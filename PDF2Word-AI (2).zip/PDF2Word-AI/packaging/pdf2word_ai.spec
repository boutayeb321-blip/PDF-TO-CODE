# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for PDF2Word AI — by Boutib Ahmed.
Builds one self-contained executable with the logo and every data file bundled.

Driven by the build scripts. If the environment variable PDF2WORD_SRC is set (the build
script points it at the PyArmor-obfuscated copy), the app is built from there instead of the
plain source, so the shipped executable contains no readable Python source (anti-theft)."""
import os
import sys

from PyInstaller.utils.hooks import collect_all, collect_submodules

block_cipher = None

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(SPEC)), ".."))
SRC = os.environ.get("PDF2WORD_SRC") or ROOT          # where run.py + pdf2word_ai live
ASSETS = os.path.join(ROOT, "assets")
ICON = os.path.join(ASSETS, "icon.ico")

# the web UI, the icon and (if present) the pyarmor runtime must travel inside the exe
datas = [(os.path.join(SRC, "pdf2word_ai", "web"), os.path.join("pdf2word_ai", "web")),
         (ICON, "assets")]
for n in os.listdir(SRC):
    if n.startswith("pyarmor_runtime"):
        datas.append((os.path.join(SRC, n), n))

binaries = []
# list the app's own modules explicitly, so the build works even when the package is obfuscated
# (and importing it for auto-discovery would need the PyArmor runtime on the path)
_mods = ["ai", "aiexport", "analysis", "archives", "batch", "cli", "converter", "docxwriter",
         "gdrive", "layout", "mdparse", "model", "ocr", "ocr_embedded", "settings", "textutils", "webui"]
hiddenimports = ["pdf2word_ai"] + [f"pdf2word_ai.{m}" for m in _mods] + ["flask", "werkzeug", "jinja2"]
for n in os.listdir(SRC):
    if n.startswith("pyarmor_runtime"):
        hiddenimports.append(n)

# libraries that ship data files / native parts PyInstaller must be told about explicitly
for pkg in ("pdfplumber", "pdfminer", "pypdfium2", "pypdfium2_raw", "docx", "PIL", "pikepdf",
            "charset_normalizer", "rapidocr", "rapidocr_onnxruntime", "onnxruntime"):
    try:
        d, b, h = collect_all(pkg)
        datas += d
        binaries += b
        hiddenimports += h
    except Exception:
        pass
try:
    hiddenimports += collect_submodules("pdf2word_ai")  # works for the plain (non-obfuscated) build
except Exception:
    pass

a = Analysis([os.path.join(SRC, "run.py")],
             pathex=[SRC],
             binaries=binaries,
             datas=datas,
             hiddenimports=hiddenimports,
             hookspath=[],
             runtime_hooks=[],
             excludes=["tkinter", "matplotlib", "pytest", "PyInstaller"],
             cipher=block_cipher,
             noarchive=False)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
          name="PDF2Word-AI",
          debug=False,
          bootloader_ignore_signals=False,
          strip=False,
          upx=True,
          runtime_tmpdir=None,
          console=False,            # windowed: no black console window
          disable_windowed_traceback=False,
          icon=ICON if os.path.exists(ICON) else None,
          version=os.path.join(os.path.dirname(os.path.abspath(SPEC)), "version_info.txt")
          if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(SPEC)), "version_info.txt")) else None)
