@echo off
chcp 65001 >nul
title PDF2Word AI - Build EXE  (by Boutib Ahmed)
cd /d "%~dp0"
setlocal enabledelayedexpansion

rem ============================================================
rem  Builds a single Windows executable:  dist\PDF2Word-AI.exe
rem  - embeds the logo and every file the program needs
rem  - OBFUSCATE=1 (default) scrambles the Python code (anti-theft)
rem    set OBFUSCATE=0 below if the built exe refuses to start
rem ============================================================
set "OBFUSCATE=1"

echo ================================================================
echo   PDF2Word AI - building the Windows program (needs internet)
echo ================================================================
echo.

set "PY="
py -3 -c "import sys;sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys;sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul && set "PY=python"
if not defined PY goto nopython

echo [1/6] Python found:
%PY% --version
if not exist ".buildenv\Scripts\python.exe" %PY% -m venv .buildenv || goto fail
set "VP=.buildenv\Scripts\python.exe"

echo [2/6] Installing the program libraries ...
"%VP%" -m pip install --upgrade pip >nul
"%VP%" -m pip install -r requirements.txt || goto fail
"%VP%" -m pip install -r requirements-optional.txt >nul 2>nul
"%VP%" -m pip install -r requirements-ocr.txt >nul 2>nul

echo [3/6] Installing the build tool (PyInstaller) ...
"%VP%" -m pip install "pyinstaller>=6.6" || goto fail

echo [4/6] Preparing the logo ...
"%VP%" assets\make_logo.py >nul 2>nul

rem clean previous build
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
set "PDF2WORD_SRC="

if "%OBFUSCATE%"=="1" (
  echo [5/6] Protecting the code against theft ^(PyArmor^) ...
  "%VP%" -m pip install pyarmor >nul 2>nul
  "%VP%" -m pyarmor gen -O build\obf -r run.py pdf2word_ai >build\pyarmor.log 2>&1
  if exist "build\obf\run.py" (
    xcopy /e /i /y /q pdf2word_ai\web build\obf\pdf2word_ai\web >nul
    set "PDF2WORD_SRC=%cd%\build\obf"
    echo       code protection: ON
  ) else (
    echo       PyArmor not available - building without obfuscation ^(the exe still ships compiled, no source^).
    type build\pyarmor.log 2>nul | more
  )
) else (
  echo [5/6] Obfuscation disabled by setting ^(OBFUSCATE=0^).
)

echo [6/6] Building the executable ... this takes a few minutes.
"%VP%" -m PyInstaller --clean --noconfirm packaging\pdf2word_ai.spec || goto buildfail

if not exist "dist\PDF2Word-AI.exe" goto buildfail
echo.
echo ================================================================
echo   Done!  Your program is:
echo       %cd%\dist\PDF2Word-AI.exe
echo   Double-click it to run. You can copy this single file anywhere.
echo   (by Boutib Ahmed)
echo ================================================================
rem put a copy next to this script for convenience
copy /y "dist\PDF2Word-AI.exe" "PDF2Word-AI.exe" >nul 2>nul
pause
exit /b 0

:buildfail
echo.
echo The build failed.
if "%OBFUSCATE%"=="1" echo Try again after editing this file and setting  OBFUSCATE=0
echo See the messages above for the reason.
pause
exit /b 1

:nopython
echo Python 3.9+ was not found. Install it from https://www.python.org/downloads/
echo and tick "Add python.exe to PATH" on the first screen, then run this file again.
start "" https://www.python.org/downloads/
pause
exit /b 1

:fail
echo.
echo Setup failed (check your internet connection) and run this file again.
pause
exit /b 1
