# -*- coding: utf-8 -*-
"""Write the document model to a Word (.docx) file with proper right-to-left support."""
from __future__ import annotations

import os

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

from . import textutils as tu
from . import AUTHOR
from .model import Paragraph, Picture, Run, Table

PPR_ORDER = ["w:pStyle", "w:keepNext", "w:keepLines", "w:pageBreakBefore", "w:framePr", "w:widowControl", "w:numPr",
             "w:suppressLineNumbers", "w:pBdr", "w:shd", "w:tabs", "w:suppressAutoHyphens", "w:kinsoku", "w:wordWrap",
             "w:overflowPunct", "w:topLinePunct", "w:autoSpaceDE", "w:autoSpaceDN", "w:bidi", "w:adjustRightInd",
             "w:snapToGrid", "w:spacing", "w:ind", "w:contextualSpacing", "w:mirrorIndents", "w:suppressOverlap", "w:jc",
             "w:textDirection", "w:textAlignment", "w:textboxTightWrap", "w:outlineLvl", "w:divId", "w:cnfStyle", "w:rPr",
             "w:sectPr", "w:pPrChange"]
RPR_ORDER = ["w:rStyle", "w:rFonts", "w:b", "w:bCs", "w:i", "w:iCs", "w:caps", "w:smallCaps", "w:strike", "w:dstrike",
             "w:outline", "w:shadow", "w:emboss", "w:imprint", "w:noProof", "w:snapToGrid", "w:vanish", "w:webHidden",
             "w:color", "w:spacing", "w:w", "w:kern", "w:position", "w:sz", "w:szCs", "w:highlight", "w:u", "w:effect",
             "w:bdr", "w:shd", "w:fitText", "w:vertAlign", "w:rtl", "w:cs", "w:em", "w:lang", "w:eastAsianLayout",
             "w:specVanish", "w:oMath"]
TBLPR_ORDER = ["w:tblStyle", "w:tblpPr", "w:tblOverlap", "w:bidiVisual", "w:tblStyleRowBandSize", "w:tblStyleColBandSize",
               "w:tblW", "w:jc", "w:tblCellSpacing", "w:tblInd", "w:tblBorders", "w:shd", "w:tblLayout", "w:tblCellMar",
               "w:tblLook", "w:tblCaption", "w:tblDescription"]
SECTPR_ORDER = ["w:headerReference", "w:footerReference", "w:footnotePr", "w:endnotePr", "w:type", "w:pgSz", "w:pgMar",
                "w:paperSrc", "w:pgBorders", "w:lnNumType", "w:pgNumType", "w:cols", "w:formProt", "w:vAlign",
                "w:noEndnote", "w:titlePg", "w:textDirection", "w:bidi", "w:rtlGutter", "w:docGrid", "w:printerSettings",
                "w:sectPrChange"]


def _local(el):
    return "w:" + el.tag.split("}", 1)[1]


def _insert_ordered(parent, child, order):
    name = _local(child)
    try:
        succ = set(order[order.index(name) + 1:])
    except ValueError:
        parent.append(child)
        return child
    for existing in parent:
        try:
            if _local(existing) in succ:
                existing.addprevious(child)
                return child
        except Exception:
            continue
    parent.append(child)
    return child


def _ensure(parent, tag, order, val=None, attrs=None):
    el = parent.find(qn(tag))
    if el is None:
        el = OxmlElement(tag)
        _insert_ordered(parent, el, order)
    if val is not None:
        el.set(qn("w:val"), str(val))
    for k, v in (attrs or {}).items():
        el.set(qn(k), str(v))
    return el


def _set_fonts(rPr, latin, cs):
    rf = rPr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts")
        _insert_ordered(rPr, rf, RPR_ORDER)
    for a in list(rf.attrib):
        del rf.attrib[a]
    rf.set(qn("w:ascii"), latin)
    rf.set(qn("w:hAnsi"), latin)
    rf.set(qn("w:eastAsia"), latin)
    rf.set(qn("w:cs"), cs)


def script_segments(text, para_rtl):
    """Split text into (segment, is_rtl) so Arabic runs get complex-script formatting."""
    segs = []
    cur, cur_dir = [], None
    for ch in text:
        b = tu.bidi_of(ch)
        d = "R" if b in ("R", "AL") else ("L" if b == "L" else None)
        if d is None or cur_dir is None or d == cur_dir:
            if cur_dir is None and d is not None:
                cur_dir = d
            cur.append(ch)
        else:
            segs.append(("".join(cur), cur_dir == "R"))
            cur, cur_dir = [ch], d
    if cur:
        segs.append(("".join(cur), (cur_dir == "R") if cur_dir else para_rtl))
    return segs


ARABIC_FONT_HINTS = ("arab", "naskh", "kufi", "amiri", "scheherazade", "lateef", "majalla", "andalus", "aldhabi",
                     "traditional", "simplified", "lotus", "badr", "mitra", "nazanin", "yagut", "zar", "hacen", "droid",
                     "dejavu", "tahoma", "arial", "times new roman", "segoe", "noto", "uthman", "thuluth", "diwani",
                     "ruqaa", "cairo", "tajawal", "almarai", "vazir", "sahel", "ge ss", "ge dinar", "frutiger", "sultan")


class DocxBuilder:
    def __init__(self, font_latin="Calibri", font_arabic="Arial", base_size=12.0, keep_fonts=True, rtl_doc=False,
                 margins=None, title=None):
        self.doc = Document()
        self.font_latin = font_latin or "Calibri"
        self.font_cs = font_arabic or "Arial"
        self.base_size = base_size or 12.0
        self.keep_fonts = keep_fonts
        self.rtl_doc = rtl_doc
        self.margins = margins or (56.7, 56.7, 56.7, 56.7)  # left, top, right, bottom (pt)
        self.first_page = True
        self.cur_size = None
        self.pending_break = False
        self.page_has_content = False
        self.content_w = 480.0
        self.content_h = 700.0
        self.page_w = 480.0
        self.cur_cols = 1
        self.section_has_content = False
        self._setup_styles()
        if title:
            self.doc.core_properties.title = title[:250]
        self.doc.core_properties.comments = "Converted by PDF2Word AI"
        self.doc.core_properties.author = AUTHOR
        self.doc.core_properties.last_modified_by = AUTHOR

    # -- styles ---------------------------------------------------------------------------
    def _style_fonts(self, style, size, bold=None, color_black=False):
        rPr = style.element.get_or_add_rPr()
        _set_fonts(rPr, self.font_latin, self.font_cs)
        half = str(int(round(size * 2)))
        _ensure(rPr, "w:sz", RPR_ORDER, val=half)
        _ensure(rPr, "w:szCs", RPR_ORDER, val=half)
        if bold:
            _ensure(rPr, "w:b", RPR_ORDER)
            _ensure(rPr, "w:bCs", RPR_ORDER)
        if color_black:
            c = rPr.find(qn("w:color"))
            if c is not None:
                rPr.remove(c)
            _ensure(rPr, "w:color", RPR_ORDER, val="000000")
        _ensure(rPr, "w:lang", RPR_ORDER, attrs={"w:bidi": "ar-SA"})

    def _setup_styles(self):
        st = self.doc.styles
        normal = st["Normal"]
        self._style_fonts(normal, self.base_size)
        pf = normal.paragraph_format
        pf.space_after = Pt(4)
        pf.space_before = Pt(0)
        pf.line_spacing = 1.1
        sizes = {1: 18, 2: 15, 3: 13}
        for lvl, sz in sizes.items():
            try:
                h = st[f"Heading {lvl}"]
            except KeyError:
                continue
            self._style_fonts(h, sz, bold=True, color_black=True)
            h.paragraph_format.space_before = Pt(10 if lvl == 1 else 8)
            h.paragraph_format.space_after = Pt(4)
            h.paragraph_format.keep_with_next = True

    # -- pages ----------------------------------------------------------------------------
    def _set_cols(self, sec, n, gap):
        cols = sec._sectPr.find(qn("w:cols"))
        if cols is None:
            cols = OxmlElement("w:cols")
            _insert_ordered(sec._sectPr, cols, SECTPR_ORDER)
        cols.set(qn("w:num"), str(max(1, n)))
        cols.set(qn("w:space"), str(int(round((gap or 18.0) * 20))))
        self.cur_cols = max(1, n)
        self.col_gap = gap or 18.0
        self.content_w = (self.page_w - (n - 1) * self.col_gap) / n if n > 1 else self.page_w

    def _setup_section(self, sec, w, h):
        if w > h:
            sec.orientation = WD_ORIENT.LANDSCAPE
        else:
            sec.orientation = WD_ORIENT.PORTRAIT
        sec.page_width = Pt(w)
        sec.page_height = Pt(h)
        l, t, r, b = self.margins
        min_w = 0.45 * w
        if w - l - r < min_w:
            l = r = (w - min_w) / 2
        min_h = 0.45 * h
        if h - t - b < min_h:
            t = b = (h - min_h) / 2
        sec.left_margin, sec.right_margin = Pt(l), Pt(r)
        sec.top_margin, sec.bottom_margin = Pt(t), Pt(b)
        sec.header_distance = Pt(min(30, t * 0.5))
        sec.footer_distance = Pt(min(30, b * 0.5))
        self.content_w = w - l - r
        self.page_w = self.content_w
        self.content_h = h - t - b
        if self.rtl_doc:
            _ensure(sec._sectPr, "w:bidi", SECTPR_ORDER)

    def start_page(self, width, height, columns=1, gap=0.0):
        width, height = float(width), float(height)
        if self.first_page:
            sec = self.doc.sections[0]
            self._setup_section(sec, width, height)
            self._set_cols(sec, columns, gap)
            self.first_page = False
            self.pending_break = False
            self.section_new = True
        elif (self.cur_size and (abs(width - self.cur_size[0]) > 2 or abs(height - self.cur_size[1]) > 2)) or columns != self.cur_cols:
            sec = self.doc.add_section(WD_SECTION.NEW_PAGE)
            self._setup_section(sec, width, height)
            self._set_cols(sec, columns, gap)
            self.pending_break = False
            self.section_new = True
        else:
            self.pending_break = True
            self.section_new = False
        self.cur_size = (width, height)
        self.page_has_content = False

    def switch_columns(self, columns, gap=0.0):
        """Continuous section break inside a page (e.g. full-width title above two columns)."""
        if columns == self.cur_cols:
            return
        if not self.page_has_content and getattr(self, "section_new", False):
            self._set_cols(self.doc.sections[-1], columns, gap)
            return
        sec = self.doc.add_section(WD_SECTION.CONTINUOUS)
        self._set_cols(sec, columns, gap)

    def end_page(self):
        if not self.page_has_content:
            p = self.doc.add_paragraph()
            self._apply_break(p)
            self.page_has_content = True

    def _apply_break(self, par):
        if self.pending_break:
            par.paragraph_format.page_break_before = True
            self.pending_break = False

    # -- paragraphs -----------------------------------------------------------------------
    def _font_for(self, r: Run, rtl_seg: bool):
        latin, cs = self.font_latin, self.font_cs
        if self.keep_fonts and r.font:
            if rtl_seg:
                low = r.font.lower()
                if any(h in low for h in ARABIC_FONT_HINTS):
                    cs = r.font
            else:
                latin = r.font
        return latin, cs

    def _add_run(self, par, text, r: Run, rtl_seg: bool, para_size):
        pieces = text.split("\n")
        for k, piece in enumerate(pieces):
            if k > 0:
                par.add_run().add_break(WD_BREAK.LINE)
            if not piece:
                continue
            run = par.add_run(piece)
            rPr = run._r.get_or_add_rPr()
            latin, cs = self._font_for(r, rtl_seg)
            _set_fonts(rPr, latin, cs)
            if r.bold:
                _ensure(rPr, "w:b", RPR_ORDER)
                _ensure(rPr, "w:bCs", RPR_ORDER)
            if r.italic:
                _ensure(rPr, "w:i", RPR_ORDER)
                _ensure(rPr, "w:iCs", RPR_ORDER)
            if r.color:
                _ensure(rPr, "w:color", RPR_ORDER, val=r.color)
            size = r.size or para_size
            if size:
                half = str(max(2, int(round(size * 2))))
                _ensure(rPr, "w:sz", RPR_ORDER, val=half)
                _ensure(rPr, "w:szCs", RPR_ORDER, val=half)
            if r.underline:
                _ensure(rPr, "w:u", RPR_ORDER, val="single")
            if r.superscript:
                _ensure(rPr, "w:vertAlign", RPR_ORDER, val="superscript")
            if rtl_seg:
                _ensure(rPr, "w:rtl", RPR_ORDER)

    def write_paragraph(self, par, p: Paragraph):
        if p.heading:
            try:
                par.style = self.doc.styles[f"Heading {min(3, p.heading)}"]
            except KeyError:
                pass
        if p.rtl:
            _ensure(par._p.get_or_add_pPr(), "w:bidi", PPR_ORDER)
        if p.space_before and p.space_before > 0:
            par.paragraph_format.space_before = Pt(p.space_before)
        if p.align == "center":
            par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif p.align == "justify":
            par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        elif p.align == "right" and not p.rtl:
            par.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        # Left alignment of a right-to-left paragraph is not written: Word and LibreOffice do
        # not agree on what "left" means inside a bidi paragraph.
        for r in p.runs:
            if not r.text:
                continue
            for seg, seg_rtl in script_segments(r.text, p.rtl):
                self._add_run(par, seg, r, seg_rtl, None)

    def add_paragraph(self, p: Paragraph):
        par = self.doc.add_paragraph()
        self._apply_break(par)
        self.write_paragraph(par, p)
        self.page_has_content = True
        return par

    # -- tables ---------------------------------------------------------------------------
    def add_table(self, t: Table):
        nrows = len(t.grid)
        ncols = max((len(r) for r in t.grid), default=0)
        if nrows == 0 or ncols == 0:
            return
        if self.pending_break:
            spacer = self.doc.add_paragraph()
            self._apply_break(spacer)
            spacer.paragraph_format.space_after = Pt(0)
        table = self.doc.add_table(rows=nrows, cols=ncols)
        try:
            table.style = self.doc.styles["Table Grid"]
        except KeyError:
            pass
        tblPr = table._tbl.tblPr
        if t.rtl:
            _ensure(tblPr, "w:bidiVisual", TBLPR_ORDER)
        widths = t.col_widths if t.col_widths and len(t.col_widths) == ncols else None
        if widths:
            total = sum(widths)
            scale = min(1.0, self.content_w / total) if total > 0 else 1.0
            widths = [max(18.0, w * scale) for w in widths]
            table.autofit = False
            for row in table.rows:
                for ci, cell in enumerate(row.cells):
                    if ci < ncols:
                        cell.width = Pt(widths[ci])
        # merges first
        for ri, row in enumerate(t.grid):
            for ci, cell in enumerate(row):
                if cell is None:
                    continue
                rs, cs = max(1, cell.rowspan), max(1, cell.colspan)
                if rs > 1 or cs > 1:
                    r2, c2 = min(nrows - 1, ri + rs - 1), min(ncols - 1, ci + cs - 1)
                    try:
                        table.cell(ri, ci).merge(table.cell(r2, c2))
                    except Exception:
                        pass
        for ri, row in enumerate(t.grid):
            for ci, cell in enumerate(row):
                if cell is None:
                    continue
                dcell = table.cell(ri, ci)
                paras = cell.paragraphs or []
                first = dcell.paragraphs[0]
                first.paragraph_format.space_after = Pt(0)
                for k, p in enumerate(paras):
                    target = first if k == 0 else dcell.add_paragraph()
                    target.paragraph_format.space_after = Pt(0)
                    self.write_paragraph(target, p)
                if not paras and t.rtl:
                    _ensure(first._p.get_or_add_pPr(), "w:bidi", PPR_ORDER)
        after = self.doc.add_paragraph()
        after.paragraph_format.space_after = Pt(0)
        self.page_has_content = True

    # -- pictures -------------------------------------------------------------------------
    def add_picture(self, pic: Picture):
        if not pic.path or not os.path.exists(pic.path):
            return
        w = max(8.0, float(pic.width or 100))
        h = max(8.0, float(pic.height or 100))
        scale = min(1.0, self.content_w / w, (self.content_h * 0.98) / h)
        par = self.doc.add_paragraph()
        self._apply_break(par)
        par.paragraph_format.space_after = Pt(4)
        try:
            par.add_run().add_picture(pic.path, width=Pt(w * scale))
        except Exception:
            return
        if pic.align == "center" or pic.kind == "page":
            par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif pic.align == "right":
            par.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        elif pic.align == "left":
            par.alignment = WD_ALIGN_PARAGRAPH.LEFT
        self.page_has_content = True

    def add_item(self, it):
        if isinstance(it, Paragraph):
            if it.text.strip():
                self.add_paragraph(it)
        elif isinstance(it, Table):
            self.add_table(it)
        elif isinstance(it, Picture):
            self.add_picture(it)

    def save(self, path):
        self.doc.save(path)


def docx_text(path) -> str:
    """All visible text of a .docx (body, tables, text boxes) for verification."""
    d = Document(path)
    parts = []
    body = d.element.body
    for p in body.iter(qn("w:p")):
        parts.append("".join(t.text or "" for t in p.iter(qn("w:t"))))
    return "\n".join(parts)
