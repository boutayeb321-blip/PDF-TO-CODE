# -*- coding: utf-8 -*-
"""Free AI correction: Google Gemini (free API key), Ollama (local, offline), Groq / OpenRouter /
any OpenAI-compatible server. The AI only *reads* scanned pages; every answer is validated
against the OCR draft and rejected if it drops, adds, translates or rewrites content."""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass

from . import textutils as tu

PROVIDERS = {
    "gemini": {"label": "Google Gemini — مجاني بمفتاح", "model": "auto", "base_url": "https://generativelanguage.googleapis.com/v1beta",
               "vision": True, "key_url": "https://aistudio.google.com/apikey", "needs_key": True, "rpm": 8},
    "ollama": {"label": "Ollama — على جهازك بدون إنترنت", "model": "qwen3-vl:8b", "base_url": "http://localhost:11434",
               "vision": True, "key_url": "https://ollama.com/download", "needs_key": False, "rpm": 60},
    "groq": {"label": "Groq — مجاني بمفتاح", "model": "qwen/qwen3.8-27b", "base_url": "https://api.groq.com/openai/v1",
             "vision": True, "key_url": "https://console.groq.com/keys", "needs_key": True, "rpm": 20},
    "openrouter": {"label": "OpenRouter — نماذج مجانية", "model": "", "base_url": "https://openrouter.ai/api/v1",
                   "vision": True, "key_url": "https://openrouter.ai/keys", "needs_key": True, "rpm": 15},
    "custom": {"label": "خادم متوافق مع OpenAI", "model": "", "base_url": "", "vision": False, "key_url": "", "needs_key": False, "rpm": 30},
}


class AIError(Exception):
    pass


class AIQuotaExhausted(AIError):
    pass


class AIAuthError(AIError):
    pass


class AIBlocked(AIError):
    pass


class _ModelNotFound(AIError):
    pass


def http_json(method, url, payload=None, headers=None, timeout=180):
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
    h = {"Content-Type": "application/json", "User-Agent": "PDF2Word-AI/1.0"}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", "replace")
            try:
                return r.status, json.loads(body or "{}"), dict(r.headers)
            except json.JSONDecodeError:
                return r.status, {"raw": body[:2000]}, dict(r.headers)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace") if e.fp else ""
        try:
            j = json.loads(body)
        except Exception:
            j = {"raw": body[:500]}
        return e.code, j, dict(e.headers or {})
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
        raise AIError(f"تعذّر الاتصال بخدمة الذكاء الاصطناعي: {getattr(e, 'reason', e)}")


class RateLimiter:
    def __init__(self, rpm):
        self.interval = 60.0 / max(float(rpm or 1), 0.1)
        self.next = 0.0
        self.lock = threading.Lock()

    def wait(self):
        with self.lock:
            now = time.monotonic()
            if now < self.next:
                time.sleep(self.next - now)
                now = self.next
            self.next = now + self.interval


def _strip_think(text):
    return re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()


def _err_message(j):
    if isinstance(j, dict):
        e = j.get("error")
        if isinstance(e, dict):
            return e.get("message") or json.dumps(e, ensure_ascii=False)[:300]
        if isinstance(e, str):
            return e
        return (j.get("raw") or json.dumps(j, ensure_ascii=False))[:300]
    return str(j)[:300]


# ----------------------------------------------------------------------------------------------
# Providers
# ----------------------------------------------------------------------------------------------
class GeminiProvider:
    name = "gemini"
    supports_vision = True

    def __init__(self, api_key, model="auto", rpm=8, base_url=None, log=None):
        self.key = (api_key or "").strip()
        self.base = (base_url or PROVIDERS["gemini"]["base_url"]).rstrip("/")
        self.model_pref = (model or "auto").strip()
        self.limiter = RateLimiter(rpm or 8)
        self.log = log or (lambda *_: None)
        self.candidates = None
        self.idx = 0
        self.compat = {}

    @property
    def model(self):
        if self.candidates and self.idx < len(self.candidates):
            return self.candidates[self.idx]
        return self.model_pref

    def _headers(self):
        return {"x-goog-api-key": self.key}

    def list_models(self):
        st, j, _ = http_json("GET", f"{self.base}/models?pageSize=1000", headers=self._headers(), timeout=30)
        if st in (400, 401, 403):
            raise AIAuthError(_err_message(j))
        if st != 200:
            raise AIError(f"HTTP {st}: {_err_message(j)}")
        out = []
        for m in j.get("models", []):
            if "generateContent" in (m.get("supportedGenerationMethods") or []):
                out.append(m.get("name", "").split("/", 1)[-1])
        return out

    @staticmethod
    def rank(models):
        bad = ("image", "tts", "live", "audio", "transcribe", "omni", "embedding", "robotics", "computer", "native",
               "learnlm", "gemma", "aqa", "veo", "imagen", "lyria", "translate", "research", "thinking-exp", "nano")
        cands = [m for m in models if "flash" in m and not any(b in m for b in bad)]

        def ver(m):
            nums = re.findall(r"(\d+(?:\.\d+)?)", m)
            return float(nums[0]) if nums else 99.0

        cands.sort(key=lambda m: ("lite" in m, ("preview" in m or "exp" in m), -ver(m), m))
        return cands

    def _ensure_candidates(self):
        if self.candidates is not None:
            return
        cands = []
        if self.model_pref and self.model_pref != "auto":
            cands.append(self.model_pref)
        try:
            for m in self.rank(self.list_models()):
                if m not in cands:
                    cands.append(m)
        except AIAuthError:
            raise
        except AIError as e:
            self.log(f"تعذّر جلب قائمة نماذج Gemini: {e}")
        if not cands:
            cands = ["gemini-flash-latest", "gemini-3.8-flash", "gemini-3.5-flash-lite"]
        self.candidates = cands

    @staticmethod
    def _v3plus(model):
        m = re.search(r"gemini-(\d+)", model)
        return True if not m else int(m.group(1)) >= 3

    def _body(self, model, system, prompt, image, max_tokens, extras):
        parts = [{"text": prompt}]
        if image:
            img = {"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(image).decode("ascii")}}
            if extras:
                img["mediaResolution"] = {"level": "media_resolution_high"}
            parts.append(img)
        gen = {"maxOutputTokens": max_tokens}
        if extras:
            gen["thinkingConfig"] = {"thinkingLevel": "low"}
        elif not self._v3plus(model):
            gen["temperature"] = 0
        return {"systemInstruction": {"parts": [{"text": system}]},
                "contents": [{"role": "user", "parts": parts}], "generationConfig": gen}

    @staticmethod
    def _is_daily(j, msg):
        err = j.get("error", {}) if isinstance(j, dict) else {}
        for d in err.get("details", []) or []:
            for v in d.get("violations", []) or []:
                q = (v.get("quotaId", "") + " " + v.get("quotaMetric", "")).lower()
                if "perday" in q or "per_day" in q or "daily" in q:
                    return True
        return bool(re.search(r"per day|daily|PerDay", msg or "", re.I))

    @staticmethod
    def _retry_delay(j, hdr):
        err = j.get("error", {}) if isinstance(j, dict) else {}
        for d in err.get("details", []) or []:
            rd = d.get("retryDelay")
            if rd:
                m = re.match(r"([\d.]+)s", str(rd))
                if m:
                    return min(120.0, float(m.group(1)) + 1)
        ra = (hdr or {}).get("Retry-After") or (hdr or {}).get("retry-after")
        if ra:
            try:
                return min(120.0, float(ra))
            except ValueError:
                pass
        return None

    def _call(self, model, system, prompt, image, max_tokens):
        extras = self._v3plus(model) and self.compat.get(model, True)
        attempt = 0
        while attempt < 7:
            body = self._body(model, system, prompt, image, max_tokens, extras)
            self.limiter.wait()
            st, j, hdr = http_json("POST", f"{self.base}/models/{model}:generateContent", body, self._headers(), timeout=300)
            if st == 200:
                return self._extract(j)
            msg = _err_message(j)
            if st == 400 and extras and re.search(r"thinking|media.?resolution|Unknown name|Invalid JSON payload", msg, re.I):
                self.compat[model] = False
                extras = False
                continue
            if st in (401, 403) or (st == 400 and re.search(r"api key|API_KEY", msg, re.I)):
                raise AIAuthError(msg)
            if st == 404:
                raise _ModelNotFound(msg)
            if st == 429:
                if self._is_daily(j, msg):
                    raise AIQuotaExhausted(msg)
                delay = self._retry_delay(j, hdr) or min(60.0, 5.0 * (2 ** attempt))
                self.log(f"تجاوز حد الطلبات مؤقتاً، انتظار {int(delay)} ثانية…")
                time.sleep(delay)
                attempt += 1
                continue
            if st >= 500:
                time.sleep(min(60.0, 4.0 * (2 ** attempt)))
                attempt += 1
                continue
            raise AIError(f"HTTP {st}: {msg}")
        raise AIError("فشل الطلب بعد عدة محاولات")

    @staticmethod
    def _extract(j):
        cands = j.get("candidates") or []
        if not cands:
            fb = j.get("promptFeedback") or {}
            raise AIBlocked(fb.get("blockReason") or "لا توجد إجابة")
        c = cands[0]
        fr = c.get("finishReason", "")
        parts = (c.get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        if fr in ("SAFETY", "RECITATION", "BLOCKLIST", "PROHIBITED_CONTENT", "SPII"):
            raise AIBlocked(fr)
        if fr == "MAX_TOKENS":
            raise AIError("الإجابة مقطوعة (طويلة جداً)")
        return text

    def generate(self, system, prompt, image=None, max_tokens=16384):
        self._ensure_candidates()
        last = None
        while self.idx < len(self.candidates):
            model = self.candidates[self.idx]
            try:
                return self._call(model, system, prompt, image, max_tokens)
            except AIQuotaExhausted as e:
                last = e
                self.log(f"انتهت الحصة اليومية المجانية للنموذج {model}، التحويل إلى نموذج آخر…")
                self.idx += 1
            except _ModelNotFound as e:
                last = e
                self.idx += 1
        raise AIQuotaExhausted(f"لا يوجد نموذج Gemini متاح حالياً ({last})")

    def describe(self):
        return f"Gemini ({self.model})"

    def cache_id(self):
        return f"gemini:{self.model_pref}"


class OllamaProvider:
    name = "ollama"

    def __init__(self, base_url=None, model=None, log=None, vision=None):
        self.base = (base_url or PROVIDERS["ollama"]["base_url"]).rstrip("/")
        self.model = (model or PROVIDERS["ollama"]["model"]).strip()
        self.log = log or (lambda *_: None)
        self._vision = vision
        self._think_ok = True

    @property
    def supports_vision(self):
        if self._vision is None:
            self._vision = self._detect_vision()
        return self._vision

    def _detect_vision(self):
        try:
            st, j, _ = http_json("POST", f"{self.base}/api/show", {"model": self.model}, timeout=20)
            if st == 200:
                caps = j.get("capabilities")
                if isinstance(caps, list):
                    return "vision" in caps
        except AIError:
            pass
        return bool(re.search(r"vl|vision|llava|gemma3|gemma4|minicpm-v|moondream|granite.*vision|mistral-small3", self.model, re.I))

    def list_models(self):
        st, j, _ = http_json("GET", f"{self.base}/api/tags", timeout=15)
        if st != 200:
            raise AIError(f"HTTP {st}: {_err_message(j)}")
        return [m.get("name") for m in j.get("models", [])]

    def generate(self, system, prompt, image=None, max_tokens=16384):
        msg = {"role": "user", "content": prompt}
        if image and self.supports_vision:
            msg["images"] = [base64.b64encode(image).decode("ascii")]
        body = {"model": self.model, "messages": [{"role": "system", "content": system}, msg], "stream": False,
                "options": {"temperature": 0, "num_ctx": 16384, "num_predict": max_tokens}, "keep_alive": "15m"}
        for _ in range(3):
            if self._think_ok:
                body["think"] = False
            else:
                body.pop("think", None)
            st, j, _ = http_json("POST", f"{self.base}/api/chat", body, timeout=1800)
            if st == 200:
                return _strip_think((j.get("message") or {}).get("content", ""))
            msg_ = _err_message(j)
            if st == 400 and "think" in msg_.lower() and self._think_ok:
                self._think_ok = False
                continue
            if st == 404:
                raise AIError(f"النموذج غير مثبت في Ollama. شغّل: ollama pull {self.model}")
            if st >= 500:
                time.sleep(3)
                continue
            raise AIError(f"HTTP {st}: {msg_}")
        raise AIError("فشل الاتصال بـ Ollama")

    def describe(self):
        return f"Ollama ({self.model})"

    def cache_id(self):
        return f"ollama:{self.model}"


class OpenAICompatProvider:
    name = "openai"

    def __init__(self, base_url, api_key="", model="", vision=True, rpm=20, log=None, name="openai"):
        self.base = (base_url or "").rstrip("/")
        self.key = (api_key or "").strip()
        self.model = (model or "").strip()
        self.supports_vision = bool(vision)
        self.limiter = RateLimiter(rpm or 20)
        self.log = log or (lambda *_: None)
        self.name = name

    def _headers(self):
        h = {}
        if self.key:
            h["Authorization"] = f"Bearer {self.key}"
        if "openrouter.ai" in self.base:
            h["HTTP-Referer"] = "https://github.com/pdf2word-ai"
            h["X-Title"] = "PDF2Word AI"
        return h

    def list_models(self):
        st, j, _ = http_json("GET", f"{self.base}/models", headers=self._headers(), timeout=30)
        if st in (401, 403):
            raise AIAuthError(_err_message(j))
        if st != 200:
            raise AIError(f"HTTP {st}: {_err_message(j)}")
        return [d.get("id") for d in j.get("data", []) if d.get("id")]

    def generate(self, system, prompt, image=None, max_tokens=8192):
        if not self.model:
            raise AIError("لم يتم تحديد اسم النموذج")
        content = [{"type": "text", "text": prompt}]
        if image and self.supports_vision:
            content.append({"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + base64.b64encode(image).decode("ascii")}})
        body = {"model": self.model, "messages": [{"role": "system", "content": system}, {"role": "user", "content": content}],
                "temperature": 0, "max_tokens": max_tokens}
        attempt = 0
        while attempt < 7:
            self.limiter.wait()
            st, j, hdr = http_json("POST", f"{self.base}/chat/completions", body, self._headers(), timeout=600)
            if st == 200:
                try:
                    ch = j["choices"][0]
                    c = ch["message"]["content"]
                except (KeyError, IndexError, TypeError):
                    raise AIError("إجابة غير متوقعة من الخادم")
                if isinstance(c, list):
                    c = "".join(p.get("text", "") for p in c if isinstance(p, dict))
                if ch.get("finish_reason") == "length":
                    raise AIError("الإجابة مقطوعة (طويلة جداً)")
                return _strip_think(c or "")
            msg = _err_message(j)
            if st in (401, 403):
                raise AIAuthError(msg)
            if st == 404:
                raise AIError(f"النموذج غير موجود: {self.model}")
            if st == 429:
                if re.search(r"per day|daily|RPD|TPD", msg, re.I):
                    raise AIQuotaExhausted(msg)
                ra = hdr.get("Retry-After") or hdr.get("retry-after")
                try:
                    delay = min(120.0, float(ra)) if ra else min(60.0, 5.0 * 2 ** attempt)
                except ValueError:
                    delay = 10.0
                self.log(f"تجاوز حد الطلبات مؤقتاً، انتظار {int(delay)} ثانية…")
                time.sleep(delay)
                attempt += 1
                continue
            if st >= 500:
                time.sleep(min(60.0, 4.0 * 2 ** attempt))
                attempt += 1
                continue
            raise AIError(f"HTTP {st}: {msg}")
        raise AIError("فشل الطلب بعد عدة محاولات")

    def describe(self):
        return f"{self.name} ({self.model})"

    def cache_id(self):
        return f"{self.name}:{self.base}:{self.model}:{int(self.supports_vision)}"


def make_provider(settings: dict, log=None):
    prov = (settings.get("ai_provider") or "gemini").lower()
    preset = PROVIDERS.get(prov, PROVIDERS["custom"])
    key = settings.get("ai_api_key", "")
    model = settings.get("ai_model") or preset["model"]
    base = settings.get("ai_base_url") or preset["base_url"]
    rpm = settings.get("ai_rpm") or preset["rpm"]
    if prov == "gemini":
        if not key:
            raise AIAuthError("مفتاح Gemini مطلوب (مجاني من aistudio.google.com/apikey)")
        return GeminiProvider(key, model or "auto", rpm, base_url=base, log=log)
    if prov == "ollama":
        return OllamaProvider(base, model, log=log)
    if preset["needs_key"] and not key:
        raise AIAuthError("مفتاح API مطلوب لهذه الخدمة")
    vision = settings.get("ai_vision")
    if vision is None:
        vision = preset["vision"]
    return OpenAICompatProvider(base, key, model, vision=vision, rpm=rpm, log=log, name=prov)


# ----------------------------------------------------------------------------------------------
# Prompts
# ----------------------------------------------------------------------------------------------
SYSTEM_PROMPT = (
    "You are a meticulous document transcription engine. You copy text exactly as it appears. "
    "You never summarize, translate, explain, reword, or add anything of your own."
)

VISION_PROMPT = """Transcribe ALL the text visible in this scanned page image, exactly as written, in its original language(s). Arabic stays Arabic, English stays English.

Rules:
1. Reproduce every word, number, date, name and punctuation mark exactly. Do not fix the author's grammar or spelling, do not paraphrase, do not translate, do not summarize, do not skip repeated text.
2. Keep diacritics (tashkeel) where they appear. Use normal Arabic letters, not presentation forms.
3. Follow the natural reading order (right-to-left for Arabic). On multi-column pages finish one column before starting the next.
4. Use Markdown only for structure: "# ", "## ", "### " for headings, "- " or "1. " for list items, and Markdown pipe tables for tables (one row per line, cells in the reading order of the original). Use **bold** only for clearly bold text.
5. Separate paragraphs with one empty line. Join the wrapped lines of one paragraph into a single line. Keep line breaks only where the layout needs them (poetry, addresses, signatures).
6. If a word is truly unreadable, write [؟] in its place. Never guess or invent text.
7. Ignore decorations (borders, watermarks, logos, stamps' artwork). Write page headers, footers and page numbers as plain lines.
8. Output ONLY the transcription: no introduction, no comments, no code fences."""

OCR_HINT = """

A rough machine-OCR draft of this page is given between <ocr> tags. It can contain wrong letters, missing or extra words, and wrong order. Use it only as a hint; the image is the source of truth.
<ocr>
{ocr}
</ocr>"""

TEXT_PROMPT = """The text between <ocr> tags was produced by OCR software from a scanned document and contains recognition errors.
Correct ONLY obvious OCR errors: wrong or missing letters inside a word, words wrongly split or merged, misrecognised punctuation, isolated noise symbols.
Strict rules:
- Do NOT rephrase, translate, summarize, reorder, add or remove words or sentences.
- Do NOT change words, names, numbers or dates that may be correct. When unsure, leave the text unchanged.
- Keep the same paragraphs and line breaks.
- Output ONLY the corrected text, without any explanation and without code fences.
<ocr>
{ocr}
</ocr>"""

_REFUSAL = re.compile(r"^(i'?m sorry|i cannot|i can'?t|sorry|unfortunately|as an ai|عذراً|عذرا|آسف|لا أستطيع|لا يمكنني)", re.I)


def clean_ai_output(text: str) -> str:
    t = _strip_think(text or "").strip()
    m = re.match(r"^```[a-zA-Z]*\s*\n(.*?)\n```\s*$", t, re.S)
    if m:
        t = m.group(1)
    t = re.sub(r"</?ocr>", "", t)
    lines = t.splitlines()
    if lines and re.match(r"^(here is|here's|below is|the transcription|transcription:|إليك|فيما يلي|النص:)", lines[0].strip(), re.I) and len(lines[0]) < 120:
        lines = lines[1:]
    return "\n".join(lines).strip()


def _markdown_to_plain(md: str) -> str:
    t = re.sub(r"^#{1,6}\s*", "", md, flags=re.M)
    t = re.sub(r"\*\*(.+?)\*\*", r"\1", t)
    t = re.sub(r"^\s*\|?\s*:?-{2,}.*$", "", t, flags=re.M)
    t = t.replace("|", " ")
    return t


@dataclass
class Correction:
    text: str = ""
    accepted: bool = False
    used: bool = False
    mode: str = ""
    reason: str = ""
    uncertain: int = 0
    needs_review: bool = False


class Corrector:
    def __init__(self, provider, cache_dir=None, log=None):
        self.p = provider
        self.log = log or (lambda *_: None)
        self.cache_dir = cache_dir
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)
        self.disabled = None  # reason string once AI must stop (quota, auth)

    @staticmethod
    def prepare_image(pil, max_side=2000):
        img = pil.convert("RGB")
        if max(img.size) > max_side:
            img = img.copy()
            img.thumbnail((max_side, max_side))
        b = io.BytesIO()
        img.save(b, "JPEG", quality=85)
        return b.getvalue()

    def _cache_get(self, key):
        if not self.cache_dir:
            return None
        f = os.path.join(self.cache_dir, key + ".txt")
        if os.path.exists(f):
            try:
                with open(f, encoding="utf-8") as fh:
                    return fh.read()
            except OSError:
                return None
        return None

    def _cache_put(self, key, text):
        if not self.cache_dir:
            return
        try:
            with open(os.path.join(self.cache_dir, key + ".txt"), "w", encoding="utf-8") as fh:
                fh.write(text)
        except OSError:
            pass

    def correct(self, page_image=None, ocr_text="", ocr_conf=None) -> Correction:
        if self.disabled:
            return Correction(reason=self.disabled)
        ocr_text = (ocr_text or "").strip()
        use_vision = page_image is not None and getattr(self.p, "supports_vision", False)
        if not use_vision and not ocr_text:
            return Correction(reason="لا يوجد نص لتصحيحه")
        if use_vision:
            img = self.prepare_image(page_image, 1600 if self.p.name == "ollama" else 2000)
            prompt = VISION_PROMPT + (OCR_HINT.format(ocr=ocr_text[:12000]) if len(ocr_text) >= 20 else "")
            mode = "vision"
        else:
            img = None
            prompt = TEXT_PROMPT.format(ocr=ocr_text[:15000])
            mode = "text"
        key = hashlib.sha256((self.p.cache_id() + mode + prompt).encode("utf-8") + (hashlib.sha256(img).digest() if img else b"")).hexdigest()
        out = self._cache_get(key)
        if out is None:
            try:
                out = self.p.generate(SYSTEM_PROMPT, prompt, img)
            except AIQuotaExhausted as e:
                self.disabled = "انتهت الحصة المجانية للذكاء الاصطناعي اليوم"
                self.log(f"⚠️ {self.disabled}: {e}. سيكمل البرنامج بدون تصحيح ذكي.")
                return Correction(reason=self.disabled)
            except AIAuthError as e:
                self.disabled = f"مشكلة في مفتاح الذكاء الاصطناعي: {e}"
                self.log("⚠️ " + self.disabled)
                return Correction(reason=self.disabled)
            except AIBlocked as e:
                return Correction(used=True, mode=mode, reason=f"رفضت الخدمة معالجة الصفحة ({e})")
            except AIError as e:
                return Correction(used=True, mode=mode, reason=str(e))
            out = clean_ai_output(out)
            if out:
                self._cache_put(key, out)
        return self.validate(out, ocr_text, ocr_conf, mode)

    @staticmethod
    def validate(out, ocr_text, ocr_conf, mode) -> Correction:
        c = Correction(text=out, used=True, mode=mode)
        if not out or len(tu.normalize_for_compare(out)) < 2:
            c.reason = "إجابة فارغة"
            return c
        if _REFUSAL.match(out.strip()) and len(out) < 400:
            c.reason = "رفض الذكاء الاصطناعي المهمة"
            return c
        c.uncertain = out.count("[؟]")
        plain = _markdown_to_plain(out)
        if ocr_text and len(tu.normalize_for_compare(ocr_text)) >= 40:
            sim = tu.similarity_report(ocr_text, plain)
            if (sim["ar_orig"] > 0.5 and sim["ar_cand"] < 0.2) or (sim["ar_orig"] < 0.15 and sim["ar_cand"] > 0.6):
                c.reason = "تغيّرت لغة النص (ترجمة) — رُفض التصحيح"
                return c
            if mode == "text":
                ok = sim["dice"] >= 0.78 and sim["words"] >= 0.45 and 0.8 <= sim["len_ratio"] <= 1.25
                if not ok:
                    c.reason = f"التصحيح غيّر النص أكثر من المسموح (تشابه {sim['dice']:.0%}) — رُفض"
                    return c
            else:
                long_enough = len(tu.normalize_for_compare(ocr_text)) >= 200
                if long_enough and sim["len_ratio"] < 0.5:
                    c.reason = "الذكاء الاصطناعي أسقط جزءاً كبيراً من النص — رُفض"
                    return c
                if long_enough and sim["len_ratio"] > 2.3:
                    c.reason = "الذكاء الاصطناعي أضاف نصاً غير موجود — رُفض"
                    return c
                if ocr_conf is not None and ocr_conf >= 88 and sim["dice"] < 0.5:
                    c.reason = "اختلاف كبير مع OCR عالي الثقة — اعتُمد نص OCR"
                    c.needs_review = True
                    return c
                if sim["dice"] < 0.35:
                    c.needs_review = True
        c.accepted = True
        if c.uncertain:
            c.needs_review = True
        return c
