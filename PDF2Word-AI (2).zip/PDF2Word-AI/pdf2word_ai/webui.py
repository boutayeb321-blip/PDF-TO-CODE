# -*- coding: utf-8 -*-
"""Local web interface (Arabic). Runs only on 127.0.0.1 and is protected by a per-run token."""
from __future__ import annotations

import html as _html
import json
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime

from flask import Flask, Response, abort, jsonify, request, send_file

from . import __version__
from . import aiexport, batch, gdrive, ocr_embedded
from . import settings as st
from .ai import PROVIDERS, AIError, make_provider
from .ocr import Tesseract, app_data_dir

HERE = os.path.dirname(os.path.abspath(__file__))


def _open_path(path, reveal=False):
    if not path or not os.path.exists(path):
        return False
    if reveal:  # show the file selected in its folder
        if sys.platform.startswith("win"):
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            return True
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path])
            return True
        path = os.path.dirname(path)
    if sys.platform.startswith("win"):
        os.startfile(path)  # noqa: S606 - local desktop action requested by the user
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])
    return True


def system_check(s):
    t = Tesseract(s.get("tesseract_path") or None, s.get("ocr_lang") or "ara+eng")
    info = {"tesseract": bool(t.exe), "tesseract_path": t.exe or "", "tesseract_version": t.version() if t.exe else ""}
    langs = set()
    if t.exe:
        _, langs = t.list_langs()
        from .ocr import app_data_dir
        user_dir = os.path.join(app_data_dir(), "tessdata")
        if os.path.isdir(user_dir):
            _, ul = t.list_langs(user_dir)
            langs |= ul
    wanted = [l for l in (s.get("ocr_lang") or "ara+eng").split("+") if l]
    info["langs"] = sorted(langs)
    info["missing_langs"] = [l for l in wanted if l not in langs]
    try:
        import pdf2docx  # noqa: F401
        info["pdf2docx"] = True
    except Exception:
        info["pdf2docx"] = False
    info["embedded"] = ocr_embedded.installed()
    info["embedded_family"] = ocr_embedded.family_for(s.get("ocr_lang") or "ara+eng")
    info["ocr_engine"] = s.get("ocr_engine", "auto")
    oa = gdrive.OAuth()
    info["drive"] = {"key": bool(s.get("drive_api_key")), "oauth_client": oa.configured(), "signed_in": oa.signed_in()}
    return info


_OAUTH_PAGE = """<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>PDF2Word AI</title>
<body style="font-family:Segoe UI,Tahoma,Arial;background:#f4f6fb;display:flex;align-items:center;justify-content:center;height:90vh">
<div style="background:#fff;padding:32px 40px;border-radius:14px;box-shadow:0 4px 24px #0001;max-width:560px;text-align:center">
<h2 style="color:{color}">{title}</h2><p style="font-size:17px;line-height:1.8">{msg}</p></div></body></html>"""


def create_app(token: str, port_holder: dict):
    app = Flask(__name__, static_folder=None)
    app.json.ensure_ascii = False
    app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 ** 3  # one uploaded file per request
    state = {"job": None}
    oauth = gdrive.OAuth()
    try:
        batch.cleanup_old()
    except Exception:
        pass

    allowed_hosts = {"127.0.0.1", "localhost"} | set(port_holder.get("hosts") or ())

    @app.before_request
    def _guard():
        host = (request.host or "").split(":")[0]
        if host not in allowed_hosts:
            abort(403)  # DNS-rebinding protection (LAN mode adds this machine's own IP only)
        if request.path.startswith("/api/") and request.headers.get("X-Token") != token:
            abort(403)

    @app.after_request
    def _headers(resp):
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Frame-Options"] = "DENY"
        return resp

    @app.get("/")
    def index():
        if request.args.get("state") and (request.args.get("code") or request.args.get("error")):
            return oauth_callback()
        with open(os.path.join(HERE, "web", "index.html"), encoding="utf-8") as f:
            html = f.read()
        return Response(html.replace("__TOKEN__", token).replace("__VERSION__", __version__), mimetype="text/html")

    def _asset(name):
        for base in (os.path.join(os.path.dirname(HERE), "assets"), os.path.join(HERE, "assets")):
            p = os.path.join(base, name)
            if os.path.exists(p):
                return p
        return None

    @app.get("/logo.png")
    def logo_png():
        p = _asset("logo_512.png") or _asset("logo.png")
        return send_file(p, mimetype="image/png") if p else ("", 404)

    @app.get("/icon-<int:size>.png")
    def icon_png(size):
        p = _asset("logo_512.png") or _asset("logo.png")
        return send_file(p, mimetype="image/png") if p else ("", 404)

    @app.get("/manifest.webmanifest")
    def manifest():
        # lets Android/Chrome "Install app" / "Add to Home screen" with the logo as the icon
        return jsonify({
            "name": "محوّل PDF إلى Word — بوطيب أحمد", "short_name": "PDF2Word AI",
            "description": "تحويل كل ملفات PDF إلى Word — من إنجاز بوطيب أحمد",
            "lang": "ar", "dir": "rtl", "start_url": "/", "scope": "/", "display": "standalone",
            "background_color": "#0e6b5c", "theme_color": "#0e6b5c",
            "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
                      {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]})

    def oauth_callback():
        if request.args.get("error"):
            msg = "أُلغي تسجيل الدخول أو رُفض: " + _html.escape(request.args.get("error", ""))
            return Response(_OAUTH_PAGE.format(color="#b42318", title="لم يكتمل تسجيل الدخول", msg=msg), mimetype="text/html")
        try:
            oauth.finish(request.args.get("code", ""), request.args.get("state", ""))
        except gdrive.DriveError as e:
            return Response(_OAUTH_PAGE.format(color="#b42318", title="لم يكتمل تسجيل الدخول", msg=_html.escape(str(e))),
                            mimetype="text/html")
        return Response(_OAUTH_PAGE.format(color="#067647", title="تم تسجيل الدخول بحساب Google ✔",
                                           msg="يمكنك إغلاق هذه الصفحة والعودة إلى نافذة البرنامج ولصق رابط Drive."),
                        mimetype="text/html")

    @app.get("/api/lan")
    def lan_info():
        # the phone URL to open on the same Wi-Fi (empty unless the program was started in phone mode)
        return jsonify({"url": port_holder.get("phone_url") or ""})

    @app.get("/api/init")
    def init():
        s = st.load_settings()
        prov = {k: {kk: vv for kk, vv in v.items()} for k, v in PROVIDERS.items()}
        return jsonify({"settings": s, "providers": prov, "drives": batch.list_drives(), "version": __version__,
                        "platform": sys.platform})

    @app.post("/api/settings")
    def save():
        s = st.coerce(request.get_json(force=True) or {})
        st.save_settings(s)
        return jsonify({"ok": True, "settings": s})

    @app.get("/api/drives")
    def drives():
        return jsonify(batch.list_drives())

    @app.get("/api/browse")
    def browse():
        path = request.args.get("path") or os.path.expanduser("~")
        return jsonify(batch.browse(path))

    @app.post("/api/check")
    def check():
        s = st.coerce(request.get_json(force=True) or {})
        return jsonify(system_check(s))

    @app.post("/api/tessdata")
    def tessdata():
        s = st.coerce(request.get_json(force=True) or {})
        logs = []
        t = Tesseract(s.get("tesseract_path") or None, s.get("ocr_lang"), log=logs.append)
        if not t.exe:
            return jsonify({"ok": False, "message": "Tesseract غير مثبت", "logs": logs})
        ok, msg = t.prepare(allow_download=True)
        return jsonify({"ok": ok and msg == "OK", "message": msg, "logs": logs})

    @app.post("/api/ai/test")
    def ai_test():
        s = st.coerce(request.get_json(force=True) or {})
        logs = []
        try:
            p = make_provider(s, log=logs.append)
        except AIError as e:
            return jsonify({"ok": False, "message": str(e)})
        models = []
        try:
            models = p.list_models()
        except AIError as e:
            if s.get("ai_provider") != "ollama":
                return jsonify({"ok": False, "message": str(e)})
            return jsonify({"ok": False, "message": "تعذّر الاتصال بـ Ollama. هل البرنامج مثبت ويعمل؟ " + str(e)})
        t0 = time.time()
        try:
            reply = p.generate("You are a test.", "Reply with the single word: OK", None, max_tokens=256)
        except AIError as e:
            return jsonify({"ok": False, "message": str(e), "models": models[:200]})
        vision = getattr(p, "supports_vision", False)
        desc = p.describe() if hasattr(p, "describe") else ""
        return jsonify({"ok": True, "message": f"تم الاتصال بنجاح: {desc} — {round(time.time() - t0, 1)} ث",
                        "reply": (reply or "")[:100], "vision": bool(vision), "models": models[:300], "logs": logs})

    # -- built-in OCR -----------------------------------------------------------------------
    @app.post("/api/ocr/test")
    def ocr_test():
        s = st.coerce(request.get_json(force=True) or {})
        if not ocr_embedded.installed():
            return jsonify({"ok": False, "message": "محرك OCR المدمج غير مثبت. شغّل ملف التثبيت مرة أخرى."})
        logs = []
        eng = ocr_embedded.EmbeddedOCR(s.get("ocr_lang"), log=logs.append)
        ok, msg = eng.self_test()  # the first run downloads the models (internet needed once)
        if not ok and eng.broken:
            msg = f"تعذّر تشغيل المحرك المدمج: {eng.broken}"
        return jsonify({"ok": bool(ok), "message": msg, "logs": logs})

    # -- Google Drive ----------------------------------------------------------------------
    @app.get("/api/gdrive/status")
    def gdrive_status():
        return jsonify({"configured": oauth.configured(), "signed_in": oauth.signed_in()})

    @app.post("/api/gdrive/client")
    def gdrive_client():
        data = request.get_json(force=True) or {}
        try:
            oauth.save_client(data.get("json") or "")
        except (ValueError, gdrive.DriveError) as e:
            return jsonify({"ok": False, "message": f"ملف غير صالح: {e}"})
        return jsonify({"ok": True})

    @app.post("/api/gdrive/auth_url")
    def gdrive_auth_url():
        port = port_holder.get("port") or request.host.split(":")[-1]
        try:
            url = oauth.begin(f"http://127.0.0.1:{port}/")
        except gdrive.DriveError as e:
            return jsonify({"ok": False, "message": str(e)})
        return jsonify({"ok": True, "url": url})

    @app.post("/api/gdrive/signout")
    def gdrive_signout():
        oauth.sign_out()
        return jsonify({"ok": True})

    @app.post("/api/gdrive/test")
    def gdrive_test():
        data = request.get_json(force=True) or {}
        s = st.coerce(data.get("settings") or {})
        link = (data.get("link") or "").strip()
        try:
            fx = gdrive.Fetcher(link, api_key=s["drive_api_key"], oauth=oauth)
            info = fx.resolve()
            entries = fx.list()
        except gdrive.DriveError as e:
            return jsonify({"ok": False, "message": str(e)})
        pdfs = [f for f in entries if gdrive.is_pdf_entry(f)]
        zips = [f for f in entries if gdrive.is_zip_entry(f)]
        folders = len({"/".join(f.get("path", [])) for f in entries})
        size = sum(int(f.get("size") or 0) for f in pdfs + zips)
        mode = "تسجيل الدخول" if fx.client and fx.client.mode == "oauth" else ("مفتاح API" if fx.client else "رابط عام")
        return jsonify({"ok": True, "name": info["name"], "folder": info["folder"], "pdfs": len(pdfs), "zips": len(zips),
                        "files": len(entries), "folders": folders, "mb": round(size / 1048576, 1), "mode": mode,
                        "message": f"«{info['name']}»: {len(pdfs)} ملف PDF" + (f" و{len(zips)} ملف ZIP" if zips else "")
                        + f" في {folders} مجلد ({round(size / 1048576, 1)} MB) — عبر {mode}"})

    # -- uploads (drag & drop any number of files) ------------------------------------------
    @app.post("/api/upload/new")
    def upload_new():
        sid = "ملفات_مرفوعة_" + datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        path = os.path.join(batch.uploads_dir(), sid)
        k = 2
        while os.path.exists(path):
            path = os.path.join(batch.uploads_dir(), f"{sid}_{k}")
            k += 1
        os.makedirs(path)
        return jsonify({"ok": True, "session": os.path.basename(path), "path": path})

    @app.post("/api/upload")
    def upload():
        sid = request.args.get("session", "")
        base = os.path.join(batch.uploads_dir(), sid)
        if not sid or os.path.basename(sid) != sid or sid.startswith(".") or not os.path.isdir(base):
            return jsonify({"ok": False, "message": "جلسة رفع غير صالحة"}), 400
        f = request.files.get("file")
        if f is None:
            return jsonify({"ok": False, "message": "لا يوجد ملف"}), 400
        rel = request.form.get("path") or f.filename or "file.pdf"
        parts = [gdrive.safe_name(p) for p in re.split(r"[\\/]+", rel) if p not in ("", ".", "..")]
        if not parts or not parts[-1].lower().endswith((".pdf", ".zip")):
            return jsonify({"ok": False, "message": "يُقبل PDF و ZIP فقط"}), 400
        dest = os.path.join(base, *parts[-8:])
        if not os.path.abspath(dest).startswith(os.path.abspath(base) + os.sep):
            abort(400)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        f.save(dest + ".part")
        os.replace(dest + ".part", dest)
        lm = request.form.get("lastModified")
        if lm and lm.isdigit():
            try:
                ts = int(lm) / 1000.0
                os.utime(dest, (ts, ts))
            except (OverflowError, OSError, ValueError):
                pass
        return jsonify({"ok": True})

    # -- AI package (+ analysis) from an existing folder of Word files ------------------------
    @app.post("/api/aipack")
    def aipack():
        job = state["job"]
        if job and job.running:
            return jsonify({"ok": False, "message": "يوجد عمل قيد التشغيل"}), 409
        data = request.get_json(force=True) or {}
        s = st.coerce(data.get("settings") or {})
        folder = os.path.abspath(os.path.expanduser(data.get("folder") or s["output_dir"]))
        if not os.path.isdir(folder):
            return jsonify({"ok": False, "message": "المجلد غير موجود"})
        st.save_settings(s)
        job = batch.Job([], s, pack_folder=folder)
        state["job"] = job
        job.start()
        return jsonify({"ok": True})

    @app.get("/api/claude_part")
    def claude_part():
        job = state["job"]
        try:
            i = int(request.args.get("i", "1"))
        except ValueError:
            abort(400)
        if not job or not job.pack_dir or not (1 <= i <= len(job.claude_parts)):
            return jsonify({"ok": False, "message": "لا يوجد ملف جاهز"}), 404
        path = os.path.join(job.pack_dir, job.claude_parts[i - 1])
        with open(path, encoding="utf-8") as f:
            text = f.read()
        return jsonify({"ok": True, "text": text, "file": path, "parts": len(job.claude_parts)})

    @app.post("/api/start")
    def start():
        job = state["job"]
        if job and job.running:
            return jsonify({"ok": False, "message": "يوجد تحويل قيد التشغيل"}), 409
        data = request.get_json(force=True) or {}
        sources = [p for p in data.get("sources", []) if isinstance(p, str) and p.strip()]
        if not sources:
            return jsonify({"ok": False, "message": "اختر قرصاً أو مجلداً أو أضف رابط Drive أولاً"}), 400
        s = st.coerce(data.get("settings") or {})
        st.save_settings(s)
        job = batch.Job(sources, s)
        state["job"] = job
        job.start()
        return jsonify({"ok": True})

    @app.post("/api/stop")
    def stop():
        if state["job"]:
            state["job"].stop()
        return jsonify({"ok": True})

    @app.get("/api/status")
    def status():
        job = state["job"]
        if not job:
            return jsonify({"phase": "idle", "logs": []})
        since = int(request.args.get("since") or 0)
        return jsonify(job.snapshot(since))

    @app.post("/api/open")
    def open_path():
        data = request.get_json(force=True) or {}
        path = data.get("path") or ""
        if data.get("make"):
            try:
                os.makedirs(path, exist_ok=True)
            except OSError:
                pass
        try:
            return jsonify({"ok": _open_path(path, bool(data.get("reveal")))})
        except Exception as e:
            return jsonify({"ok": False, "message": str(e)})

    @app.post("/api/quit")
    def quit_app():
        if state["job"]:
            state["job"].stop()
        threading.Timer(0.5, lambda: os._exit(0)).start()
        return jsonify({"ok": True})

    return app


def find_port(preferred=8765):
    for port in [preferred] + list(range(preferred + 1, preferred + 40)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sk:
            try:
                sk.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sk:
        sk.bind(("127.0.0.1", 0))
        return sk.getsockname()[1]


def _lan_ip():
    """This machine's IP on the local network (no packet is actually sent)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if not ip.startswith("127."):
            return ip
    except OSError:
        pass
    try:
        ip = socket.gethostbyname(socket.gethostname())
        return ip if not ip.startswith("127.") else None
    except OSError:
        return None


def run_server(port=None, open_browser=True, lan=False):
    token = secrets.token_urlsafe(18)
    port = port or find_port()
    url = f"http://127.0.0.1:{port}/"
    bind, hosts, phone_url = "127.0.0.1", set(), ""
    if lan:
        ip = _lan_ip()
        if ip:
            bind = "0.0.0.0"
            hosts = {ip}
            phone_url = f"http://{ip}:{port}/"
    app = create_app(token, {"port": port, "hosts": hosts, "phone_url": phone_url})
    print("=" * 64)
    print("  PDF2Word AI " + __version__ + "  —  by Boutib Ahmed / بوطيب أحمد")
    print("  The interface is open in your browser:  " + url)
    if lan and phone_url:
        print("  On your phone (same Wi-Fi), open:       " + phone_url)
        print("  then Chrome menu -> Add to Home screen for an app icon.")
    elif lan:
        print("  (could not detect this computer's Wi-Fi address; phone access unavailable)")
    print("  Keep this window open while converting. Close it to quit.")
    print("=" * 64, flush=True)
    if open_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    import logging
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    app.run(host=bind, port=port, threaded=True, use_reloader=False, debug=False)
