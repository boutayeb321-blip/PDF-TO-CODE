# -*- coding: utf-8 -*-
"""AI-ready package: the converted documents as compact Markdown that an AI assistant can read
with as few tokens as possible (no layout noise, no repeated headers/footers, duplicates removed,
an index first, then the text split into parts of a chosen size)."""
from __future__ import annotations

import hashlib
import json
import os
import re
import unicodedata
from collections import Counter
from datetime import datetime

from docx import Document

from . import textutils as tu

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_PAGE_NO = re.compile(r"^\W*(?:page|صفحة|الصفحة|ص)?\s*[\d٠-٩]{1,4}(?:\s*(?:of|من|/)\s*[\d٠-٩]{1,4})?\W*$", re.I)


def estimate_tokens(text: str) -> int:
    """Rough token count (Arabic costs more tokens per character than English)."""
    ar = lat = dig = other = 0
    for ch in text:
        if ch.isspace():
            continue
        b = unicodedata.bidirectional(ch)
        if b in ("AL", "R"):
            ar += 1
        elif ch.isascii() and ch.isalpha():
            lat += 1
        elif ch.isdigit():
            dig += 1
        else:
            other += 1
    return int(ar / 2.4 + lat / 4.0 + dig / 2.5 + other / 1.5) + 1


def _clean(text: str, strip_tashkeel: bool) -> str:
    t = tu.normalize_text(text).replace("ـ", "")
    if strip_tashkeel:
        t = tu.strip_diacritics(t)
    t = re.sub(r"[ \t ]+", " ", t)
    t = re.sub(r" *\n *", "\n", t)
    return t.strip()


def _heading_levels(doc):
    levels = {}
    try:
        for st in doc.styles:
            name = (getattr(st, "name", "") or "").lower()
            m = re.search(r"(?:heading|عنوان)\s*(\d)", name)
            if m and getattr(st, "style_id", None):
                levels[st.style_id] = int(m.group(1))
            elif name == "title" and getattr(st, "style_id", None):
                levels[st.style_id] = 1
    except Exception:
        pass
    return levels


def read_docx(path):
    """Return (meta, pages) where pages = [[(kind, value), ...], ...].
    kinds: h=(level, text)  p=text  t=rows  img=count"""
    doc = Document(path)
    meta = {}
    m = re.search(r"PDF2Word AI (\{.*\})", doc.core_properties.comments or "", re.S)
    if m:
        try:
            meta = json.loads(m.group(1))
        except ValueError:
            meta = {}
    levels = _heading_levels(doc)
    body = doc.element.body
    sect_types = []
    for sp in body.iter(W + "sectPr"):
        t = sp.find(W + "type")
        sect_types.append(t.get(W + "val") if t is not None else "nextPage")
    pages = [[]]
    sect_idx = 0
    started = [False]

    def new_page():
        # every page break starts a page (blank pages keep the page numbers right),
        # except a break before any content at all
        if started[0] or pages[-1]:
            pages.append([])
        started[0] = True

    for el in body.iterchildren():
        if el.tag == W + "p":
            ppr = el.find(W + "pPr")
            if ppr is not None:
                pb = ppr.find(W + "pageBreakBefore")
                if pb is not None and pb.get(W + "val", "1") not in ("0", "false"):
                    new_page()
            parts, imgs = [], 0
            for node in el.iter():
                tag = node.tag
                if tag == W + "t" and node.text:
                    parts.append(node.text)
                elif tag == W + "tab":
                    parts.append(" ")
                elif tag == W + "br":
                    if node.get(W + "type") == "page":
                        text = "".join(parts).strip()
                        if text:
                            pages[-1].append(("p", text))
                        parts = []
                        new_page()
                    else:
                        parts.append("\n")
                elif tag.endswith("}drawing") or tag.endswith("}pict"):
                    imgs += 1
            text = "".join(parts).strip()
            lvl = 0
            if ppr is not None:
                ps = ppr.find(W + "pStyle")
                if ps is not None:
                    lvl = levels.get(ps.get(W + "val"), 0)
            if text:
                pages[-1].append(("h", (lvl, text)) if lvl else ("p", text))
            if imgs:
                pages[-1].append(("img", imgs))
            if ppr is not None and ppr.find(W + "sectPr") is not None:
                sect_idx += 1
                nxt = sect_types[sect_idx] if sect_idx < len(sect_types) else "nextPage"
                if nxt in ("nextPage", "oddPage", "evenPage"):
                    new_page()
        elif el.tag == W + "tbl":
            rows = []
            for tr in el.findall(W + "tr"):
                cells = []
                for tc in tr.findall(W + "tc"):
                    cells.append(" ".join("".join(t.text or "" for t in p.iter(W + "t")).strip() for p in tc.findall(W + "p")).strip())
                if any(cells):
                    rows.append(cells)
            if rows:
                pages[-1].append(("t", rows))
    while len(pages) > 1 and not pages[-1]:
        pages.pop()
    return meta, pages


def _block_text(b):
    if b[0] == "h":
        return b[1][1]
    if b[0] == "p":
        return b[1]
    return ""


def strip_running(pages):
    """Remove running headers/footers and page numbers."""
    n = len(pages)

    def key(t):
        return re.sub(r"[\d٠-٩]+", "#", tu.normalize_for_compare(t))

    repeated = set()
    if n >= 3:
        cnt = Counter()
        for pg in pages:
            texts = [b for b in pg if b[0] in ("p", "h")]
            seen = set()
            for b in texts[:2] + texts[-2:]:
                k = key(_block_text(b))
                if 0 < len(k) <= 100 and k not in seen:
                    cnt[k] += 1
                    seen.add(k)
        repeated = {k for k, c in cnt.items() if c >= max(3, 0.5 * n)}
    out = []
    removed = 0
    for pg in pages:
        texts_idx = [i for i, b in enumerate(pg) if b[0] in ("p", "h")]
        edge = set(texts_idx[:2] + texts_idx[-2:])
        keep = []
        for i, b in enumerate(pg):
            t = _block_text(b)
            if b[0] in ("p", "h") and (_PAGE_NO.match(t) or (i in edge and key(t) in repeated)):
                removed += 1
                continue
            keep.append(b)
        out.append(keep)
    return out, removed


def to_markdown(pages, strip_tashkeel=False, page_marks=True):
    lines = []
    multi = len(pages) > 1
    for pi, pg in enumerate(pages, 1):
        if multi and page_marks:
            lines.append(f"[ص{pi}]")
        pending_img = 0
        for b in pg:
            if b[0] == "img":
                pending_img += b[1]
                continue
            if pending_img:
                lines.append("[صورة]" if pending_img == 1 else f"[{pending_img} صور]")
                pending_img = 0
            if b[0] == "h":
                lvl, t = b[1]
                t = _clean(t, strip_tashkeel)
                if t:
                    lines.append("#" * min(3, max(1, lvl)) + " " + t.replace("\n", " "))
            elif b[0] == "p":
                t = _clean(b[1], strip_tashkeel)
                if t:
                    lines.append(t)
            elif b[0] == "t":
                rows = [[_clean(c, strip_tashkeel).replace("\n", " ").replace("|", "/") for c in r] for r in b[1]]
                width = max(len(r) for r in rows)
                if width == 1:
                    lines.extend(r[0] for r in rows if r[0])
                else:
                    lines.extend("| " + " | ".join(r + [""] * (width - len(r))) + " |" for r in rows)
        if pending_img:
            lines.append("[صورة]" if pending_img == 1 else f"[{pending_img} صور]")
    return "\n".join(lines).strip()


def _ranges(nums):
    nums = sorted(set(int(n) for n in nums))
    out, start, prev = [], None, None
    for n in nums:
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            out.append(f"{start}" if start == prev else f"{start}-{prev}")
            start = prev = n
    if start is not None:
        out.append(f"{start}" if start == prev else f"{start}-{prev}")
    return "،".join(out)


def _slug(s, n=40):
    s = re.sub(r"[^\w؀-ۿ]+", "_", s).strip("_")
    return (s[:n] or "doc")


ANALYSIS_NAME = re.compile(r"^(?:تحليل|Analysis)_.+_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}\.docx$")


def collect_docx(folder):
    out = []
    for dp, dn, files in os.walk(folder):
        dn[:] = [d for d in dn if not d.startswith(("AI_READY", "_drive", "."))]
        for f in sorted(files):
            if f.lower().endswith(".docx") and not f.startswith(("~$", ".")) and ".~tmp" not in f and not ANALYSIS_NAME.match(f):
                full = os.path.join(dp, f)
                out.append({"docx": full, "source": os.path.relpath(full, folder)})
    return out


def build_pack(entries, out_dir, part_tokens=100_000, strip_tashkeel=False, log=None, title="الأرشيف", task_prompt="",
               task_lang="ar"):
    """entries: [{"docx": path, "source": display name, "report": optional dict}] -> writes pack."""
    log = log or (lambda *_: None)
    os.makedirs(os.path.join(out_dir, "docs"), exist_ok=True)
    docs, seen_hash = [], {}
    for k, e in enumerate(entries, 1):
        try:
            meta, pages = read_docx(e["docx"])
        except Exception as ex:
            log(f"تخطي {e.get('source')}: تعذّرت قراءته ({ex})")
            continue
        pages, removed = strip_running(pages)
        md = to_markdown(pages, strip_tashkeel)
        if not md.strip():
            continue
        h = hashlib.sha1(tu.normalize_for_compare(re.sub(r"\[ص\d+\]", "", md)).encode("utf-8")).hexdigest()
        rep = e.get("report") or {}
        review = rep.get("review_pages") or meta.get("review") or []
        ocr_pages = meta.get("ocr_pages") or []
        first = next((b for pg in pages for b in pg if b[0] in ("h", "p")), None)
        heading = next((b for pg in pages[:2] for b in pg if b[0] == "h"), None)
        ttl = _block_text(heading or first) if (heading or first) else os.path.splitext(os.path.basename(e["docx"]))[0]
        ttl = _clean(ttl, False).replace("\n", " ")[:90]
        plain = re.sub(r"\[ص\d+\]|\[\d* ?صور?ة?\]", " ", md)
        d = {"n": len(docs) + 1, "source": e.get("source") or os.path.basename(e["docx"]), "docx": e["docx"],
             "pages": len(pages), "words": len(plain.split()), "tokens": estimate_tokens(md),
             "lang": "ar" if tu.arabic_ratio(plain) >= 0.5 else "en", "title": ttl, "ocr_pages": ocr_pages,
             "review_pages": review, "uncertain": md.count("[؟]"), "duplicate_of": seen_hash.get(h), "md": None,
             "removed_running": removed, "_md": md}
        if d["duplicate_of"] is None:
            seen_hash[h] = d["n"]
        docs.append(d)
    uniq = [d for d in docs if d["duplicate_of"] is None]
    # per-document files
    for d in uniq:
        notes = []
        if d["ocr_pages"]:
            notes.append("قراءة ضوئية: ص" + _ranges(d["ocr_pages"]))
        if d["review_pages"]:
            notes.append("تحتاج مراجعة: ص" + _ranges(d["review_pages"]))
        if d["uncertain"]:
            notes.append(f"{d['uncertain']} كلمة غير مقروءة [؟]")
        head = f"## [{d['n']}] {d['title']}\n> {d['source']} · {d['pages']} ص" + (" · " + " · ".join(notes) if notes else "")
        d["_full"] = head + "\n" + d["_md"]
        name = f"{d['n']:04d}_{_slug(os.path.splitext(os.path.basename(d['source']))[0])}.md"
        d["md"] = "docs/" + name
        with open(os.path.join(out_dir, "docs", name), "w", encoding="utf-8") as f:
            f.write(d["_full"] + "\n")
    # parts ready for Claude (instructions + documents in compact tags)
    def tag(d, body, part=None):
        a = f'n="{d["n"]}" src="{_attr(d["source"])}" pages="{d["pages"]}"'
        if part:
            a += f' part="{part}"'
        if d["ocr_pages"]:
            a += f' ocr="{_ranges(d["ocr_pages"])}"'
        if d["review_pages"]:
            a += f' review="{_ranges(d["review_pages"])}"'
        if d["uncertain"]:
            a += f' unread="{d["uncertain"]}"'
        return f"<doc {a}>\n{body.strip()}\n</doc>"

    parts, cur, cur_tok = [], [], 0
    budget = max(int(part_tokens * 0.5), part_tokens - 700)  # room for the instructions
    for d in uniq:
        full = tag(d, d["_md"])
        t = estimate_tokens(full)
        if cur and cur_tok + t > budget:
            parts.append(cur)
            cur, cur_tok = [], 0
        if t > budget:  # a very long document is split at page markers
            chunks = re.split(r"(?=\n\[ص\d+\]\n)", "\n" + d["_md"])
            pieces, buf, btok = [], "", 0
            for ch in chunks:
                ct = estimate_tokens(ch)
                if buf and btok + ct > budget:
                    pieces.append(buf)
                    buf, btok = "", 0
                buf += ch
                btok += ct
            if buf.strip():
                pieces.append(buf)
            for k, pc in enumerate(pieces, 1):
                txt = tag(d, pc, f"{k}/{len(pieces)}")
                if k < len(pieces):
                    parts.append(cur + [(d, txt)] if cur else [(d, txt)])
                    cur, cur_tok = [], 0
                else:
                    cur, cur_tok = [(d, txt)], estimate_tokens(txt)
            continue
        cur.append((d, full))
        cur_tok += t
    if cur:
        parts.append(cur)
    part_files = []
    for pi, part in enumerate(parts, 1):
        name = f"CLAUDE_part{pi:02d}.md"
        nums = sorted({d["n"] for d, _ in part})
        header = claude_task(pi, len(parts), nums, len(uniq), task_prompt, task_lang)
        with open(os.path.join(out_dir, name), "w", encoding="utf-8") as f:
            f.write(header + "\n\n" + "\n\n".join(txt for _, txt in part) + "\n")
        tok = estimate_tokens(header) + sum(estimate_tokens(txt) for _, txt in part)
        part_files.append({"file": name, "docs": nums, "tokens": tok})
        for d, _ in part:
            d.setdefault("part", pi)
    total_tok = sum(d["tokens"] for d in uniq)
    dups = [d for d in docs if d["duplicate_of"] is not None]
    manifest = {"generated": datetime.now().isoformat(timespec="seconds"), "title": title, "documents": [
        {k: v for k, v in d.items() if not k.startswith("_") and k != "docx"} for d in docs], "parts": part_files,
        "total_tokens_estimate": total_tok, "strip_tashkeel": strip_tashkeel}
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)
    write_index(out_dir)
    log(f"جُهّزت النسخة المختصرة للذكاء الاصطناعي: {len(uniq)} مستند، ≈{total_tok:,} توكن في {len(part_files)} جزء.")
    return {"dir": out_dir, "docs": len(uniq), "duplicates": len(dups), "tokens": total_tok, "parts": len(part_files)}


def _attr(s):
    return str(s or "").replace('"', "'").replace("\n", " ")


def claude_task(k, n_parts, nums, total_docs, custom="", lang="ar"):
    """Instructions at the top of every CLAUDE_partNN.md, so the file can be handed over as is."""
    lang_line = {"en": "اكتب التحليل باللغة الإنجليزية.", "auto": "اكتب تحليل كل مستند بلغته."}.get(lang, "اكتب التحليل باللغة العربية.")
    overall = "نظرة عامة · الموضوعات المشتركة · جدول مقارنة بين المستندات · خط زمني · تناقضات واختلافات · أهم النتائج والتوصيات"
    step = 3 if custom else 2
    L = ["<task>",
         f"هذا الملف من برنامج PDF2Word AI: نص {len(nums)} مستند (من رقم {nums[0]} إلى {nums[-1]}، من أصل {total_docs}) — "
         f"الجزء {k} من {n_parts}. حولت من PDF واختصرت لتوفير التوكنز.",
         "الرموز: [صN] بداية الصفحة N في الملف الأصلي · [صورة] صورة لم تنقل نصيا · [؟] كلمة غير مقروءة · "
         "السطور التي تبدأ بـ | جداول · سمات <doc>: ocr صفحات مقروءة ضوئيا، review صفحات تحتاج مراجعة، unread عدد الكلمات غير المقروءة.",
         "إذا لم يطلب المستخدم شيئا آخر مع هذا الملف، فحلل المستندات هكذا:",
         "1) لكل مستند: في سطر واحد · الملخص · النقاط الرئيسية · الأشخاص والجهات والأماكن · التواريخ والأرقام المهمة · "
         "الموضوعات والتصنيف · ملاحظات وأسئلة مفتوحة."]
    if custom:
        L.append("2) المطلوب تحديداً (نفذه لكل مستند وللمجموعة كلها): " + custom.strip())
    if n_parts == 1:
        L.append(f"{step}) ثم تقرير شامل لكل المستندات: {overall}.")
    elif k < n_parts:
        L.append(f"{step}) هذا الجزء {k} من {n_parts}: حلل مستنداته فقط، واحتفظ بالنتائج، واترك التقرير الشامل إلى أن يصل الجزء الأخير.")
    else:
        L.append(f"{step}) هذا الجزء الأخير: حلل مستنداته، ثم اكتب التقرير الشامل لكل الأجزاء: {overall}.")
    L.append("القواعد: اعتمد على النص المرفق فقط دون معلومات من خارجه، واختم كل نقطة بمصدرها [#رقم المستند صرقم الصفحة]، "
             "وانسخ الأرقام والأسماء كما وردت، ونبه إلى الكلمات [؟] والصفحات التي تحتاج مراجعة.")
    L.append(lang_line + " واكتب الناتج في مستند مرتب.")
    L.append("</task>")
    return "\n".join(L)


def write_index(out_dir):
    """(Re)write INDEX.md from manifest.json (also after the analysis adds one-line summaries)."""
    with open(os.path.join(out_dir, "manifest.json"), encoding="utf-8") as f:
        man = json.load(f)
    docs = man["documents"]
    title = man.get("title") or "الأرشيف"
    uniq = [d for d in docs if not d.get("duplicate_of")]
    dups = len(docs) - len(uniq)
    total_tok = man.get("total_tokens_estimate", 0)
    has_sum = any(d.get("summary") for d in docs)
    has_an = os.path.exists(os.path.join(out_dir, "ANALYSIS.md"))
    first = man["parts"][0]["file"] if man.get("parts") else "CLAUDE_part01.md"
    L = [f"# فهرس {title} (نسخة مختصرة للتحليل بالذكاء الاصطناعي)", "",
         f"المستندات: {len(uniq)} · الصفحات: {sum(int(d.get('pages') or 0) for d in uniq)} · الحجم التقريبي: ≈{total_tok:,} توكن"
         + (f" · {dups} ملف مكرر لم يُكرَّر نصه" if dups else ""),
         f"أُنشئ: {man.get('generated', '')[:16].replace('T', ' ')}", "",
         "طريقة الاستخدام مع Claude:",
         f"- للتحليل الكامل: أرسل {first} (ثم الأجزاء التالية بالترتيب إن وُجدت). فيه التعليمات والنص معاً، فيبدأ التحليل مباشرة.",
         "- لسؤال محدد: أرسل هذا الفهرس، ثم ملف المستند من مجلد docs، واكتب سؤالك.",
         "- لتحليل سريع بأقل التوكنز: أرسل ANALYSIS.md (التحليل الآلي الجاهز) وحده." if has_an else
         "- فعّل «تحليل المحتوى» في البرنامج ليُضاف ملف ANALYSIS.md: تحليل جاهز يمكن إرساله وحده بأقل التوكنز.",
         "[صN] = بداية الصفحة N في الملف الأصلي، [صورة] = صورة لم تُنقل نصياً، [؟] = كلمة غير مقروءة.", ""]
    cols = ["#", "الملف", "ص", "كلمات", "توكن≈", "لغة", "الملخص" if has_sum else "العنوان", "ملاحظات", "الجزء"]
    L += ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for d in docs:
        if d.get("duplicate_of"):
            L.append(f"| {d['n']} | {d['source']} | {d['pages']} | — | — | {d.get('lang', '')} | (نسخة مكررة من #{d['duplicate_of']}) | | |")
            continue
        notes = []
        if d.get("review_pages"):
            notes.append("مراجعة ص" + _ranges(d["review_pages"]))
        if d.get("ocr_pages"):
            notes.append("OCR")
        label = (d.get("summary") or d.get("title") or "") if has_sum else (d.get("title") or "")
        L.append(f"| {d['n']} | {d['source']} | {d['pages']} | {d.get('words', 0):,} | {d.get('tokens', 0):,} | {d.get('lang', '')} | "
                 f"{label.replace('|', '/')} | {'، '.join(notes)} | {d.get('part', '')} |")
    L += ["", "## الأجزاء"]
    for p in man.get("parts", []):
        L.append(f"- {p['file']}: المستندات {p['docs'][0]}–{p['docs'][-1]} (≈{p['tokens']:,} توكن)")
    with open(os.path.join(out_dir, "INDEX.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
