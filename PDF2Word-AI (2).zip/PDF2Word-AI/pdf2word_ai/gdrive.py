# -*- coding: utf-8 -*-
"""Google Drive links: walk every sub-folder (no 50-file limit, any number of files) and
download the PDFs, using the official Drive API with either

* an API key  -> folders shared as "anyone with the link", or
* Google sign-in (OAuth, read-only) -> any folder your account can open.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

from .ocr import app_data_dir

API = "https://www.googleapis.com/drive/v3"
AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
USERCONTENT = "https://drive.usercontent.google.com/download"
SCOPE = "https://www.googleapis.com/auth/drive.readonly"
FOLDER = "application/vnd.google-apps.folder"
SHORTCUT = "application/vnd.google-apps.shortcut"
NATIVE = "application/vnd.google-apps."
FIELDS = "id,name,mimeType,size,md5Checksum,modifiedTime,resourceKey,shortcutDetails(targetId,targetMimeType,targetResourceKey)"


def _ep(name, default):
    """Endpoints can be redirected (tests / proxies) with environment variables."""
    return os.environ.get(name) or default


class DriveError(Exception):
    pass


class DriveAuthError(DriveError):
    pass


class DriveNotFound(DriveError):
    pass


# ----------------------------------------------------------------------------------------------
# Links and names
# ----------------------------------------------------------------------------------------------
_ID = r"[A-Za-z0-9_-]{10,}"


def is_drive_link(text: str) -> bool:
    t = (text or "").strip()
    return bool(re.search(r"(drive|docs)\.google\.com|drive\.usercontent\.google\.com", t)) or t.lower().startswith("gdrive:")


def parse_link(text: str):
    """Return {"id", "kind": folder|file|doc|unknown, "resource_key"} or None."""
    s = (text or "").strip()
    if s.lower().startswith("gdrive:"):
        s = s[7:].strip()
    rk = None
    m = re.search(r"[?&]resourcekey=([^&#\s]+)", s, re.I)
    if m:
        rk = urllib.parse.unquote(m.group(1))
    pats = [
        (rf"/folders/({_ID})", "folder"),
        (rf"/file/d/({_ID})", "file"),
        (rf"/(?:document|spreadsheets|presentation|drawings)/d/({_ID})", "doc"),
        (rf"[?&]id=({_ID})", "unknown"),
    ]
    for pat, kind in pats:
        m = re.search(pat, s)
        if m:
            return {"id": m.group(1), "kind": kind, "resource_key": rk}
    if re.fullmatch(_ID, s):
        return {"id": s, "kind": "unknown", "resource_key": rk}
    return None


_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}


def safe_name(name: str, maxlen: int = 120) -> str:
    n = _BAD.sub("_", (name or "").strip()).rstrip(". ")
    if not n:
        n = "_"
    stem, ext = os.path.splitext(n)
    if stem.upper() in _RESERVED:
        stem = "_" + stem
    if len(stem) + len(ext) > maxlen:
        stem = stem[: max(1, maxlen - len(ext))].rstrip(". ")
    return stem + ext


# ----------------------------------------------------------------------------------------------
# Google sign-in (OAuth 2.0 for installed apps, PKCE, loopback redirect)
# ----------------------------------------------------------------------------------------------
class OAuth:
    def __init__(self, client_file=None, token_file=None, auth_url=None, token_url=None):
        base = app_data_dir()
        self.client_file = client_file or os.path.join(base, "gdrive_client.json")
        self.token_file = token_file or os.path.join(base, "gdrive_token.json")
        self.auth_url = auth_url or _ep("PDF2WORD_GOOGLE_AUTH", AUTH_URL)
        self.token_url = token_url or _ep("PDF2WORD_GOOGLE_TOKEN", TOKEN_URL)
        self._pending = {}
        self._lock = threading.Lock()

    @staticmethod
    def parse_client(data):
        if isinstance(data, (str, bytes)):
            data = json.loads(data)
        sec = data.get("installed") or data.get("web") or data
        cid, csec = sec.get("client_id"), sec.get("client_secret")
        if not cid:
            raise DriveAuthError("ملف بيانات الاعتماد غير صالح (لا يحتوي client_id)")
        return {"client_id": cid, "client_secret": csec or ""}

    def save_client(self, data):
        c = self.parse_client(data)
        with open(self.client_file, "w", encoding="utf-8") as f:
            json.dump(c, f)
        return c

    def client(self):
        try:
            with open(self.client_file, encoding="utf-8") as f:
                return self.parse_client(f.read())
        except (OSError, ValueError, DriveAuthError):
            return None

    def configured(self) -> bool:
        return self.client() is not None

    def _load_token(self):
        try:
            with open(self.token_file, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return None

    def _save_token(self, tok):
        tmp = self.token_file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(tok, f)
        os.replace(tmp, self.token_file)

    def signed_in(self) -> bool:
        t = self._load_token()
        return bool(t and (t.get("refresh_token") or t.get("access_token")))

    def begin(self, redirect_uri):
        c = self.client()
        if not c:
            raise DriveAuthError("أضف ملف بيانات اعتماد Google (OAuth client) أولاً")
        verifier = base64.urlsafe_b64encode(secrets.token_bytes(48)).rstrip(b"=").decode()
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        state = secrets.token_urlsafe(24)
        with self._lock:
            self._pending[state] = (verifier, redirect_uri, time.time())
        q = {"client_id": c["client_id"], "redirect_uri": redirect_uri, "response_type": "code", "scope": SCOPE,
             "access_type": "offline", "prompt": "consent", "state": state, "code_challenge": challenge,
             "code_challenge_method": "S256"}
        return self.auth_url + "?" + urllib.parse.urlencode(q)

    def _post(self, data):
        req = urllib.request.Request(self.token_url, data=urllib.parse.urlencode(data).encode(), method="POST",
                                     headers={"Content-Type": "application/x-www-form-urlencoded"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")
            raise DriveAuthError(f"رفضت Google تسجيل الدخول: {body[:300]}")
        except urllib.error.URLError as e:
            raise DriveError(f"تعذّر الاتصال بـ Google: {e.reason}")

    def finish(self, code, state):
        with self._lock:
            pend = self._pending.pop(state, None)
        if not pend:
            raise DriveAuthError("طلب تسجيل دخول غير معروف أو منتهي. أعد المحاولة.")
        verifier, redirect_uri, _ = pend
        c = self.client()
        tok = self._post({"code": code, "client_id": c["client_id"], "client_secret": c["client_secret"],
                          "redirect_uri": redirect_uri, "grant_type": "authorization_code", "code_verifier": verifier})
        tok["expires_at"] = time.time() + float(tok.get("expires_in", 3600)) - 60
        self._save_token(tok)
        return True

    def access_token(self):
        t = self._load_token()
        if not t:
            raise DriveAuthError("غير مسجّل الدخول بحساب Google")
        if t.get("access_token") and time.time() < float(t.get("expires_at", 0)):
            return t["access_token"]
        if not t.get("refresh_token"):
            raise DriveAuthError("انتهت صلاحية تسجيل الدخول. سجّل الدخول مرة أخرى.")
        c = self.client()
        if not c:
            raise DriveAuthError("ملف بيانات اعتماد Google مفقود")
        new = self._post({"client_id": c["client_id"], "client_secret": c["client_secret"],
                          "refresh_token": t["refresh_token"], "grant_type": "refresh_token"})
        t["access_token"] = new["access_token"]
        t["expires_at"] = time.time() + float(new.get("expires_in", 3600)) - 60
        if new.get("refresh_token"):
            t["refresh_token"] = new["refresh_token"]
        self._save_token(t)
        return t["access_token"]

    def invalidate(self):
        t = self._load_token()
        if t:
            t["expires_at"] = 0
            self._save_token(t)

    def sign_out(self):
        try:
            os.remove(self.token_file)
        except OSError:
            pass


# ----------------------------------------------------------------------------------------------
# Drive API client
# ----------------------------------------------------------------------------------------------
class DriveClient:
    def __init__(self, api_key=None, oauth=None, base=None, usercontent=None, log=None, timeout=90):
        self.key = (api_key or "").strip() or None
        self.oauth = oauth if (oauth is not None and oauth.signed_in()) else None
        self.base = (base or _ep("PDF2WORD_DRIVE_API", API)).rstrip("/")
        self.usercontent = usercontent or _ep("PDF2WORD_DRIVE_USERCONTENT", USERCONTENT)
        self.log = log or (lambda *_: None)
        self.timeout = timeout
        if not self.key and not self.oauth:
            raise DriveAuthError("لقراءة مجلد Drive أضف «مفتاح Google Drive API» أو سجّل الدخول بحساب Google من الإعدادات")

    @property
    def mode(self):
        return "oauth" if self.oauth else "key"

    def _headers(self, rkeys=None):
        h = {"User-Agent": "PDF2Word-AI/1.1"}
        if self.oauth:
            h["Authorization"] = "Bearer " + self.oauth.access_token()
        if rkeys:
            h["X-Goog-Drive-Resource-Keys"] = ",".join(f"{i}/{k}" for i, k in rkeys.items() if k)
        return h

    def _url(self, path, params=None):
        p = dict(params or {})
        if self.key and not self.oauth:
            p["key"] = self.key
        url = path if path.startswith("http") else self.base + path
        return url + ("?" + urllib.parse.urlencode(p) if p else "")

    @staticmethod
    def _reason(body):
        try:
            j = json.loads(body)
            err = j.get("error", {})
            reasons = [e.get("reason", "") for e in err.get("errors", []) if isinstance(e, dict)]
            for d in err.get("details", []) or []:
                if isinstance(d, dict) and d.get("reason"):
                    reasons.append(d["reason"])
            return (reasons[0] if reasons else err.get("status", "")), err.get("message", body[:200])
        except Exception:
            return "", body[:200]

    def _open(self, url, rkeys=None, stop=None):
        """Open a URL with retries. Returns the response object (caller closes it)."""
        delay = 2.0
        refreshed = False
        for attempt in range(8):
            if stop is not None and stop.is_set():
                raise DriveError("أُوقف")
            req = urllib.request.Request(url, headers=self._headers(rkeys))
            try:
                return urllib.request.urlopen(req, timeout=self.timeout)
            except urllib.error.HTTPError as e:
                body = e.read().decode("utf-8", "replace") if e.fp else ""
                reason, msg = self._reason(body)
                if e.code == 401 and self.oauth and not refreshed:
                    self.oauth.invalidate()
                    refreshed = True
                    continue
                if e.code in (400, 401) and re.search(r"API key|keyInvalid|API_KEY", body, re.I):
                    raise DriveAuthError("مفتاح Google Drive API غير صالح")
                if e.code == 403 and (reason in ("accessNotConfigured", "SERVICE_DISABLED") or "has not been used" in msg or "is disabled" in msg):
                    raise DriveAuthError("خدمة Google Drive API غير مفعّلة لهذا المفتاح. فعّلها من Google Cloud Console")
                if e.code == 404:
                    raise DriveNotFound("غير موجود أو غير مشارك معك (تحقق من الرابط وصلاحية المشاركة)")
                if e.code == 429 or reason in ("rateLimitExceeded", "userRateLimitExceeded", "RATE_LIMIT_EXCEEDED") or e.code >= 500:
                    ra = e.headers.get("Retry-After") if e.headers else None
                    wait = float(ra) if ra and ra.replace(".", "", 1).isdigit() else delay
                    time.sleep(min(60.0, wait))
                    delay = min(60.0, delay * 2)
                    continue
                if e.code == 403:
                    if reason == "downloadQuotaExceeded":
                        raise DriveError("تجاوز الملف حد التنزيل في Google Drive (حاول لاحقاً)")
                    if reason in ("cannotDownloadFile", "cannotCopyFile"):
                        raise DriveError("صاحب الملف منع التنزيل")
                    if reason == "cannotDownloadAbusiveFile":
                        raise DriveError("Google وسمت الملف كملف خطر ومنعت تنزيله")
                    if reason in ("dailyLimitExceeded", "quotaExceeded"):
                        raise DriveAuthError("انتهت حصة Google Drive API اليومية لهذا المفتاح")
                    raise DriveError(f"لا توجد صلاحية للوصول ({reason or msg})")
                raise DriveError(f"HTTP {e.code}: {msg}")
            except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
                if attempt >= 5:
                    raise DriveError(f"تعذّر الاتصال بـ Google Drive: {getattr(e, 'reason', e)}")
                time.sleep(delay)
                delay = min(60.0, delay * 2)
        raise DriveError("فشل الطلب بعد عدة محاولات")

    def _json(self, path, params=None, rkeys=None, stop=None):
        with self._open(self._url(path, params), rkeys, stop) as r:
            return json.loads(r.read().decode("utf-8"))

    def meta(self, fid, rk=None):
        return self._json(f"/files/{fid}", {"fields": FIELDS, "supportsAllDrives": "true"}, {fid: rk} if rk else None)

    def children(self, fid, rk=None, stop=None):
        token = None
        while True:
            p = {"q": f"'{fid}' in parents and trashed = false", "fields": f"nextPageToken,files({FIELDS})",
                 "pageSize": 1000, "supportsAllDrives": "true", "includeItemsFromAllDrives": "true"}
            if token:
                p["pageToken"] = token
            j = self._json("/files", p, {fid: rk} if rk else None, stop)
            for f in j.get("files", []):
                yield f
            token = j.get("nextPageToken")
            if not token:
                break

    def walk(self, fid, rk=None, stop=None, on_progress=None):
        """All files below a folder (recursive). Each entry gets 'path': list of folder names."""
        out = []
        seen = {fid}
        queue = [(fid, rk, [])]
        folders = 0
        while queue:
            if stop is not None and stop.is_set():
                break
            cur, crk, path = queue.pop(0)
            folders += 1
            for f in self.children(cur, crk, stop):
                mime = f.get("mimeType", "")
                if mime == SHORTCUT:
                    sd = f.get("shortcutDetails") or {}
                    tid, tmime = sd.get("targetId"), sd.get("targetMimeType", "")
                    if not tid:
                        continue
                    trk = sd.get("targetResourceKey")
                    if tmime == FOLDER:
                        if tid not in seen:
                            seen.add(tid)
                            queue.append((tid, trk, path + [f.get("name", tid)]))
                        continue
                    try:
                        target = self.meta(tid, trk)
                    except DriveError:
                        continue
                    target["name"] = f.get("name") or target.get("name")
                    f = target
                    mime = f.get("mimeType", "")
                if mime == FOLDER:
                    if f["id"] not in seen:
                        seen.add(f["id"])
                        queue.append((f["id"], f.get("resourceKey"), path + [f.get("name", f["id"])]))
                    continue
                f["path"] = path
                out.append(f)
            if on_progress:
                on_progress(folders, len(out))
        return out

    def download(self, f, dest, stop=None, on_bytes=None):
        """Download one file (resumes nothing; writes to .part then renames). Returns bytes."""
        fid = f["id"]
        rk = f.get("resourceKey")
        url = self._url(f"/files/{fid}", {"alt": "media", "supportsAllDrives": "true"})
        tmp = dest + ".part"
        md5 = hashlib.md5()
        n = 0
        with self._open(url, {fid: rk} if rk else None, stop) as r, open(tmp, "wb") as out:
            while True:
                if stop is not None and stop.is_set():
                    raise DriveError("أُوقف")
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
                md5.update(chunk)
                n += len(chunk)
                if on_bytes:
                    on_bytes(len(chunk))
        size = f.get("size")
        if size and str(n) != str(size):
            os.remove(tmp)
            raise DriveError(f"التنزيل غير مكتمل ({n} من {size} بايت)")
        if f.get("md5Checksum") and md5.hexdigest() != f["md5Checksum"]:
            os.remove(tmp)
            raise DriveError("فشل التحقق من سلامة الملف بعد التنزيل (md5)")
        os.replace(tmp, dest)
        _set_mtime(dest, f.get("modifiedTime"))
        return n


def _set_mtime(path, iso):
    if not iso:
        return
    try:
        ts = datetime.strptime(iso[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
        os.utime(path, (ts, ts))
    except (ValueError, OSError):
        pass


def _mtime_of(iso):
    try:
        return datetime.strptime(iso[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
    except (TypeError, ValueError):
        return 0.0


def public_file_download(fid, dest, usercontent=None, rk=None, timeout=120):
    """Single public file without any key (drive.usercontent.google.com)."""
    usercontent = usercontent or _ep("PDF2WORD_DRIVE_USERCONTENT", USERCONTENT)
    q = {"id": fid, "export": "download", "confirm": "t"}
    if rk:
        q["resourcekey"] = rk
    req = urllib.request.Request(usercontent + "?" + urllib.parse.urlencode(q), headers={"User-Agent": "Mozilla/5.0 PDF2Word-AI"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r, open(dest + ".part", "wb") as out:
            first = r.read(1 << 16)
            if not first.startswith(b"%PDF") and b"%PDF" not in first[:1024]:
                raise DriveError("الملف ليس PDF عاماً قابلاً للتنزيل (قد يحتاج تسجيل دخول)")
            out.write(first)
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
    except urllib.error.HTTPError as e:
        raise DriveError(f"تعذّر تنزيل الملف العام (HTTP {e.code})")
    except urllib.error.URLError as e:
        raise DriveError(f"تعذّر الاتصال بـ Google Drive: {e.reason}")
    os.replace(dest + ".part", dest)
    return dest


def is_pdf_entry(f) -> bool:
    return f.get("mimeType") == "application/pdf" or f.get("name", "").lower().endswith(".pdf")


def is_zip_entry(f) -> bool:
    return f.get("mimeType") in ("application/zip", "application/x-zip-compressed") or f.get("name", "").lower().endswith(".zip")


class Fetcher:
    """Resolve a Drive link, list every file below it (all sub-folders), then download the PDFs/ZIPs.

    fx = Fetcher(link, api_key=..., oauth=...); info = fx.resolve(); files = fx.list();
    res = fx.download(dest_dir, should_skip=..., threads=4)
    """

    def __init__(self, link, *, api_key=None, oauth=None, log=None, progress=None, stop=None, include_zips=True,
                 base=None, usercontent=None):
        self.link = link
        self.info = parse_link(link)
        if not self.info:
            raise DriveError("هذا ليس رابط Google Drive صالحاً")
        if self.info["kind"] == "doc":
            raise DriveError("هذا رابط مستند Google (Docs/Sheets) وليس ملف PDF أو مجلداً")
        self.log = log or (lambda *_: None)
        self.progress = progress
        self.stop = stop
        self.include_zips = include_zips
        self.usercontent = usercontent
        self.client = None
        try:
            self.client = DriveClient(api_key=api_key, oauth=oauth, base=base, usercontent=usercontent, log=self.log)
        except DriveAuthError:
            if self.info["kind"] != "file":
                raise
        self.meta = None
        self.entries = []

    @property
    def is_folder(self):
        return bool(self.meta and self.meta.get("mimeType") == FOLDER)

    def resolve(self):
        if self.client is None:  # single public file, no key
            self.meta = {"id": self.info["id"], "name": self.info["id"] + ".pdf", "mimeType": "application/pdf",
                         "resourceKey": self.info.get("resource_key"), "path": []}
            return {"name": "Drive", "label": "Drive", "id": self.info["id"], "folder": False}
        meta = self.client.meta(self.info["id"], self.info.get("resource_key"))
        if meta.get("mimeType") == SHORTCUT:
            sd = meta.get("shortcutDetails") or {}
            meta = self.client.meta(sd.get("targetId"), sd.get("targetResourceKey"))
        if not meta.get("resourceKey") and self.info.get("resource_key") and meta.get("id") == self.info["id"]:
            meta["resourceKey"] = self.info["resource_key"]
        self.meta = meta
        name = meta.get("name") or self.info["id"]
        if self.is_folder:
            return {"name": name, "label": safe_name(name, 80), "id": meta["id"], "folder": True}
        return {"name": name, "label": "Drive", "id": meta["id"], "folder": False}

    def list(self):
        if self.meta is None:
            self.resolve()
        if self.is_folder:
            self.log(f"جارٍ قراءة مجلد Drive «{self.meta.get('name')}» وكل مجلداته الفرعية…")

            def walk_progress(folders, files):
                if self.progress:
                    self.progress(phase="listing", folders=folders, files=files)

            entries = self.client.walk(self.meta["id"], self.meta.get("resourceKey"), self.stop, walk_progress)
        else:
            m = dict(self.meta)
            m["path"] = []
            entries = [m]
        self.entries = entries
        return entries

    def wanted(self):
        return [f for f in self.entries if is_pdf_entry(f) or (self.include_zips and is_zip_entry(f))]

    def plan(self):
        """[(entry, relative local path)] with Windows-safe, unique names."""
        plan, used = [], set()
        for f in self.wanted():
            parts = [safe_name(p, 80) for p in f.get("path", [])]
            fname = safe_name(f.get("name") or f["id"])
            if is_pdf_entry(f) and not fname.lower().endswith(".pdf"):
                fname += ".pdf"
            rel = os.path.join(*parts, fname) if parts else fname
            stem, ext = os.path.splitext(rel)
            k = 2
            while rel.lower() in used:
                rel = f"{stem} ({k}){ext}"
                k += 1
            used.add(rel.lower())
            plan.append((f, rel))
        return plan

    def download(self, dest, threads=4, should_skip=None):
        """should_skip(rel, modified_ts) -> truthy to skip (e.g. the Word file already exists)."""
        plan = self.plan()
        stats = {"listed": len(self.entries), "pdfs": sum(1 for f, _ in plan if is_pdf_entry(f)),
                 "zips": sum(1 for f, _ in plan if not is_pdf_entry(f)), "downloaded": 0, "cached": 0,
                 "skipped": [], "failed": [], "bytes": 0,
                 "native_docs": sum(1 for f in self.entries if f.get("mimeType", "").startswith(NATIVE))}
        total_bytes = sum(int(f.get("size") or 0) for f, _ in plan)
        self.log(f"وُجد {stats['pdfs']} ملف PDF" + (f" و {stats['zips']} ملف ZIP" if stats["zips"] else "")
                 + f" من أصل {len(self.entries)} ملفاً (الحجم {total_bytes / 1048576:.1f} MB).")
        if stats["native_docs"]:
            self.log(f"ملاحظة: يوجد {stats['native_docs']} مستند Google (Docs/Sheets/Slides) ليس PDF فلم يُنزَّل.")
        os.makedirs(dest, exist_ok=True)
        lock = threading.Lock()
        done = [0, 0]

        def bump(nbytes=0, file_done=False):
            with lock:
                done[1] += nbytes
                if file_done:
                    done[0] += 1
                if self.progress:
                    self.progress(phase="downloading", done=done[0], total=len(plan), bytes=done[1], total_bytes=total_bytes)

        def work(item):
            f, rel = item
            if self.stop is not None and self.stop.is_set():
                return "stopped", f, rel, None
            out = os.path.join(dest, rel)
            mts = _mtime_of(f.get("modifiedTime"))
            if should_skip and is_pdf_entry(f):
                sk = should_skip(rel, mts)
                if sk:
                    return "skipped", f, rel, sk
            os.makedirs(os.path.dirname(out), exist_ok=True)
            if os.path.exists(out) and f.get("size") and os.path.getsize(out) == int(f["size"]) and \
                    (not mts or abs(os.path.getmtime(out) - mts) < 2):
                return "cached", f, rel, None
            try:
                if self.client is None:
                    public_file_download(f["id"], out, self.usercontent, f.get("resourceKey"))
                else:
                    self.client.download(f, out, self.stop, on_bytes=lambda n: bump(n))
                return "ok", f, rel, None
            except DriveError as e:
                return "failed", f, rel, str(e)

        bump()
        with ThreadPoolExecutor(max_workers=max(1, min(16, int(threads or 4)))) as ex:
            futs = [ex.submit(work, it) for it in plan]
            for fu in as_completed(futs):
                status, f, rel, extra = fu.result()
                if status == "ok":
                    stats["downloaded"] += 1
                    stats["bytes"] += int(f.get("size") or 0)
                elif status == "cached":
                    stats["cached"] += 1
                elif status == "skipped":
                    stats["skipped"].append((rel, extra))
                elif status == "failed":
                    stats["failed"].append((rel, extra))
                    self.log(f"✖ تعذّر تنزيل {rel}: {extra}")
                bump(file_done=True)
        # the cache folder is ours: drop files that are no longer in the Drive folder
        keep = {os.path.normcase(os.path.join(dest, rel)) for _, rel in plan}
        for dp, _, fs in os.walk(dest):
            for fn in fs:
                full = os.path.join(dp, fn)
                if fn.lower().endswith((".pdf", ".zip", ".part")) and os.path.normcase(full) not in keep:
                    try:
                        os.remove(full)
                    except OSError:
                        pass
        return stats


def fetch(link, dest_root, *, api_key=None, oauth=None, threads=4, log=None, progress=None, stop=None,
          should_skip=None, include_zips=True, base=None, usercontent=None):
    """One-call helper: download every PDF/ZIP of a Drive link into dest_root/<folder name>/."""
    fx = Fetcher(link, api_key=api_key, oauth=oauth, log=log, progress=progress, stop=stop,
                 include_zips=include_zips, base=base, usercontent=usercontent)
    info = fx.resolve()
    fx.list()
    root = os.path.join(dest_root, info["label"])
    stats = fx.download(root, threads, should_skip)
    return dict(stats, root=root, label=info["label"], name=info["name"])
