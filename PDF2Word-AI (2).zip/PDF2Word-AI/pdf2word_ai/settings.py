# -*- coding: utf-8 -*-
"""User settings (saved as JSON in the user's profile)."""
from __future__ import annotations

import json
import os

from .ocr import app_data_dir

DEFAULTS = {
    # output
    "output_mode": "folder",  # folder | beside
    "output_dir": os.path.join(os.path.expanduser("~"), "Documents", "PDF2Word"),
    "skip_existing": True,
    "include_system_folders": False,
    "scan_zips": True,
    "markdown_output": False,  # also write a .md next to every Word file
    # off by default on purpose: scanning a whole drive would otherwise convert every stray
    # .txt/.json/.xml on it. Turn it on for a folder of mixed documents.
    "scan_other_files": False,  # also convert the PDFs inside .zip files
    # packaging of the results
    "zip_output": True,  # put all the Word files of a run in one .zip
    "ai_pack": True,  # compact Markdown copy for AI assistants (AI_READY folder)
    "ai_pack_strip_tashkeel": False,
    "ai_pack_part_tokens": 100000,
    # content analysis with the free AI service chosen for correction
    "analysis_enabled": False,
    "analysis_prompt": "",  # the user's own analysis instructions (also written into the CLAUDE files)
    "analysis_overall": True,  # combined report over all documents
    "analysis_language": "ar",  # ar | en | auto (language of each document)
    "analysis_chunk_tokens": 0,  # 0 = automatic per service
    # Google Drive links
    "drive_api_key": "",
    "drive_threads": 4,
    "keep_downloads": False,
    # conversion
    "mode": "auto",  # auto | exact (pdf2docx layout copy for non-Arabic digital files, experimental)
    "detect_tables": True,
    "include_images": True,
    "vector_figures": True,
    "keep_fonts": True,
    "keep_columns": True,
    "font_latin": "Calibri",
    "font_arabic": "Arial",
    "password": "",
    "workers": 1,
    # OCR
    "ocr_enabled": True,
    "ocr_lang": "ara+eng",
    "ocr_dpi": 300,
    "force_ocr": False,
    "ocr_engine": "auto",  # auto | tesseract | embedded
    "ocr_embedded": True,
    "include_scan_image": False,
    "tesseract_path": "",
    # AI
    "ai_enabled": False,
    "ai_provider": "gemini",
    "ai_api_key": "",
    "ai_model": "",
    "ai_base_url": "",
    "ai_rpm": 0,
    "ai_vision": None,
}


def settings_path() -> str:
    return os.path.join(app_data_dir(), "settings.json")


def load_settings() -> dict:
    s = dict(DEFAULTS)
    try:
        with open(settings_path(), encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            for k in DEFAULTS:
                if k in data:
                    s[k] = data[k]
    except (OSError, ValueError):
        pass
    return s


def save_settings(s: dict) -> None:
    data = {k: s.get(k, v) for k, v in DEFAULTS.items()}
    tmp = settings_path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, settings_path())


def coerce(s: dict) -> dict:
    """Validate / normalise values coming from the UI or CLI."""
    out = dict(DEFAULTS)
    out.update({k: v for k, v in (s or {}).items() if k in DEFAULTS})
    for k in ("skip_existing", "include_system_folders", "scan_zips", "zip_output", "ai_pack", "ai_pack_strip_tashkeel",
              "keep_downloads", "analysis_enabled", "analysis_overall", "markdown_output",
              "scan_other_files", "detect_tables", "include_images", "vector_figures",
              "keep_fonts", "keep_columns", "ocr_embedded", "ocr_enabled", "force_ocr", "include_scan_image", "ai_enabled"):
        out[k] = bool(out[k])
    try:
        out["workers"] = max(1, min(16, int(out["workers"])))
    except (TypeError, ValueError):
        out["workers"] = 1
    try:
        out["ocr_dpi"] = max(150, min(600, int(out["ocr_dpi"])))
    except (TypeError, ValueError):
        out["ocr_dpi"] = 300
    try:
        out["ai_rpm"] = max(0, min(1000, int(out["ai_rpm"] or 0)))
    except (TypeError, ValueError):
        out["ai_rpm"] = 0
    try:
        out["drive_threads"] = max(1, min(16, int(out["drive_threads"])))
    except (TypeError, ValueError):
        out["drive_threads"] = 4
    try:
        out["ai_pack_part_tokens"] = max(5000, min(2_000_000, int(out["ai_pack_part_tokens"])))
    except (TypeError, ValueError):
        out["ai_pack_part_tokens"] = 100000
    out["analysis_prompt"] = str(out.get("analysis_prompt") or "").strip()[:4000]
    if out.get("analysis_language") not in ("ar", "en", "auto"):
        out["analysis_language"] = "ar"
    try:
        out["analysis_chunk_tokens"] = max(0, min(900_000, int(out.get("analysis_chunk_tokens") or 0)))
    except (TypeError, ValueError):
        out["analysis_chunk_tokens"] = 0
    out["drive_api_key"] = "".join(ch for ch in str(out["drive_api_key"] or "") if ch.isalnum() or ch in "-_")[:100]
    if out["output_mode"] not in ("folder", "beside"):
        out["output_mode"] = "folder"
    if out["mode"] not in ("auto", "exact"):
        out["mode"] = "auto"
    if out["ocr_engine"] not in ("auto", "tesseract", "embedded"):
        out["ocr_engine"] = "auto"
    out["ocr_lang"] = "".join(ch for ch in str(out["ocr_lang"] or "ara+eng") if ch.isalnum() or ch in "+_") or "ara+eng"
    out["output_dir"] = os.path.expanduser(str(out["output_dir"] or DEFAULTS["output_dir"]))
    return out
