# -*- coding: utf-8 -*-
"""One PDF -> one Word file. Decides per page: exact text extraction (digital pages), OCR
(scanned pages) and optional AI correction, then verifies what was written."""
from __future__ import annotations

import json
import os
import re
import shutil
import statistics
import tempfile
import time
import traceback
from collections import Counter
from dataclasses import dataclass, field

import pdfplumber
import pypdfium2 as pdfium

from . import layout
from . import textutils as tu
from .ai import AIError, Corrector, make_provider
from . import tomarkdown
from .docxwriter import DocxBuilder, docx_text
from .mdparse import parse_markdown
from .model import PageResult, Paragraph, Picture, Table
from . import ocr_embedded
from .ocr import Tesseract, app_data_dir, ink_ratio, ocr_to_paragraphs, render_page
from .settings import DEFAULTS, coerce


def long_path(p: str) -> str:
    """Windows paths longer than 260 characters need the extended-length prefix."""
    if os.name == "nt" and p and len(p) > 240 and not p.startswith("\\\\?\\"):
        p = os.path.abspath(p)
        return "\\\\?\\UNC\\" + p[2:] if p.startswith("\\\\") else "\\\\?\\" + p
    return p


class Cancelled(Exception):
    pass


class PasswordError(Exception):
    pass


@dataclass
class FileReport:
    source: str
    output: str = ""
    status: str = "ok"  # ok | warning | error | skipped | cancelled
    pages: int = 0
    native_pages: int = 0
    ocr_pages: int = 0
    ai_pages: int = 0
    blank_pages: int = 0
    image_pages: int = 0
    review_pages: list = field(default_factory=list)
    uncertain: int = 0
    notes: list = field(default_factory=list)
    seconds: float = 0.0
    message: str = ""
    method: str = "structured"
    engines: dict = field(default_factory=dict)  # OCR engine -> pages read with it
    markdown: str = ""  # the .md file written beside the Word file, if asked for
    log: list = field(default_factory=list)

    def to_dict(self):
        return dict(self.__dict__)


def _is_password_error(e) -> bool:
    name = type(e).__name__.lower()
    return "password" in name or "password" in str(e).lower() or "encrypt" in name


class Converter:
    def __init__(self, settings: dict, log=None, stop_event=None, progress=None):
        self.s = coerce(dict(DEFAULTS, **(settings or {})))
        self._log = log or (lambda m: None)
        self.stop = stop_event
        self.progress = progress or (lambda *a: None)
        self.ocr = None
        self.ocr_ready = None
        self._engines = None
        self._warned = set()
        self.corrector = None
        if self.s.get("ai_enabled"):
            try:
                prov = make_provider(self.s, log=self.log)
                self.corrector = Corrector(prov, cache_dir=os.path.join(app_data_dir(), "ai_cache"), log=self.log)
            except AIError as e:
                self.log(f"⚠️ تعذّر تفعيل الذكاء الاصطناعي: {e}")

    def log(self, msg):
        self._log(msg)

    def _check_stop(self):
        if self.stop is not None and self.stop.is_set():
            raise Cancelled()

    def init_ocr(self) -> bool:
        if self.ocr_ready is not None:
            return self.ocr_ready
        self.ocr_ready = False
        if not self.s.get("ocr_enabled"):
            return False
        t = Tesseract(self.s.get("tesseract_path") or None, self.s.get("ocr_lang"), log=self.log,
                      threads_limit=self.s.get("workers", 1) > 1)
        if not t.available:
            if not ocr_embedded.installed():
                self.log("⚠️ لا يوجد محرك OCR: ثبّت مكتبة rapidocr (المحرك المدمج) أو برنامج Tesseract لقراءة الصفحات الممسوحة.")
            return False
        ok, msg = t.prepare(allow_download=True)
        if not ok:
            self.log("⚠️ " + msg)
            return False
        if msg != "OK":
            self.log(msg)
        self.ocr = t
        self.ocr_ready = True
        return True

    def ocr_engines(self):
        """OCR engines in the order they are tried: Tesseract (if installed) and the built-in
        engine (always shipped with the program). 'ocr_engine' setting can force one."""
        if self._engines is not None:
            return self._engines
        engines = []
        if self.s.get("ocr_enabled"):
            pref = self.s.get("ocr_engine", "auto")
            tess = self.ocr if (pref in ("auto", "tesseract") and self.init_ocr()) else None
            emb = None
            if pref in ("auto", "embedded") and self.s.get("ocr_embedded", True) and ocr_embedded.installed():
                workers = max(1, int(self.s.get("workers", 1)))
                threads = max(1, (os.cpu_count() or 2) // workers) if workers > 1 else 0
                emb = ocr_embedded.EmbeddedOCR(self.s.get("ocr_lang"), log=self.log, threads=threads)
            order = [emb, tess] if pref == "embedded" else [tess, emb]
            engines = [e for e in order if e is not None]
            if not engines:
                self.log("⚠️ لا يوجد محرك OCR جاهز: الصفحات الممسوحة ستُقرأ بالذكاء الاصطناعي إن كان مفعّلاً، وإلا ستُدرج كصور.")
            elif pref == "auto" and tess is None and emb is not None and "emb" not in self._warned:
                self._warned.add("emb")
                self.log("Tesseract غير مثبت؛ سيُستخدم محرك OCR المدمج لقراءة الصفحات الممسوحة.")
        self._engines = engines
        return engines

    def _run_ocr(self, img, dpi, pr):
        """Try the engines; keep the reading that looks most like real text."""
        results = []
        for eng in self.ocr_engines():
            if getattr(eng, "broken", None):
                continue
            try:
                r = eng.ocr(img, dpi=dpi)
            except Exception as e:
                key = f"fail:{getattr(eng, 'name', '?')}"
                if key not in self._warned:
                    self._warned.add(key)
                    self.log(f"⚠️ تعذّر استخدام {getattr(eng, 'label', 'Tesseract')}: {e}")
                continue
            text = "\n".join(" ".join(l.text for l in g) for g in r.paragraphs)
            q = 0.6 * tu.ocr_plausibility(text) + 0.4 * r.conf
            results.append((q, r, getattr(eng, "name", "tesseract")))
            if q >= 78:
                break
        if not results:
            return None, None
        q, r, name = max(results, key=lambda x: x[0])
        return r, name

    def _convert_to_markdown(self, path, out_path, rep, t0) -> FileReport:
        """Word / PowerPoint / Excel / CSV / HTML / text -> Markdown (like Microsoft MarkItDown)."""
        try:
            if os.path.splitext(out_path)[1].lower() != ".md":
                out_path = os.path.splitext(out_path)[0] + ".md"
                rep.output = out_path
            os.makedirs(os.path.dirname(long_path(out_path)) or ".", exist_ok=True)
            tomarkdown.write_file_markdown(long_path(path), long_path(out_path),
                                           source=os.path.basename(path))
            rep.markdown = out_path
            rep.method = "markdown"
            rep.pages = 1
            if os.path.getsize(long_path(out_path)) < 20:
                rep.status = "warning"
                rep.message = "لم يُعثر على نص في هذا الملف"
        except Exception as e:
            rep.status = "error"
            rep.message = str(e) if type(e) is RuntimeError else f"{type(e).__name__}: {e}"
        rep.seconds = round(time.time() - t0, 1)
        return rep

    # ------------------------------------------------------------------------------------
    def convert(self, pdf_path: str, out_path: str) -> FileReport:
        rep = FileReport(source=pdf_path, output=out_path)
        t0 = time.time()
        if os.path.splitext(pdf_path)[1].lower() in tomarkdown.OTHER_EXTS:
            return self._convert_to_markdown(pdf_path, out_path, rep, t0)
        img_dir = tempfile.mkdtemp(prefix="p2w_img_")
        self._tmp_files = []
        self._handles = []
        try:
            self._convert(pdf_path, out_path, rep, img_dir)
        except Cancelled:
            rep.status, rep.message = "cancelled", "أوقفه المستخدم"
        except PasswordError:
            rep.status, rep.message = "error", "الملف محمي بكلمة مرور (أدخل كلمة المرور في الإعدادات)"
        except PermissionError as e:
            rep.status, rep.message = "error", f"لا يمكن الكتابة (هل ملف Word مفتوح؟): {e}"
        except Exception as e:  # never crash the batch because of one file
            rep.status = "error"
            rep.message = str(e) if type(e) is RuntimeError else f"{type(e).__name__}: {e}"
            rep.log.append(traceback.format_exc()[-2000:])
        finally:
            shutil.rmtree(img_dir, ignore_errors=True)
            for h in self._handles:
                try:
                    h.close()
                except Exception:
                    pass
            for f in self._tmp_files:
                try:
                    os.remove(f)
                except OSError:
                    pass
            rep.seconds = round(time.time() - t0, 1)
        return rep

    def _repair(self, pdf_path, rep):
        """Try to rebuild a damaged PDF with qpdf (pikepdf). Returns a temp path or None."""
        try:
            import pikepdf
        except Exception:
            return None
        try:
            fd, tmp = tempfile.mkstemp(suffix=".pdf", prefix="p2w_fix_")
            os.close(fd)
            with pikepdf.open(long_path(pdf_path), password=self.s.get("password") or "", attempt_recovery=True) as pdf:
                if len(pdf.pages) == 0:
                    return None
                pdf.save(tmp)
            rep.notes.append("الملف كان تالفاً وتم إصلاحه تلقائياً (قد تكون بعض الصفحات ناقصة)")
            self._tmp_files.append(tmp)
            return tmp
        except Exception:
            return None

    def _fh(self, path):
        # Files are opened by Python (handles Arabic names and long paths on Windows) and the
        # handles are given to the PDF libraries.
        fh = open(long_path(path), "rb")
        self._handles.append(fh)
        return fh

    def _open(self, pdf_path, rep):
        pw = self.s.get("password") or None
        try:
            pdoc = pdfium.PdfDocument(self._fh(pdf_path), password=pw)
        except Exception as e:
            if _is_password_error(e):
                raise PasswordError()
            fixed = self._repair(pdf_path, rep)
            if not fixed:
                raise RuntimeError("ملف PDF تالف ولا يمكن إصلاحه")
            pdf_path = fixed
            pdoc = pdfium.PdfDocument(self._fh(pdf_path), password=pw)
        plumber = None
        try:
            plumber = pdfplumber.open(self._fh(pdf_path), password=pw or "")
            _ = len(plumber.pages)
        except Exception as e:
            if _is_password_error(e):
                pdoc.close()
                raise PasswordError()
            plumber = None
            rep.notes.append("بنية الملف تالفة جزئياً؛ قُرئت الصفحات كصور")
        return pdoc, plumber

    def _convert(self, pdf_path, out_path, rep, img_dir):
        pdoc, plumber = self._open(pdf_path, rep)
        try:
            n = len(pdoc)
            rep.pages = n
            if n == 0:
                raise RuntimeError("الملف لا يحتوي على صفحات")
            doc_state = {}
            pages = []
            for i in range(n):
                self._check_stop()
                self.progress(i, n)
                pr = self._process_page(i, plumber, pdoc, img_dir, doc_state)
                pages.append(pr)
            title = None
            try:
                title = (pdoc.get_metadata_dict() or {}).get("Title")
            except Exception:
                pass
        finally:
            try:
                if plumber is not None:
                    plumber.close()
            except Exception:
                pass
            try:
                pdoc.close()
            except Exception:
                pass
        self._check_stop()
        self.progress(n, n)
        body = assign_headings(pages)
        margins = doc_margins(pages)
        rtl_doc = doc_is_rtl(pages)

        for pr in pages:
            if pr.method == "native":
                rep.native_pages += 1
            elif pr.method in ("ocr", "ocr_layer"):
                rep.ocr_pages += 1
            elif pr.method == "blank":
                rep.blank_pages += 1
            elif pr.method == "image":
                rep.image_pages += 1
            if pr.ai_used:
                rep.ai_pages += 1
            eng = getattr(pr, "engine", None)
            if eng:
                rep.engines[eng] = rep.engines.get(eng, 0) + 1
            rep.uncertain += pr.uncertain
            if pr.needs_review:
                rep.review_pages.append(pr.index + 1)
            for note in pr.notes:
                rep.notes.append(f"ص{pr.index + 1}: {note}")

        os.makedirs(long_path(os.path.dirname(os.path.abspath(out_path)) or "."), exist_ok=True)
        tmp = out_path[:-5] + ".~tmp.docx" if out_path.lower().endswith(".docx") else out_path + ".~tmp"
        used_exact = False
        if self.s.get("mode") == "exact" and all(p.method in ("native", "blank") for p in pages) and not rtl_doc:
            used_exact = self._try_exact(pdf_path, tmp, pages, rep)
        if not used_exact:
            b = DocxBuilder(font_latin=self.s.get("font_latin"), font_arabic=self.s.get("font_arabic"),
                            base_size=body or 12.0, keep_fonts=self.s.get("keep_fonts", True), rtl_doc=rtl_doc,
                            margins=margins, title=title or os.path.splitext(os.path.basename(pdf_path))[0])
            meta = {"pages": rep.pages, "native": rep.native_pages, "ocr": rep.ocr_pages, "ai": rep.ai_pages,
                    "review": rep.review_pages[:200], "uncertain": rep.uncertain, "engines": rep.engines,
                    "ocr_pages": [pr.index + 1 for pr in pages if pr.method in ("ocr", "ocr_layer", "image")][:500],
                    "source": os.path.basename(pdf_path)}
            b.doc.core_properties.comments = "PDF2Word AI " + json.dumps(meta, ensure_ascii=False, separators=(",", ":"))
            for pr in pages:
                plan = pr.col_plan if (pr.method == "native" and self.s.get("keep_columns", True)) else [(1, 0, 0.0)]
                b.start_page(pr.width, pr.height, plan[0][0], plan[0][2])
                for k, (ncols, start, gap) in enumerate(plan):
                    end = plan[k + 1][1] if k + 1 < len(plan) else len(pr.items)
                    if k > 0:
                        b.switch_columns(ncols, gap)
                    for it in pr.items[start:end]:
                        b.add_item(it)
                b.end_page()
            b.save(long_path(tmp))
        if self.s.get("markdown_output"):
            try:
                md_path = os.path.splitext(out_path)[0] + ".md"
                os.makedirs(os.path.dirname(long_path(md_path)) or ".", exist_ok=True)
                tomarkdown.write_markdown(pages, long_path(md_path),
                                          images=bool(self.s.get("include_images", True)),
                                          source=os.path.basename(pdf_path))
                rep.markdown = md_path
            except Exception as e:
                rep.notes.append("تعذّر إنشاء ملف Markdown: %s" % e)
        try:
            os.replace(long_path(tmp), long_path(out_path))
        except PermissionError:
            try:
                os.remove(long_path(tmp))
            except OSError:
                pass
            raise
        # verification: re-read the Word file and compare with what we meant to write
        expected = sum(tu.count_visible(pr.plain_text()) for pr in pages)
        got = tu.count_visible(docx_text(long_path(out_path)))
        if not used_exact and expected and got < 0.98 * expected:
            rep.notes.append(f"تحقق: كُتب {got} من {expected} حرفاً متوقعاً")
            rep.status = "warning"
        rep.method = "exact" if used_exact else "structured"
        if rep.review_pages or rep.status == "warning":
            rep.status = "warning"
            if rep.review_pages:
                rep.message = "صفحات تحتاج مراجعة: " + ", ".join(map(str, rep.review_pages[:30]))
        else:
            rep.status = "ok"

    # ------------------------------------------------------------------------------------
    def _decide(self, page, pdoc, i, frame):
        """Return (method, raw_chars, mojibake, note)."""
        try:
            raw = layout.visible_chars(page, frame)
        except Exception:
            return "ocr", None, False, "تعذّرت قراءة نص الصفحة"
        upright = [c for c in raw if c.get("upright", True)]
        text = "".join(c.get("text") or "" for c in upright)
        moj = tu.detect_cp1256_mojibake(text)
        norm = tu.normalize_text(tu.fix_cp1256_mojibake(text) if moj else text)
        letters = sum(1 for ch in norm if ch.isalnum())
        W, H = frame[2] - frame[0], frame[3] - frame[1]
        big, big_box = 0.0, None
        try:
            for im in page.images:
                x0, top = max(im["x0"], frame[0]), max(im["top"], frame[1])
                x1, bot = min(im["x1"], frame[2]), min(im["bottom"], frame[3])
                a = max(0.0, x1 - x0) * max(0.0, bot - top) / max(1.0, W * H)
                if a > big:
                    big, big_box = a, (x0, top, x1, bot)
        except Exception:
            pass
        if self.s.get("force_ocr"):
            return "ocr", raw, moj, None
        if raw and len(upright) < 0.5 * len(raw) and len(raw) >= 15:
            return "ocr", raw, moj, "نص الصفحة مُدار؛ قُرئت بالـ OCR"
        if letters >= 1:
            quality = tu.text_quality(norm)
            gib = tu.gibberish_score(norm)
            if quality >= 0.85 and gib < 0.45:
                if big >= 0.6 and big_box is not None:
                    inside = sum(1 for c in upright if big_box[0] <= (c["x0"] + c["x1"]) / 2 <= big_box[2]
                                 and big_box[1] <= (c["top"] + c["bottom"]) / 2 <= big_box[3])
                    return ("ocr_layer" if inside >= 50 else "ocr"), raw, moj, None
                return "native", raw, moj, None
            return "ocr", raw, moj, "طبقة النص في الملف تالفة (ترميز خاطئ)؛ قُرئت الصفحة بالـ OCR"
        try:
            has_graphics = bool(page.images) or len(page.curves) + len(page.rects) + len(page.lines) > 0
        except Exception:
            has_graphics = True
        if not has_graphics:
            return "blank", raw, moj, None
        small = render_page(pdoc, i, dpi=40, grayscale=True)
        if ink_ratio(small) > 0.003:
            return "ocr", raw, moj, None
        return "blank", raw, moj, None

    def _process_page(self, i, plumber, pdoc, img_dir, doc_state) -> PageResult:
        if plumber is None:
            pp = pdoc[i]
            try:
                w, h = pp.get_size()
            finally:
                pp.close()
            return self._ocr_page(i, "ocr", None, pdoc, img_dir, float(w), float(h), None)
        page = plumber.pages[i]
        try:
            frame = layout.page_frame(page)
            W, H = frame[2] - frame[0], frame[3] - frame[1]
            method, raw, moj, note = self._decide(page, pdoc, i, frame)
            opts = {"tables": self.s.get("detect_tables", True), "images": self.s.get("include_images", True),
                    "figures": self.s.get("vector_figures", True)}
            if method == "native":
                ppage = pdoc[i]
                try:
                    pr = layout.analyze_native_page(page, ppage, i, opts, img_dir, raw_chars=raw, fix_mojibake=moj, doc_state=doc_state)
                finally:
                    ppage.close()
                if moj:
                    pr.notes.append("أُصلح ترميز عربي قديم (Windows-1256)")
                if pr.chars_in and pr.chars_out < 0.96 * pr.chars_in:
                    pr.notes.append(f"قد يكون جزء من النص ناقصاً ({pr.chars_out}/{pr.chars_in})")
                    pr.needs_review = True
                if tu.looks_reversed(pr.plain_text()):
                    pr.notes.append("ترتيب الحروف العربية في هذه الصفحة غير مؤكد")
                    pr.needs_review = True
                return pr
            if method == "blank":
                return PageResult(index=i, width=W, height=H, method="blank")
            native_pr = None
            if method == "ocr_layer":
                ppage = pdoc[i]
                try:
                    native_pr = layout.analyze_native_page(page, ppage, i, {"tables": True, "images": False, "figures": False},
                                                           img_dir, raw_chars=raw, fix_mojibake=moj, doc_state=doc_state)
                finally:
                    ppage.close()
            pr = self._ocr_page(i, method, page, pdoc, img_dir, W, H, native_pr)
            if note:
                pr.notes.append(note)
            return pr
        finally:
            try:
                page.close()
            except Exception:
                pass

    def _page_picture(self, img, i, img_dir, W, H, kind="page"):
        im = img.convert("RGB")
        if im.width > 1700:
            im = im.copy()
            im.thumbnail((1700, 1700 * im.height // max(1, im.width)))
        path = os.path.join(img_dir, f"page{i + 1}.jpg")
        im.save(path, "JPEG", quality=85)
        return Picture(path=path, width=W, height=H, kind=kind, align="center")

    def _ocr_page(self, i, method, page, pdoc, img_dir, W, H, native_pr) -> PageResult:
        pr = PageResult(index=i, width=W, height=H, method=method)
        dpi = int(self.s.get("ocr_dpi") or 300)
        img = render_page(pdoc, i, dpi=dpi)
        draft, ocr_items = "", []
        if method == "ocr_layer" and native_pr is not None:
            draft = native_pr.plain_text()
        scan_pics = []
        ocr_failed = False
        if method != "ocr_layer" and self.ocr_engines():
            try:
                res, engine_name = self._run_ocr(img, dpi, pr)
                if res is None:
                    ocr_failed = True
                    raise RuntimeError("لم ينجح أي محرك OCR في قراءة الصفحة")
                pr.engine = engine_name
                pr.ocr_conf = round(res.conf, 1)
                ocr_items = ocr_to_paragraphs(res, W)
                draft = "\n\n".join(p.text for p in ocr_items)
                if self.s.get("include_images", True):
                    for k, b in enumerate(res.pictures[:6]):
                        crop = img.crop(b).convert("RGB")
                        path = os.path.join(img_dir, f"p{i + 1}_scanpic{k + 1}.jpg")
                        crop.save(path, "JPEG", quality=88)
                        s_ = 72.0 / dpi
                        scan_pics.append(Picture(path=path, width=(b[2] - b[0]) * s_, height=(b[3] - b[1]) * s_,
                                                 bbox=(b[0] * s_, b[1] * s_, b[2] * s_, b[3] * s_), align="center"))
            except Exception as e:
                pr.notes.append(f"فشل OCR: {e}")
        if self.corrector is not None and not self.corrector.disabled:
            self._check_stop()
            corr = self.corrector.correct(page_image=img, ocr_text=draft, ocr_conf=pr.ocr_conf)
            if corr.accepted:
                items = parse_markdown(corr.text, source="ai")
                if items:
                    pr.items = items
                    pr.ai_used = True
                    pr.uncertain = corr.uncertain
                    if corr.needs_review:
                        pr.needs_review = True
                        if corr.uncertain:
                            pr.notes.append(f"{corr.uncertain} كلمة غير مقروءة مُعلَّمة بـ [؟]")
            elif corr.used and corr.reason:
                pr.notes.append("لم يُعتمد تصحيح الذكاء الاصطناعي: " + corr.reason)
                if corr.needs_review:
                    pr.needs_review = True
        if not pr.items:
            if native_pr is not None and native_pr.items:
                pr.items = native_pr.items
            elif ocr_items:
                pr.items = ocr_items
                if pr.ocr_conf is not None and pr.ocr_conf < 70:
                    pr.needs_review = True
                    pr.notes.append(f"دقة OCR منخفضة ({pr.ocr_conf:.0f}%)")
        if scan_pics and pr.items:
            items = list(pr.items)
            for pic in scan_pics:
                if pr.ai_used or not any(getattr(it, "bbox", None) for it in items):
                    pos = int(round(len(items) * (pic.bbox[1] / max(H, 1.0))))
                else:
                    pos = len(items)
                    for k, it in enumerate(items):
                        bb = getattr(it, "bbox", None)
                        if bb and bb[1] > pic.bbox[1]:
                            pos = k
                            break
                items.insert(min(max(pos, 0), len(items)), pic)
            pr.items = items
        letters = sum(1 for ch in pr.plain_text() if ch.isalnum())
        if letters < 15:
            if ink_ratio(img) > 0.01:
                pr.items = list(pr.items) + [self._page_picture(img, i, img_dir, W, H)]
                if (not self.ocr_engines() or ocr_failed) and not pr.ai_used:
                    pr.notes.append("أُدرجت الصفحة كصورة (لم يتمكن أي محرك OCR من قراءتها)")
                    pr.needs_review = True
                pr.method = "image" if letters == 0 else pr.method
        elif self.s.get("include_scan_image"):
            pr.items = list(pr.items) + [self._page_picture(img, i, img_dir, W, H, kind="scan")]
        return pr

    def _try_exact(self, pdf_path, tmp, pages, rep) -> bool:
        try:
            from pdf2docx import Converter as P2D  # optional dependency
        except Exception:
            rep.notes.append("وضع مطابقة التنسيق يحتاج مكتبة pdf2docx؛ استُخدم الوضع العادي")
            return False
        try:
            cv = P2D(long_path(pdf_path), password=self.s.get("password") or None)
            try:
                cv.convert(tmp)
            finally:
                cv.close()
            ref = "\n".join(pr.plain_text() for pr in pages)
            got = docx_text(tmp)
            rec = tu.word_recall(ref, got)
            if rec >= 0.97:
                return True
            rep.notes.append(f"مطابقة التنسيق فقدت نصاً ({rec:.0%})؛ استُخدم الوضع العادي")
        except Exception as e:
            rep.notes.append(f"تعذّر وضع مطابقة التنسيق: {e}")
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False


# ----------------------------------------------------------------------------------------------
# Document-level post-processing
# ----------------------------------------------------------------------------------------------
def _native_paragraphs(pages):
    for pr in pages:
        if pr.method != "native":
            continue
        for it in pr.items:
            if isinstance(it, Paragraph):
                yield pr, it


def assign_headings(pages):
    """Heading levels from font size (and bold one-line titles). Returns the body text size."""
    weights = Counter()
    for _, p in _native_paragraphs(pages):
        for r in p.runs:
            if r.size:
                weights[r.size] += len(r.text.strip())
    if not weights:
        return None
    body = weights.most_common(1)[0][0]
    npages = max(1, len(pages))
    repeat = Counter(tu.normalize_for_compare(p.text) for _, p in _native_paragraphs(pages))
    cands = []
    for _, p in _native_paragraphs(pages):
        t = p.text.strip()
        if not t or p.is_list or len(t) > 200 or p.line_count > 3 or p.heading:
            continue
        if npages >= 3 and repeat[tu.normalize_for_compare(t)] >= max(3, 0.5 * npages):
            continue  # running header / footer
        if re.fullmatch(r"[\d٠-٩\s\-–/|.]+", t):
            continue  # page numbers
        size = p.size or body
        if size >= body * 1.15:
            cands.append((p, round(size * 2) / 2))
        elif (p.bold_all and size >= body * 0.99 and len(t) <= 90 and p.line_count == 1
              and not t.endswith((".", "،", ",", ":", "؛", ";"))):
            cands.append((p, None))
    sizes = sorted({s for _, s in cands if s}, reverse=True)
    level_of = {s: min(3, k + 1) for k, s in enumerate(sizes)}
    bold_level = min(3, len(sizes) + 1)
    for p, s in cands:
        p.heading = level_of[s] if s else bold_level
    return body


def doc_margins(pages):
    vals = [pr for pr in pages if pr.method == "native" and pr.text_bounds]
    if not vals:
        return None
    lefts = [pr.text_bounds[0] for pr in vals]
    tops = [pr.text_bounds[1] for pr in vals]
    rights = [pr.width - pr.text_bounds[2] for pr in vals]
    bottoms = [pr.height - pr.text_bounds[3] for pr in vals]

    def clamp(v):
        return max(28.0, min(100.0, v))

    return (clamp(statistics.median(lefts)), clamp(statistics.median(tops)) * 0.9,
            clamp(statistics.median(rights)), clamp(statistics.median(bottoms)) * 0.8)


def doc_is_rtl(pages):
    ar = lt = 0
    for pr in pages:
        for it in pr.items:
            if isinstance(it, Paragraph):
                n = len(it.text)
                if it.rtl:
                    ar += n
                else:
                    lt += n
            elif isinstance(it, Table):
                n = len(it.text)
                if it.rtl:
                    ar += n
                else:
                    lt += n
    return ar > lt
