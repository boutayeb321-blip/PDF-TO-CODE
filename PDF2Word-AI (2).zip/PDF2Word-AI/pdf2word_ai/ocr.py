# -*- coding: utf-8 -*-
"""Page rendering (PDFium) and OCR with Tesseract (free, offline, supports Arabic)."""
from __future__ import annotations

import csv
import glob
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
from dataclasses import dataclass, field

from PIL import Image, ImageFilter, ImageOps

from . import textutils as tu
from .model import Paragraph, Run

IS_WIN = sys.platform.startswith("win")
NO_WINDOW = 0x08000000 if IS_WIN else 0  # CREATE_NO_WINDOW: no console flashing on Windows

TESSDATA_URLS = [
    "https://github.com/tesseract-ocr/tessdata_best/raw/main/{lang}.traineddata",
    "https://github.com/tesseract-ocr/tessdata/raw/main/{lang}.traineddata",
    "https://github.com/tesseract-ocr/tessdata_fast/raw/main/{lang}.traineddata",
]


def app_data_dir() -> str:
    if IS_WIN:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        d = os.path.join(base, "PDF2WordAI")
    else:
        d = os.path.join(os.path.expanduser("~"), ".pdf2word_ai")
    os.makedirs(d, exist_ok=True)
    return d


def render_page(pdfium_doc, index: int, dpi: int = 300, grayscale: bool = False) -> Image.Image:
    page = pdfium_doc[index]
    try:
        bm = page.render(scale=dpi / 72.0, grayscale=grayscale)
        try:
            img = bm.to_pil().copy()  # detach from PDFium memory before the page is closed
        finally:
            bm.close()
    finally:
        page.close()
    return img


def ink_bands(img: Image.Image, covered_boxes, scale: int = 4):
    """Horizontal bands of ink that are not covered by any of covered_boxes (px boxes).
    Returns [(x0, y0, x1, y1, ink_pixels)] in full-resolution px."""
    gray = img.convert("L")
    small = gray.filter(ImageFilter.MinFilter(5)).resize((max(1, gray.width // scale), max(1, gray.height // scale)), Image.BOX)
    W, H = small.size
    px = small.load()
    covered = [bytearray(W) for _ in range(H)]
    for b in covered_boxes:
        x0, y0 = max(0, int(b[0]) // scale - 2), max(0, int(b[1]) // scale - 2)
        x1, y1 = min(W, int(b[2]) // scale + 3), min(H, int(b[3]) // scale + 3)
        for y in range(y0, y1):
            row = covered[y]
            for x in range(x0, x1):
                row[x] = 1
    mx, my = int(W * 0.02), int(H * 0.02)
    min_cnt = max(3, int(0.004 * W))
    bands, cur = [], None
    for y in range(my, H - my):
        cnt, xs0, xs1 = 0, None, None
        row = covered[y]
        for x in range(mx, W - mx):
            if px[x, y] < 160 and not row[x]:
                cnt += 1
                if xs0 is None:
                    xs0 = x
                xs1 = x
        if cnt >= min_cnt:
            if cur is None:
                cur = [y, y, xs0, xs1, cnt]
            else:
                cur[1] = y
                cur[2], cur[3] = min(cur[2], xs0), max(cur[3], xs1)
                cur[4] += cnt
        elif cur is not None:
            bands.append(cur)
            cur = None
    if cur is not None:
        bands.append(cur)
    return [(b[2] * scale, b[0] * scale, (b[3] + 1) * scale, (b[1] + 1) * scale, b[4]) for b in bands]


def ink_ratio(img: Image.Image) -> float:
    """Share of non-white pixels (used to tell blank pages from pages with content)."""
    g = img.convert("L")
    g.thumbnail((400, 400))
    hist = g.histogram()
    dark = sum(hist[:200])
    return dark / max(1, sum(hist))


@dataclass
class OcrLine:
    text: str
    bbox: tuple  # x0, top, x1, bottom in points
    height: float


@dataclass
class OcrResult:
    text: str = ""
    conf: float = 0.0
    words: int = 0
    paragraphs: list = field(default_factory=list)  # list of list[OcrLine]
    variant: str = ""
    wordlist: list = field(default_factory=list)  # [{key, text, conf, box(px)}] in reading order
    line_boxes: dict = field(default_factory=dict)
    dpi: int = 300
    pictures: list = field(default_factory=list)  # picture regions found on the scan (px boxes)


class Tesseract:
    def __init__(self, exe: str | None = None, langs: str = "ara+eng", log=None, threads_limit: bool = False):
        self.log = log or (lambda *_: None)
        self.exe = self.find_exe(exe)
        self.langs_wanted = langs or "ara+eng"
        self.tessdata_dir = None
        self.threads_limit = threads_limit
        self._langs_cache = None

    # -- discovery ------------------------------------------------------------------------
    @staticmethod
    def find_exe(custom: str | None = None) -> str | None:
        cands = []
        if custom:
            cands.append(custom)
        w = shutil.which("tesseract")
        if w:
            cands.append(w)
        if IS_WIN:
            for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                         os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs"), os.environ.get("LOCALAPPDATA", "")):
                if base:
                    cands.append(os.path.join(base, "Tesseract-OCR", "tesseract.exe"))
        else:
            cands += ["/opt/homebrew/bin/tesseract", "/usr/local/bin/tesseract", "/usr/bin/tesseract"]
        for c in cands:
            if c and os.path.isfile(c):
                return c
        return None

    def _run(self, args, timeout=600):
        env = dict(os.environ)
        if self.threads_limit:
            env["OMP_THREAD_LIMIT"] = "1"
        return subprocess.run([self.exe] + args, capture_output=True, timeout=timeout, env=env, creationflags=NO_WINDOW)

    def version(self) -> str:
        if not self.exe:
            return ""
        try:
            out = self._run(["--version"], timeout=30)
            txt = (out.stdout or out.stderr).decode("utf-8", "replace")
            return txt.splitlines()[0].strip() if txt else ""
        except Exception:
            return ""

    def list_langs(self, tessdata_dir: str | None = None):
        """Return (directory, set of languages)."""
        if not self.exe:
            return None, set()
        args = ["--list-langs"]
        if tessdata_dir:
            args = ["--tessdata-dir", tessdata_dir] + args
        try:
            out = self._run(args, timeout=30)
        except Exception:
            return None, set()
        txt = (out.stdout + out.stderr).decode("utf-8", "replace")
        d = None
        m = re.search(r'languages in "(.+?)"', txt)
        if m:
            d = m.group(1)
        langs = set()
        for line in txt.splitlines():
            line = line.strip()
            if line and not line.lower().startswith("list of") and " " not in line and not line.startswith("Error"):
                langs.add(line)
        return d, langs

    @property
    def available(self) -> bool:
        return bool(self.exe)

    # -- language data --------------------------------------------------------------------
    def prepare(self, allow_download: bool = True, upgrade_arabic: bool = False) -> tuple[bool, str]:
        """Make sure the wanted languages exist; download missing ones to a user folder.
        upgrade_arabic: replace a small/fast Arabic model with the most accurate one."""
        if not self.exe:
            return False, "Tesseract غير مثبت"
        wanted = [l for l in self.langs_wanted.split("+") if l]
        sys_dir, sys_langs = self.list_langs()
        user_dir = os.path.join(app_data_dir(), "tessdata")
        user_ara = os.path.join(user_dir, "ara.traineddata")
        has_user_best = os.path.exists(user_ara) and os.path.getsize(user_ara) > 5_000_000
        sys_ara = os.path.join(sys_dir, "ara.traineddata") if sys_dir else ""
        sys_small = bool(sys_ara) and os.path.exists(sys_ara) and os.path.getsize(sys_ara) < 5_000_000
        want_upgrade = "ara" in wanted and ((upgrade_arabic and allow_download and sys_small) or has_user_best)
        if all(l in sys_langs for l in wanted) and not want_upgrade:
            self.tessdata_dir = None
            self._langs_cache = sys_langs
            return True, "OK"
        os.makedirs(user_dir, exist_ok=True)
        if want_upgrade and not has_user_best:
            self.download_lang("ara", user_dir)
        if sys_dir and os.path.isdir(sys_dir):
            for f in glob.glob(os.path.join(sys_dir, "*.traineddata")):
                dst = os.path.join(user_dir, os.path.basename(f))
                if not os.path.exists(dst):
                    try:
                        shutil.copy2(f, dst)
                    except OSError:
                        pass
        _, user_langs = self.list_langs(user_dir)
        missing = [l for l in wanted if l not in user_langs]
        if missing and allow_download:
            for lang in missing:
                ok = self.download_lang(lang, user_dir)
                if not ok:
                    self.log(f"تعذّر تنزيل بيانات اللغة {lang}")
            _, user_langs = self.list_langs(user_dir)
        missing = [l for l in wanted if l not in user_langs]
        if missing:
            have = [l for l in wanted if l in user_langs or l in sys_langs]
            if not have:
                return False, "بيانات لغة OCR غير متوفرة: " + "+".join(missing)
            self.langs_wanted = "+".join(have)
            self.tessdata_dir = user_dir if all(l in user_langs for l in have) else None
            return True, "تنبيه: لغات غير متوفرة: " + "+".join(missing)
        self.tessdata_dir = user_dir
        self._langs_cache = user_langs
        return True, "OK"

    def download_lang(self, lang: str, dest_dir: str) -> bool:
        dst = os.path.join(dest_dir, f"{lang}.traineddata")
        for url in TESSDATA_URLS:
            u = url.format(lang=lang)
            try:
                self.log(f"جارٍ تنزيل بيانات اللغة {lang} …")
                req = urllib.request.Request(u, headers={"User-Agent": "PDF2Word-AI"})
                with urllib.request.urlopen(req, timeout=120) as r:
                    data = r.read()
                if len(data) < 100_000:
                    continue
                tmp = dst + ".part"
                with open(tmp, "wb") as f:
                    f.write(data)
                os.replace(tmp, dst)
                self.log(f"تم تنزيل بيانات اللغة {lang} ({len(data) // 1024} KB)")
                return True
            except Exception as e:  # network errors, 404...
                self.log(f"فشل التنزيل من {u}: {e}")
        return False

    # -- OCR ------------------------------------------------------------------------------
    def _ocr_once(self, img: Image.Image, dpi: int, psm: int, workdir: str, tag: str):
        src = os.path.join(workdir, f"{tag}.png")
        img.save(src, dpi=(dpi, dpi))
        outbase = os.path.join(workdir, tag)
        args = [src, outbase, "-l", self.langs_wanted, "--psm", str(psm), "--dpi", str(dpi)]
        if self.tessdata_dir:
            args = [src, outbase, "--tessdata-dir", self.tessdata_dir, "-l", self.langs_wanted, "--psm", str(psm), "--dpi", str(dpi)]
        args += ["txt", "tsv"]
        proc = self._run(args)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.decode("utf-8", "replace")[-400:])
        with open(outbase + ".txt", encoding="utf-8", errors="replace") as f:
            text = f.read()
        rows = []
        with open(outbase + ".tsv", encoding="utf-8", errors="replace", newline="") as f:
            rd = csv.DictReader(f, delimiter="\t", quoting=csv.QUOTE_NONE)
            for r in rd:
                rows.append(r)
        return text, rows

    @staticmethod
    def _parse(text, rows, dpi):
        words = []
        line_boxes = {}
        for r in rows:
            try:
                lvl = int(r.get("level") or 0)
            except ValueError:
                continue
            key = (r.get("page_num"), r.get("block_num"), r.get("par_num"), r.get("line_num"))
            try:
                box = (int(r["left"]), int(r["top"]), int(r["left"]) + int(r["width"]), int(r["top"]) + int(r["height"]))
            except (KeyError, ValueError, TypeError):
                box = (0, 0, 0, 0)
            if lvl == 4:
                line_boxes[key] = box
            elif lvl == 5:
                t = (r.get("text") or "").strip()
                try:
                    conf = float(r.get("conf") or -1)
                except ValueError:
                    conf = -1
                if t and conf >= 0:
                    words.append({"key": key, "text": tu.normalize_text(t), "conf": conf, "box": box})
        res = OcrResult(text=tu.normalize_text(text), wordlist=words, line_boxes=line_boxes, dpi=dpi)
        Tesseract._rebuild(res)
        return res

    @staticmethod
    def _rebuild(res):
        words = [w for w in res.wordlist if w["text"]]
        res.words = len(words)
        res.conf = sum(w["conf"] for w in words) / len(words) if words else 0.0
        s = 72.0 / res.dpi
        paras, order = {}, []
        for w in words:
            pkey = w["key"][:3]
            if pkey not in paras:
                paras[pkey] = {}
                order.append(pkey)
            paras[pkey].setdefault(w["key"], []).append(w["text"])
        out = []
        for pkey in order:
            lines = []
            for lkey, toks in paras[pkey].items():
                b = res.line_boxes.get(lkey, (0, 0, 0, 0))
                x0, top, x1, bot = b[0] * s, b[1] * s, b[2] * s, b[3] * s
                lines.append(OcrLine(text=" ".join(toks), bbox=(x0, top, x1, bot), height=bot - top))
            if lines:
                out.append(lines)
        res.paragraphs = out

    def _arabic_second_opinion(self, img, best, dpi, psm, wd):
        """'ara+eng' sometimes reads Arabic words with the English model (e.g. "Jaall" for
        "العمل"). Re-read the page with Arabic only and swap in the Arabic reading for words that
        are clearly misread. Real English words (high confidence) are kept."""
        langs = self.langs_wanted.split("+")
        if "ara" not in langs or len(langs) < 2:
            return best
        if tu.arabic_ratio(" ".join(w["text"] for w in best.wordlist)) < 0.5:
            return best
        suspicious = [w for w in best.wordlist
                      if (not any(tu.is_arabic_letter(c) for c in w["text"]) and w["conf"] < 85 and any(c.isalnum() for c in w["text"]))
                      or (any(tu.is_arabic_letter(c) for c in w["text"]) and w["conf"] < 60)]
        if not suspicious:
            return best
        saved = self.langs_wanted
        try:
            self.langs_wanted = "ara"
            t2, r2 = self._ocr_once(img, dpi, psm, wd, "ara_only")
        except Exception:
            return best
        finally:
            self.langs_wanted = saved
        alt = self._parse(t2, r2, dpi)
        # line direction from the main reading
        line_ar = {}
        for w in best.wordlist:
            a = line_ar.setdefault(w["key"], [0, 0])
            for c in w["text"]:
                b = tu.bidi_of(c)
                if b in ("AL", "R"):
                    a[0] += 1
                elif b == "L":
                    a[1] += 1
        changed = 0
        for b in alt.wordlist:
            if not any(tu.is_arabic_letter(c) for c in b["text"]):
                continue
            bx0, by0, bx1, by1 = b["box"]
            pad = 2
            group = [w for w in best.wordlist if w["text"]
                     and bx0 - pad <= (w["box"][0] + w["box"][2]) / 2 <= bx1 + pad
                     and by0 - pad <= (w["box"][1] + w["box"][3]) / 2 <= by1 + pad]
            if not group:
                continue
            ar, lt = line_ar.get(group[0]["key"], (0, 0))
            if ar < lt:
                continue  # English line: keep the bilingual reading
            g_ar = any(any(tu.is_arabic_letter(c) for c in w["text"]) for w in group)
            g_max = max(w["conf"] for w in group)
            g_mean = sum(w["conf"] for w in group) / len(group)
            replace = False
            if not g_ar and g_max < 85:
                replace = True
            elif g_ar and len(group) == 1 and b["conf"] > g_mean + 8:
                replace = True
            if replace:
                group[0]["text"], group[0]["conf"] = b["text"], max(b["conf"], group[0]["conf"])
                for w in group[1:]:
                    w["text"] = ""
                changed += 1
        if changed:
            best.wordlist = [w for w in best.wordlist if w["text"]]
            self._rebuild(best)
            best.variant += f"+ara({changed})"
        return best

    def _ocr_crop(self, img, box, dpi, wd, tag, langs=None):
        """OCR one line/region. Text is normalised to ~20 px height and contrast-stretched:
        Tesseract's line mode often returns nothing for large or pale isolated text."""
        x0, y0, x1, y1 = box
        crop = img.crop(box)
        ink_h = max(8, y1 - y0)
        sc = min(1.0, 20.0 / (ink_h * 0.8))
        if sc < 0.95:
            crop = crop.resize((max(8, int(crop.width * sc)), max(8, int(crop.height * sc))), Image.LANCZOS)
        else:
            sc = 1.0
        crop = ImageOps.expand(ImageOps.autocontrast(crop, cutoff=1), 16, 255)
        eff = max(70, int(dpi * sc))
        saved = self.langs_wanted
        res = None
        try:
            if langs:
                self.langs_wanted = langs
            for psm in (7, 6):
                t, r = self._ocr_once(crop, eff, psm, wd, f"{tag}_{psm}")
                res = self._parse(t, r, eff)
                if res.wordlist:
                    break
        finally:
            self.langs_wanted = saved
        if res is None:
            return []
        out = []
        for w in res.wordlist:
            b = w["box"]
            out.append({"text": w["text"], "conf": w["conf"],
                        "box": (int((b[0] - 16) / sc) + x0, int((b[1] - 16) / sc) + y0, int((b[2] - 16) / sc) + x0, int((b[3] - 16) / sc) + y0)})
        return out

    def _fix_squeezed(self, img, best, dpi, wd, max_words=40):
        """A number or Latin word read with too few characters for the width of its box
        (e.g. '2024' read as '4' by the mixed Arabic+English model) is read again with the
        Latin-script languages only."""
        latin = "+".join(l for l in self.langs_wanted.split("+") if l and l not in ("ara", "fas", "urd", "pus", "heb"))
        if not latin or latin == self.langs_wanted:
            return best
        changed = tried = 0
        for i, w in enumerate(best.wordlist):
            t = w["text"]
            if tried >= max_words:
                break
            if not t or any(tu.is_arabic_letter(c) for c in t):
                continue
            x0, y0, x1, y1 = w["box"]
            bw, bh = x1 - x0, y1 - y0
            if bh < 8 or bw <= 1.5 * bh or bw / (0.5 * bh) < 2.2 * max(1, len(t)):
                continue
            tried += 1
            pad = max(4, bh // 4)
            crop = (max(0, x0 - pad), max(0, y0 - pad), min(img.width, x1 + pad), min(img.height, y1 + pad))
            try:
                words = self._ocr_crop(img, crop, dpi, wd, f"sq{i}", latin)
            except Exception:
                continue
            new = " ".join(x["text"] for x in words).strip()
            if not new or any(tu.is_arabic_letter(c) for c in new):
                continue
            conf = min(x["conf"] for x in words)
            if len(new.replace(" ", "")) > len(t) and conf >= 60:
                w["text"], w["conf"] = new, conf
                changed += 1
        if changed:
            self._rebuild(best)
            best.variant += f"+squeezed({changed})"
        return best

    def _refine_lines(self, img, best, dpi, wd, max_lines=30):
        """Re-read doubtful lines one by one (single-line mode). Page-level layout analysis
        sometimes fails on bold or coloured headings that read perfectly on their own."""
        by_line = {}
        for w in best.wordlist:
            by_line.setdefault(w["key"], []).append(w)
        page_ar = tu.arabic_ratio(" ".join(w["text"] for w in best.wordlist)) >= 0.5
        cands = []
        for key, ws in by_line.items():
            mean = sum(w["conf"] for w in ws) / len(ws)
            junk = page_ar and any(not any(tu.is_arabic_letter(c) for c in w["text"]) and w["conf"] < 85
                                   and re.search(r"[A-Za-z]", w["text"]) for w in ws)
            if mean < 65 or junk:
                cands.append((mean, key, ws))
        if not cands:
            return best
        cands.sort(key=lambda c: c[0])
        changed = 0
        for k, (mean, key, ws) in enumerate(cands[:max_lines]):
            box = best.line_boxes.get(key)
            if not box or box[2] - box[0] < 8 or box[3] - box[1] < 6:
                continue
            pad = max(4, (box[3] - box[1]) // 5)
            crop_box = (max(0, box[0] - pad), max(0, box[1] - pad), min(img.width, box[2] + pad), min(img.height, box[3] + pad))
            line_ar = tu.arabic_ratio(" ".join(w["text"] for w in ws)) >= 0.5 or (page_ar and mean < 50)
            langs = None
            if line_ar and "ara" in self.langs_wanted.split("+"):
                if not re.search(r"[A-Za-z]{3,}", " ".join(w["text"] for w in ws if w["conf"] >= 85)):
                    langs = "ara"
            try:
                words = self._ocr_crop(img, crop_box, dpi, wd, f"line{k}", langs)
            except Exception:
                continue
            if not words:
                continue
            new_mean = sum(w["conf"] for w in words) / len(words)
            if new_mean > mean + 10:
                repl = [{"key": key, "text": w["text"], "conf": w["conf"], "box": w["box"]} for w in words]
                idx = best.wordlist.index(ws[0])
                best.wordlist = [w for w in best.wordlist if w["key"] != key]
                best.wordlist[idx:idx] = repl
                changed += 1
        if changed:
            self._rebuild(best)
            best.variant += f"+lines({changed})"
        return best

    def _uncovered(self, img, best, dpi, wd):
        """Find ink the page-level OCR did not read: missed lines (re-read them) and pictures
        (charts, photos, logos) which are kept as images."""
        scale = 4
        # thicken strokes before shrinking so thin / coloured text is not lost
        small = img.filter(ImageFilter.MinFilter(5)).resize((max(1, img.width // scale), max(1, img.height // scale)), Image.BOX)
        W, H = small.size
        px = small.load()
        covered = [[False] * W for _ in range(H)]

        def junk(ws):
            txt = "".join(w["text"] for w in ws)
            mean = sum(w["conf"] for w in ws) / len(ws)
            real = re.sub(r"[lI1|!ij.,:;\-_'\"`]", "", txt)
            return mean < 50 or sum(1 for c in real if c.isalpha()) < 2

        by_line = {}
        for w in best.wordlist:
            by_line.setdefault(w["key"], []).append(w)
        boxes = []
        for key, ws in by_line.items():
            if junk(ws):
                continue
            if key in best.line_boxes:
                boxes.append(best.line_boxes[key])
            boxes.extend(w["box"] for w in ws)
        for b in boxes:
            x0, y0 = max(0, b[0] // scale - 2), max(0, b[1] // scale - 2)
            x1, y1 = min(W, b[2] // scale + 3), min(H, b[3] // scale + 3)
            for y in range(y0, y1):
                row = covered[y]
                for x in range(x0, x1):
                    row[x] = True
        margin_x, margin_y = int(W * 0.02), int(H * 0.02)
        rows = []
        for y in range(margin_y, H - margin_y):
            cnt, xs = 0, None
            for x in range(margin_x, W - margin_x):
                if px[x, y] < 160 and not covered[y][x]:
                    cnt += 1
                    if xs is None:
                        xs = [x, x]
                    else:
                        xs[1] = x
            rows.append((y, cnt, xs))
        bands, cur = [], None
        min_cnt = max(3, int(0.004 * W))
        for y, cnt, xs in rows:
            if cnt >= min_cnt:
                if cur is None:
                    cur = [y, y, xs[0], xs[1], cnt]
                else:
                    cur[1] = y
                    cur[2], cur[3] = min(cur[2], xs[0]), max(cur[3], xs[1])
                    cur[4] += cnt
            elif cur is not None:
                bands.append(cur)
                cur = None
        if cur is not None:
            bands.append(cur)
        heights = sorted(b[3] - b[1] for b in best.line_boxes.values() if b[3] > b[1])
        line_h = heights[len(heights) // 2] if heights else int(dpi * 0.2)
        new_lines, pictures = [], []
        n_new = 0
        for y0, y1, x0, x1, ink in bands:
            box = (x0 * scale, y0 * scale, (x1 + 1) * scale, (y1 + 1) * scale)
            bw, bh = box[2] - box[0], box[3] - box[1]
            if bw < 16 or bh < 10 or ink < 40:
                continue
            if bh <= 2.6 * line_h:
                pad = max(4, bh // 5)
                cb = (max(0, box[0] - pad), max(0, box[1] - pad), min(img.width, box[2] + pad), min(img.height, box[3] + pad))
                try:
                    words = [w for w in self._ocr_crop(img, cb, dpi, wd, f"miss{n_new}") if w["text"]]
                except Exception:
                    continue
                letters = sum(1 for w in words for c in w["text"] if c.isalpha())
                longest = max((sum(1 for c in w["text"] if c.isalpha()) for w in words), default=0)
                if words and letters >= 3 and longest >= 3 and sum(w["conf"] for w in words) / len(words) >= 70:
                    wb = (min(w["box"][0] for w in words), min(w["box"][1] for w in words),
                          max(w["box"][2] for w in words), max(w["box"][3] for w in words))
                    wh = max(1, wb[3] - wb[1])
                    # continuation of the paragraph right above it?
                    key = ("x", str(n_new), "0", "0")
                    above = None
                    for k2, b2 in best.line_boxes.items():
                        if k2[0] == "x":
                            continue
                        gap = wb[1] - b2[3]
                        h2 = max(1, b2[3] - b2[1])
                        if -0.2 * wh <= gap <= 0.8 * h2 and 0.75 <= wh / h2 <= 1.33:
                            if above is None or b2[3] > best.line_boxes[above][3]:
                                above = k2
                    if above is not None:
                        key = (above[0], above[1], above[2], f"{above[3]}~{n_new}")
                    n_new += 1
                    best.line_boxes[key] = wb
                    for w in words:
                        new_lines.append({"key": key, "text": w["text"], "conf": w["conf"], "box": w["box"]})
                    continue
            if bw * bh >= 0.012 * img.width * img.height and bh >= 3 * line_h:
                inside_words = sum(1 for w in best.wordlist if w["conf"] >= 60
                                   and box[0] <= (w["box"][0] + w["box"][2]) / 2 <= box[2]
                                   and box[1] <= (w["box"][1] + w["box"][3]) / 2 <= box[3])
                if inside_words < 5:  # a ruled table or a framed paragraph is text, not a picture
                    pictures.append(box)
        if pictures:
            # drop junk "text" read inside pictures (e.g. "lll" for the bars of a chart)
            def inside(w):
                cx, cy = (w["box"][0] + w["box"][2]) / 2, (w["box"][1] + w["box"][3]) / 2
                return any(p[0] - 8 <= cx <= p[2] + 8 and p[1] - 8 <= cy <= p[3] + 8 for p in pictures)
            bad_keys = {k for k, ws in by_line.items() if junk(ws) and all(inside(w) for w in ws)}
            best.wordlist = [w for w in best.wordlist if not (w["key"] in bad_keys or (inside(w) and w["conf"] < 70))]
        if new_lines:
            # insert the recovered lines in vertical order
            merged = []
            lines_order = []
            seen = set()
            for w in best.wordlist:
                if w["key"] not in seen:
                    seen.add(w["key"])
                    lines_order.append(w["key"])
            by_key = {}
            for w in best.wordlist + new_lines:
                by_key.setdefault(w["key"], []).append(w)
            new_keys = []
            for w in new_lines:
                if w["key"] not in new_keys:
                    new_keys.append(w["key"])
            for nk in new_keys:
                top = best.line_boxes[nk][1]
                pos = len(lines_order)
                for i, k in enumerate(lines_order):
                    if best.line_boxes.get(k, (0, 1e9, 0, 0))[1] > top:
                        pos = i
                        break
                lines_order.insert(pos, nk)
            # keep lines of one paragraph together (a continuation line joins its paragraph)
            grouped, seen_p = [], {}
            for k in lines_order:
                seen_p.setdefault(k[:3], []).append(k)
            done = set()
            for k in lines_order:
                if k[:3] in done:
                    continue
                done.add(k[:3])
                grouped.extend(seen_p[k[:3]])
            lines_order = grouped
            for k in lines_order:
                merged.extend(by_key.get(k, []))
            best.wordlist = merged
        best.pictures = pictures
        if new_lines or pictures:
            self._rebuild(best)
        return best

    def ocr(self, img: Image.Image, dpi: int = 300, psm: int = 3) -> OcrResult:
        """OCR with automatic clean-up: if the first pass is not confident, try de-speckled and
        binarised versions of the scan and keep the reading Tesseract is most confident about."""
        if not self.exe:
            raise RuntimeError("Tesseract غير مثبت")
        gray = ImageOps.autocontrast(img.convert("L"))
        tried = []
        with tempfile.TemporaryDirectory(prefix="p2w_ocr_") as wd:
            text, rows = self._ocr_once(gray, dpi, psm, wd, "a")
            res = self._parse(text, rows, dpi)
            res.variant = "plain"
            tried.append(res)
            if res.conf < 90 or res.words < 5:
                med = gray.filter(ImageFilter.MedianFilter(3))
                thr = _otsu(med)
                variants = [("median", med), ("median+binary", med.point(lambda v, t=thr: 255 if v > t else 0))]
                for name, im in variants:
                    try:
                        t2, r2 = self._ocr_once(im, dpi, psm, wd, name.replace("+", "_"))
                        alt = self._parse(t2, r2, dpi)
                        alt.variant = name
                        tried.append(alt)
                    except Exception:
                        continue
                if max(r.conf for r in tried) < 85:
                    try:
                        im5 = gray.filter(ImageFilter.MedianFilter(5))
                        t3, r3 = self._ocr_once(im5, dpi, psm, wd, "median5")
                        alt = self._parse(t3, r3, dpi)
                        alt.variant = "median5"
                        tried.append(alt)
                    except Exception:
                        pass
            most_words = max(r.words for r in tried)
            ok = [r for r in tried if r.words >= 0.7 * most_words] or tried
            best = max(ok, key=lambda r: r.conf)
            imgs = {"plain": gray}
            if best.variant != "plain":
                if best.variant == "median5":
                    imgs[best.variant] = gray.filter(ImageFilter.MedianFilter(5))
                else:
                    med = gray.filter(ImageFilter.MedianFilter(3))
                    thr = _otsu(med)
                    imgs["median"] = med
                    imgs["median+binary"] = med.point(lambda v, t=thr: 255 if v > t else 0)
            used = imgs.get(best.variant, gray)
            try:
                best = self._arabic_second_opinion(used, best, dpi, psm, wd)
            except Exception:
                pass
            try:
                best = self._fix_squeezed(used, best, dpi, wd)
            except Exception:
                pass
            try:
                best = self._refine_lines(used, best, dpi, wd)
            except Exception:
                pass
            try:
                best = self._uncovered(used, best, dpi, wd)
            except Exception:
                pass
        return best


def _otsu(img: Image.Image) -> int:
    hist = img.histogram()[:256]
    total = sum(hist)
    sum_all = sum(i * h for i, h in enumerate(hist))
    wb = sb = 0.0
    best, thr = -1.0, 128
    for t in range(256):
        wb += hist[t]
        if wb == 0:
            continue
        wf = total - wb
        if wf == 0:
            break
        sb += t * hist[t]
        mb, mf = sb / wb, (sum_all - sb) / wf
        between = wb * wf * (mb - mf) ** 2
        if between > best:
            best, thr = between, t
    return thr


# ----------------------------------------------------------------------------------------------
# OCR result -> paragraphs
# ----------------------------------------------------------------------------------------------
_LIST_START = re.compile(r"^\s*(?:[•▪●○■□◆➢►✓✔\-–*]|\(?[0-9٠-٩]{1,3}[.)\-]|\(?[a-zA-Z][.)])\s+")
_PCT_FIX = re.compile(r"(?<![\w%٪])([%٪])([0-9٠-٩]+(?:[.,٫][0-9٠-٩]+)?)(?![\w])")


_AR = "\u0621-\u064A\u0671-\u06D3"


def fix_ocr_rtl_quirks(text: str) -> str:
    # Tesseract writes "45%" in Arabic text as "%45" (visual order); restore the logical form.
    text = _PCT_FIX.sub(lambda m: m.group(2) + m.group(1), text)
    # Latin punctuation between Arabic words -> Arabic punctuation (as printed in Arabic texts)
    text = re.sub(rf"(?<=[{_AR}\u064B-\u0652])\s?,(?=\s+[{_AR}])", "،", text)
    text = re.sub(rf"(?<=[{_AR}\u064B-\u0652])\s?;(?=\s+[{_AR}])", "؛", text)
    text = re.sub(rf"(?<=[{_AR}\u064B-\u0652])\s?\?(?=\s|$)", "؟", text)
    # list bullets read as Arabic zero / "o"
    text = re.sub(r"^[٠o°·*]\s+(?=\S)", "• ", text)
    m = re.match(r"^(.*\S)\s+[٠•]$", text)
    if m and not text.startswith("•"):
        text = "• " + m.group(1)
    return text


def ocr_to_paragraphs(res: OcrResult, page_w: float) -> list:
    """Build Word paragraphs (with heading guesses and centring) from Tesseract structure."""
    all_lines = [l for p in res.paragraphs for l in p if l.text.strip()]
    if not all_lines:
        return []
    heights = sorted(l.height for l in all_lines if l.height > 0)
    med_h = heights[len(heights) // 2] if heights else 12.0
    tx0 = min(l.bbox[0] for l in all_lines)
    tx1 = max(l.bbox[2] for l in all_lines)
    mid, tw = (tx0 + tx1) / 2, max(tx1 - tx0, 1)
    paras = []
    for plines in res.paragraphs:
        groups = []
        for ln in plines:
            if not ln.text.strip():
                continue
            prev = groups[-1][-1] if groups else None
            size_jump = prev is not None and prev.height > 0 and ln.height > 0 and max(prev.height, ln.height) / min(prev.height, ln.height) >= 1.3
            if groups and not _LIST_START.match(ln.text) and not size_jump:
                groups[-1].append(ln)
            else:
                groups.append([ln])
        for g in groups:
            text = g[0].text
            rtl = tu.is_rtl_text(" ".join(l.text for l in g))
            for ln in g[1:]:
                if not rtl and text.endswith("-") and len(text) > 1 and text[-2].isalpha() and ln.text[:1].islower():
                    text = text[:-1] + ln.text
                else:
                    text += " " + ln.text
            text = re.sub(r"\s+", " ", text).strip()
            if rtl:
                text = fix_ocr_rtl_quirks(text)
            h = sorted(l.height for l in g)[len(g) // 2]
            p = Paragraph(runs=[Run(text)], rtl=rtl, source="ocr", line_count=len(g),
                          bbox=(min(l.bbox[0] for l in g), min(l.bbox[1] for l in g), max(l.bbox[2] for l in g), max(l.bbox[3] for l in g)))
            ratio = h / med_h if med_h else 1
            if ratio >= 1.3 and len(text) < 120 and len(g) <= 2:
                p.heading = 1 if ratio >= 1.8 else 2
                p.runs[0].bold = True
            w = p.bbox[2] - p.bbox[0]
            if abs((p.bbox[0] + p.bbox[2]) / 2 - mid) < 0.04 * tw and w < 0.8 * tw:
                p.align = "center"
            paras.append(p)
    return paras
