# -*- coding: utf-8 -*-
"""Command line interface (for advanced users and scheduled runs)."""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

from . import __version__
from . import batch
from . import settings as st
from .ai import PROVIDERS


def _print(msg):
    try:
        print(msg, flush=True)
    except UnicodeEncodeError:
        print(msg.encode("utf-8", "replace").decode("ascii", "replace"), flush=True)


def main(argv=None):
    p = argparse.ArgumentParser(prog="PDF2Word-AI",
                                description="Convert all PDF files in drives/folders/Google Drive to Word (.docx). By Boutib Ahmed.",
                                epilog="PDF2Word AI — من إنجاز بوطيب أحمد (Boutib Ahmed)")
    p.add_argument("sources", nargs="*", help="drives, folders, PDF or ZIP files, or Google Drive links")
    p.add_argument("-o", "--out", help="output folder for Word files (default: from settings)")
    p.add_argument("--beside", action="store_true", help="save each .docx next to its PDF")
    p.add_argument("--no-skip", action="store_true", help="convert again even if the .docx already exists")
    p.add_argument("--lang", help="OCR languages, e.g. ara+eng")
    p.add_argument("--no-ocr", action="store_true", help="do not OCR scanned pages")
    p.add_argument("--force-ocr", action="store_true", help="OCR every page")
    p.add_argument("--ai", choices=["none"] + list(PROVIDERS), help="AI correction provider")
    p.add_argument("--key", help="AI API key")
    p.add_argument("--model", help="AI model name")
    p.add_argument("--base-url", help="AI server URL (Ollama / OpenAI-compatible)")
    p.add_argument("--workers", type=int, help="files processed in parallel")
    p.add_argument("--password", help="password for protected PDFs")
    p.add_argument("--mode", choices=["auto", "exact"], help="conversion mode")
    p.add_argument("--drive", action="append", default=[], metavar="LINK", help="Google Drive folder/file link (repeatable)")
    p.add_argument("--drive-key", help="Google Drive API key (for folders shared with 'anyone with the link')")
    p.add_argument("--zip", dest="zip_output", action="store_true", default=None, help="put all Word files in one ZIP")
    p.add_argument("--no-zip", dest="zip_output", action="store_false", help="do not create the ZIP")
    p.add_argument("--ai-pack", dest="ai_pack", action="store_true", default=None, help="create the compact AI_READY copy")
    p.add_argument("--no-ai-pack", dest="ai_pack", action="store_false", help="do not create the AI_READY copy")
    p.add_argument("--strip-tashkeel", action="store_true", help="remove Arabic diacritics in the AI_READY copy")
    p.add_argument("--make-ai-pack", metavar="FOLDER", help="only build an AI_READY copy (and the analysis, with --analyze) "
                   "from the Word files in FOLDER")
    p.add_argument("--analyze", action="store_true", help="analyse the content with the configured free AI service")
    p.add_argument("--analysis-prompt", metavar="TEXT", help="your own analysis instructions")
    p.add_argument("--analysis-lang", choices=["ar", "en", "auto"], help="language of the analysis")
    p.add_argument("--no-overall", action="store_true", help="no combined report over all documents")
    p.add_argument("--markdown", "--md", dest="markdown", action="store_true",
                   help="also write a Markdown (.md) file next to every Word file")
    p.add_argument("--no-other-files", action="store_true",
                   help="do not convert Word/PowerPoint/Excel/CSV/HTML/text files to Markdown")
    p.add_argument("--ocr-engine", choices=["auto", "tesseract", "embedded"], help="OCR engine")
    p.add_argument("--list-drives", action="store_true", help="list drives and exit")
    p.add_argument("--check", action="store_true", help="check OCR / AI setup and exit")
    p.add_argument("--save", action="store_true", help="save these options as the new defaults")
    p.add_argument("--version", action="version", version=f"PDF2Word AI {__version__} — من إنجاز بوطيب أحمد (Boutib Ahmed)")
    a = p.parse_args(argv)

    s = st.load_settings()
    if a.out:
        s["output_dir"] = a.out
        s["output_mode"] = "folder"
    if a.beside:
        s["output_mode"] = "beside"
    if a.no_skip:
        s["skip_existing"] = False
    if a.lang:
        s["ocr_lang"] = a.lang
    if a.no_ocr:
        s["ocr_enabled"] = False
    if a.force_ocr:
        s["force_ocr"] = True
    if a.ai:
        s["ai_enabled"] = a.ai != "none"
        if a.ai != "none":
            s["ai_provider"] = a.ai
    if a.key:
        s["ai_api_key"] = a.key
    if a.model:
        s["ai_model"] = a.model
    if a.base_url:
        s["ai_base_url"] = a.base_url
    if a.workers:
        s["workers"] = a.workers
    if a.password:
        s["password"] = a.password
    if a.mode:
        s["mode"] = a.mode
    if a.drive_key:
        s["drive_api_key"] = a.drive_key
    if a.zip_output is not None:
        s["zip_output"] = a.zip_output
    if a.ai_pack is not None:
        s["ai_pack"] = a.ai_pack
    if a.strip_tashkeel:
        s["ai_pack_strip_tashkeel"] = True
    if a.ocr_engine:
        s["ocr_engine"] = a.ocr_engine
    if a.markdown:
        s["markdown_output"] = True
    if a.no_other_files:
        s["scan_other_files"] = False
    if a.analyze:
        s["analysis_enabled"] = True
    if a.analysis_prompt:
        s["analysis_prompt"] = a.analysis_prompt
    if a.analysis_lang:
        s["analysis_language"] = a.analysis_lang
    if a.no_overall:
        s["analysis_overall"] = False
    s = st.coerce(s)
    if a.save:
        st.save_settings(s)

    if a.list_drives:
        for d in batch.list_drives():
            _print(f"{d['path']}\t{d['label']}")
        return 0
    if a.check:
        from .webui import system_check
        _print(json.dumps(system_check(s), ensure_ascii=False, indent=1))
        if s.get("ai_enabled"):
            from .ai import make_provider, AIError
            try:
                prov = make_provider(s, log=_print)
                _print("AI: " + prov.generate("You are a test.", "Reply with the single word: OK", None, max_tokens=64))
            except AIError as e:
                _print(f"AI error: {e}")
        return 0
    if a.make_ai_pack:
        job = batch.Job([], s, pack_folder=a.make_ai_pack)
        return _run_job(job)
    sources = list(a.sources) + list(a.drive)
    if not sources:
        p.print_help()
        return 2

    return _run_job(batch.Job(sources, s))


def _run_job(job):
    since = 0
    job.start()
    try:
        while job.thread.is_alive():
            time.sleep(0.5)
            snap = job.snapshot(since)
            for l in snap["logs"]:
                _print(f"[{l['t']}] {l['msg']}")
                since = l["id"]
    except KeyboardInterrupt:
        job.stop()
        job.thread.join()
    snap = job.snapshot(since)
    for l in snap["logs"]:
        _print(f"[{l['t']}] {l['msg']}")
    return 0 if snap["failed"] == 0 and snap["phase"] != "error" else 1
