# -*- coding: utf-8 -*-
"""Find PDF files on drives/folders and convert them in bulk (with resume, report, workers)."""
from __future__ import annotations

import csv
import json
import os
import secrets
import shutil
import string
import sys
import threading
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime

from . import aiexport, analysis, archives, gdrive, tomarkdown
from .converter import Converter, FileReport, long_path
from .ocr import app_data_dir
from .settings import coerce

IS_WIN = sys.platform.startswith("win")

# Folders that never contain user documents (skipped unless the user asks otherwise)
SKIP_ANYWHERE = {"$recycle.bin", "system volume information", "$windows.~bt", "$windows.~ws", "$sysreset",
                 "appdata", "node_modules", ".git", "__pycache__", ".trash", ".trashes", ".spotlight-v100",
                 ".fseventsd", ".cache", "lost+found", ".tmp.drivedownload", ".tmp.driveupload"}
SKIP_AT_ROOT = {"windows", "program files", "program files (x86)", "programdata", "recovery", "perflogs",
                "msocache", "intel", "boot", "proc", "sys", "dev", "run", "snap", "usr", "bin", "sbin", "lib",
                "lib64", "etc", "var", "opt", "private", "system", "library", "cores"}


def list_drives():
    """Drives and common places the user can pick from."""
    out = []
    if IS_WIN:
        try:
            import ctypes
            mask = ctypes.windll.kernel32.GetLogicalDrives()
            for i, letter in enumerate(string.ascii_uppercase):
                if not mask & (1 << i):
                    continue
                root = f"{letter}:\\"
                dtype = ctypes.windll.kernel32.GetDriveTypeW(root)
                if dtype in (0, 1):  # unknown / no root dir
                    continue
                label_buf = ctypes.create_unicode_buffer(261)
                ok = ctypes.windll.kernel32.GetVolumeInformationW(root, label_buf, 261, None, None, None, None, 0)
                if not ok and dtype == 5:  # empty CD drive
                    continue
                kind = {2: "قرص قابل للإزالة", 3: "قرص محلي", 4: "قرص شبكة", 5: "قرص مضغوط", 6: "قرص RAM"}.get(dtype, "قرص")
                label = label_buf.value or kind
                if os.path.isdir(os.path.join(root, "My Drive")) or "google" in label.lower():
                    kind = "Google Drive"
                out.append({"path": root, "label": f"{letter}: — {label}", "kind": kind})
        except Exception:
            for letter in string.ascii_uppercase:
                root = f"{letter}:\\"
                if os.path.exists(root):
                    out.append({"path": root, "label": f"{letter}:", "kind": "قرص"})
    else:
        out.append({"path": "/", "label": "/ (النظام)", "kind": "قرص"})
        for base in ("/Volumes", "/media", "/mnt", "/run/media"):
            if os.path.isdir(base):
                try:
                    for name in sorted(os.listdir(base)):
                        p = os.path.join(base, name)
                        if os.path.isdir(p):
                            out.append({"path": p, "label": name, "kind": "قرص خارجي"})
                except OSError:
                    pass
    home = os.path.expanduser("~")
    places = [("المستندات", "Documents"), ("سطح المكتب", "Desktop"), ("التنزيلات", "Downloads")]
    for label, sub in places:
        p = os.path.join(home, sub)
        if os.path.isdir(p):
            out.append({"path": p, "label": label, "kind": "مجلد"})
    for cand in google_drive_paths():
        out.append({"path": cand, "label": "Google Drive (" + os.path.basename(cand.rstrip("\\/")) + ")", "kind": "Google Drive"})
    od = os.environ.get("OneDrive")
    if od and os.path.isdir(od):
        out.append({"path": od, "label": "OneDrive", "kind": "OneDrive"})
    out.append({"path": home, "label": "مجلد المستخدم", "kind": "مجلد"})
    seen, uniq = set(), []
    for d in out:
        k = os.path.normcase(os.path.abspath(d["path"]))
        if k not in seen:
            seen.add(k)
            uniq.append(d)
    return uniq


def google_drive_paths():
    """Folders where Google Drive for desktop keeps synced files."""
    home = os.path.expanduser("~")
    cands = []
    if IS_WIN:
        for letter in string.ascii_uppercase:
            for sub in ("My Drive", "Mon Drive", "Shared drives", "Mi unidad"):
                p = f"{letter}:\\{sub}"
                if os.path.isdir(p):
                    cands.append(p)
    cs = os.path.join(home, "Library", "CloudStorage")
    if os.path.isdir(cs):
        try:
            for n in os.listdir(cs):
                if n.lower().startswith("googledrive"):
                    cands.append(os.path.join(cs, n))
        except OSError:
            pass
    for n in ("Google Drive", "GoogleDrive", "My Drive"):
        p = os.path.join(home, n)
        if os.path.isdir(p):
            cands.append(p)
    return cands


def browse(path: str):
    """Sub-folders of path (for the folder picker)."""
    path = os.path.abspath(os.path.expanduser(path))
    dirs = []
    pdfs = 0
    zips = []
    try:
        with os.scandir(path) as it:
            for e in it:
                try:
                    if e.is_dir(follow_symlinks=False):
                        if not e.name.startswith(".") and e.name.lower() not in SKIP_ANYWHERE:
                            dirs.append(e.name)
                    elif e.name.lower().endswith(".pdf"):
                        pdfs += 1
                    elif e.name.lower().endswith(".zip"):
                        zips.append(e.name)
                except OSError:
                    continue
    except OSError as e:
        return {"path": path, "parent": os.path.dirname(path), "dirs": [], "pdfs": 0, "zips": [], "error": str(e)}
    dirs.sort(key=str.lower)
    parent = os.path.dirname(path.rstrip("\\/")) or path
    if IS_WIN and len(path) <= 3:
        parent = ""
    return {"path": path, "parent": parent if parent != path else "", "dirs": dirs, "pdfs": pdfs,
            "zips": sorted(zips, key=str.lower)[:200]}


def _is_junction(p):
    try:
        return os.path.isjunction(p)  # Python 3.12+
    except AttributeError:
        return False


def iter_pdfs(root, include_system=False, exclude=(), stop=None, exts=(".pdf",)):
    root = os.path.abspath(root)
    if os.path.isfile(root):
        if root.lower().endswith(exts):
            yield root
        return
    excl = {os.path.normcase(os.path.abspath(e)) for e in exclude if e}
    stack = [root]
    while stack:
        if stop is not None and stop.is_set():
            return
        d = stack.pop()
        try:
            with os.scandir(long_path(d)) as it:
                entries = list(it)
        except OSError:
            continue
        subdirs = []
        for e in entries:
            name = e.name
            full = os.path.join(d, name)
            try:
                if e.is_symlink() or _is_junction(full):
                    continue
                if e.is_dir(follow_symlinks=False):
                    low = name.lower()
                    if not include_system:
                        if low in SKIP_ANYWHERE:
                            continue
                        if os.path.dirname(full.rstrip("\\/")) in (os.path.splitdrive(full)[0] + os.sep, "/") and low in SKIP_AT_ROOT:
                            continue
                    if os.path.normcase(full) in excl:
                        continue
                    subdirs.append(full)
                elif name.lower().endswith(exts) and not name.startswith(("~$", ".~")) and not name.endswith(".part"):
                    try:
                        if e.stat().st_size > 0:
                            yield full
                    except OSError:
                        continue
            except OSError:
                continue
        stack.extend(sorted(subdirs, reverse=True))


def root_label(root):
    root = os.path.abspath(root)
    drive, rest = os.path.splitdrive(root)
    name = os.path.basename(root.rstrip("\\/"))
    if not name:
        name = (drive.rstrip(":\\/") or "root") + "_drive"
    return name


def uploads_dir():
    d = os.path.join(app_data_dir(), "uploads")
    os.makedirs(d, exist_ok=True)
    return d


def downloads_dir():
    d = os.path.join(app_data_dir(), "downloads")
    os.makedirs(d, exist_ok=True)
    return d


def work_dir():
    d = os.path.join(app_data_dir(), "work")
    os.makedirs(d, exist_ok=True)
    return d


def cleanup_old(days=3):
    """Remove upload sessions / leftovers of crashed runs older than `days`."""
    limit = time.time() - days * 86400
    for base in (os.path.join(app_data_dir(), "uploads"), os.path.join(app_data_dir(), "work")):
        if not os.path.isdir(base):
            continue
        for n in os.listdir(base):
            p = os.path.join(base, n)
            try:
                if os.path.isdir(p) and os.path.getmtime(p) < limit:
                    shutil.rmtree(p, ignore_errors=True)
            except OSError:
                pass


@dataclass
class Root:
    """One source of PDFs, already available locally."""
    path: str  # folder (or single PDF) to scan
    label: str  # unique name, used as the output sub-folder and inside the ZIP
    kind: str = "local"  # local | zip | drive | upload
    out_base: str | None = None  # where the Word files go; None = next to each PDF
    display: str = ""  # shown instead of the local path (Drive / ZIP / uploads)
    temp: str | None = None  # deleted at the end of the run
    cache: str | None = None  # Drive download cache (deleted unless keep_downloads)


def plan_output(root: Root, pdf: str) -> str:
    stem, ext = os.path.splitext(os.path.basename(pdf))
    # Word, PowerPoint, Excel, CSV, HTML and text files become Markdown; PDFs become Word
    base = stem + (".md" if ext.lower() in tomarkdown.OTHER_EXTS else ".docx")
    if root.out_base is None:
        return os.path.join(os.path.dirname(pdf), base)
    if os.path.isfile(root.path):
        return os.path.join(root.out_base, base)
    rel = os.path.relpath(os.path.dirname(pdf), root.path)
    if rel in (".", ""):
        return os.path.join(root.out_base, base)
    return os.path.join(root.out_base, rel, base)


def arc_name(root: Root, out: str) -> str:
    """Path of a Word file inside the result ZIP (and its name in the AI package)."""
    if root.out_base is None:
        base = root.path if os.path.isdir(root.path) else os.path.dirname(root.path)
        return os.path.join(root.label, os.path.relpath(out, base))
    rel = os.path.relpath(out, root.out_base)
    if os.path.isfile(root.path) and root.kind == "local":
        return rel
    return os.path.join(root.label, rel)


# ----------------------------------------------------------------------------------------------
# Worker process support (Windows uses "spawn": everything must be importable)
# ----------------------------------------------------------------------------------------------
_WCONV = None


def _worker_init(settings):
    global _WCONV
    logs = []
    _WCONV = (Converter(settings, log=logs.append), logs)


def _worker_convert(pdf, out):
    conv, logs = _WCONV
    del logs[:]
    rep = conv.convert(pdf, out)
    rep.log = list(logs) + rep.log
    return rep.to_dict()


RUNNING = ("preparing", "listing", "downloading", "scanning", "converting", "packaging", "analyzing")


class Job:
    """A batch run. Thread-safe state is read by the web UI."""

    def __init__(self, sources, settings, pack_folder=None):
        self.sources = [s for s in sources if s]
        self.pack_folder = os.path.abspath(pack_folder) if pack_folder else None  # only package / analyse Word files
        self.s = coerce(settings)
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.logs = []
        self.phase = "idle"
        self.found = 0
        self.total = 0
        self.done = 0
        self.ok = self.warn = self.failed = self.skipped = 0
        self.current = ""
        self.page_info = ""
        self.results = []
        self.report_path = ""
        self.zip_path = ""
        self.pack_dir = ""
        self.pack_info = {}
        self.analysis_path = ""
        self.analysis_info = {}
        self.an = {}
        self.claude_parts = []
        self.dl = {}
        self.started = None
        self.finished = None
        self.thread = None
        self.roots = []
        self.display = {}  # local pdf path -> name shown to the user
        self.arcs = {}  # output path -> name inside the ZIP
        self._labels = set()
        self.job_id = datetime.now().strftime("%Y%m%d_%H%M%S_") + secrets.token_hex(3)

    # -- state helpers -----------------------------------------------------------------
    def log(self, msg, level="info"):
        with self.lock:
            self.logs.append({"id": len(self.logs) + 1, "t": datetime.now().strftime("%H:%M:%S"), "level": level, "msg": str(msg)})
            if len(self.logs) > 5000:
                self.logs = self.logs[-4000:]

    @property
    def running(self):
        return self.phase in RUNNING or bool(self.thread and self.thread.is_alive())

    def snapshot(self, since=0):
        with self.lock:
            logs = [l for l in self.logs if l["id"] > since]
            el = (self.finished or time.time()) - self.started if self.started else 0
            eta = None
            if self.done and self.total and self.phase == "converting":
                eta = el / self.done * max(0, self.total - self.done - self.skipped)
            engines = {}
            for r in self.results:
                for k, v in (r.get("engines") or {}).items():
                    engines[k] = engines.get(k, 0) + v
            return {"phase": self.phase, "found": self.found, "total": self.total, "done": self.done, "ok": self.ok,
                    "warn": self.warn, "failed": self.failed, "skipped": self.skipped, "current": self.current,
                    "page": self.page_info, "logs": logs, "report": self.report_path, "elapsed": int(el),
                    "eta": int(eta) if eta is not None else None, "zip": self.zip_path, "ai_pack": self.pack_dir,
                    "pack": self.pack_info, "dl": dict(self.dl), "engines": engines, "analysis": self.analysis_path,
                    "an": dict(self.an), "analysis_info": self.analysis_info, "claude_parts": list(self.claude_parts),
                    "output_dir": self.s["output_dir"] if self.s["output_mode"] == "folder" or any(
                        r.kind != "local" for r in self.roots) else ""}

    def start(self):
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        self.log("جارٍ الإيقاف… سيُكمل البرنامج الملف الحالي ثم يتوقف.", "warn")

    def _unique_label(self, lab):
        lab = gdrive.safe_name(lab, 80)
        k, base = 2, lab
        while lab.lower() in self._labels:
            lab = f"{base}_{k}"
            k += 1
        self._labels.add(lab.lower())
        return lab

    def _report_dir(self):
        if self.pack_folder:
            return self.pack_folder
        if self.s["output_mode"] == "folder" or any(r.kind != "local" for r in self.roots):
            return self.s["output_dir"]
        return os.path.join(os.path.expanduser("~"), "Documents", "PDF2Word")

    def _dl_progress(self, phase, **kw):
        with self.lock:
            self.dl.update(kw)
            self.dl["phase"] = phase
            if phase == "listing":
                self.current = f"قراءة المجلدات: {kw.get('folders', 0)} مجلد، {kw.get('files', 0)} ملف"
            else:
                self.current = f"تنزيل {kw.get('done', 0)}/{kw.get('total', 0)}"

    # -- main --------------------------------------------------------------------------
    def run(self):
        self.started = time.time()
        try:
            self._run()
        except Exception as e:
            import traceback
            self.log(f"خطأ غير متوقع: {e}", "error")
            self.log(traceback.format_exc()[-1500:], "error")
            self.phase = "error"
        finally:
            try:
                self._cleanup()
            except Exception:
                pass
            self.finished = time.time()

    # -- sources -----------------------------------------------------------------------
    def _prepare_sources(self):
        s = self.s
        ups = os.path.normcase(os.path.abspath(uploads_dir()))
        for src in self.sources:
            if self.stop_event.is_set():
                return
            src = str(src).strip().strip('"')
            if gdrive.is_drive_link(src):
                r = self._fetch_drive(src)
                if r:
                    self.roots.append(r)
                continue
            path = os.path.abspath(os.path.expanduser(src))
            if not os.path.exists(path):
                self.log(f"المسار غير موجود: {src}", "error")
                continue
            if os.path.isfile(path) and path.lower().endswith(".zip"):
                label = self._unique_label(os.path.splitext(os.path.basename(path))[0])
                out_base = os.path.join(s["output_dir"], label) if s["output_mode"] == "folder" \
                    else os.path.splitext(path)[0] + "_Word"
                r = self._extract_zip(path, label, out_base, path)
                if r:
                    self.roots.append(r)
                continue
            if os.path.normcase(path).startswith(ups + os.sep):
                label = self._unique_label(os.path.basename(path.rstrip("\\/")) or "ملفات_مرفوعة")
                self.roots.append(Root(path, label, "upload", os.path.join(s["output_dir"], label), display="مرفوع › "))
                continue
            label = self._unique_label(root_label(path))
            if s["output_mode"] == "folder":
                out_base = s["output_dir"] if os.path.isfile(path) else os.path.join(s["output_dir"], label)
            else:
                out_base = None
            self.roots.append(Root(path, label, "local", out_base))

    def _extract_zip(self, zpath, label, out_base, display):
        dest = os.path.join(work_dir(), self.job_id, f"zip{len(self.roots)}_{secrets.token_hex(2)}")
        self.current = os.path.basename(zpath)
        n = archives.extract_pdfs(zpath, dest, log=lambda m: self.log(m, "warn"))
        self.log(f"🗜 {os.path.basename(zpath)}: استُخرج {n} ملف PDF")
        if not n:
            shutil.rmtree(dest, ignore_errors=True)
            return None
        return Root(dest, label, "zip", out_base, display=f"{display} › ", temp=dest)

    def _fetch_drive(self, link):
        s = self.s
        self.phase = "listing"
        try:
            fx = gdrive.Fetcher(link, api_key=s["drive_api_key"], oauth=gdrive.OAuth(), log=self.log,
                                progress=self._dl_progress, stop=self.stop_event, include_zips=s["scan_zips"])
            info = fx.resolve()
            label = self._unique_label(info["label"])
            fx.list()
            if self.stop_event.is_set():
                return None
            cache = os.path.join(downloads_dir(), f"{gdrive.safe_name(info['label'], 60)}_{info['id'][:12]}")
            out_base = os.path.join(s["output_dir"], label)
            skip_existing = s["skip_existing"]

            def should_skip(rel, mts):
                if not skip_existing:
                    return None
                out = os.path.join(out_base, os.path.splitext(rel)[0] + ".docx")
                try:
                    if os.path.getsize(long_path(out)) > 0 and os.path.getmtime(long_path(out)) >= mts:
                        return out
                except OSError:
                    pass
                return None

            self.phase = "downloading"
            stats = fx.download(cache, s["drive_threads"], should_skip)
        except gdrive.DriveError as e:
            self.log(f"Google Drive: {e}", "error")
            return None
        root = Root(cache, label, "drive", out_base, display=f"Drive › {info['name']} › ", cache=cache)
        for rel, out in stats["skipped"]:
            src = os.path.join(cache, rel)
            self.display[src] = root.display + rel
            self.arcs[out] = os.path.join(label, os.path.splitext(rel)[0] + ".docx")
            self._record(FileReport(source=src, output=out, status="skipped", message="محوّل مسبقاً").to_dict(), quiet=True)
        parts = [f"نُزّل {stats['downloaded']}"]
        if stats["cached"]:
            parts.append(f"موجود مسبقاً {stats['cached']}")
        if stats["skipped"]:
            parts.append(f"لم يُنزَّل لأنه محوّل مسبقاً {len(stats['skipped'])}")
        if stats["failed"]:
            parts.append(f"فشل {len(stats['failed'])}")
        self.log("Google Drive: " + "، ".join(parts) + ".", "warn" if stats["failed"] else "success")
        for rel, err in stats["failed"]:
            self._record(FileReport(source=root.display + rel, output="", status="error",
                                    message=f"تعذّر التنزيل: {err}").to_dict(), quiet=True)
        return root

    # -- run -----------------------------------------------------------------------------
    def _run(self):
        s = self.s
        if self.pack_folder:
            return self._run_pack_only()
        self.phase = "preparing"
        self._prepare_sources()
        if self.stop_event.is_set():
            self.phase = "stopped"
            self.log("تم الإيقاف.", "warn")
            return
        self.phase = "scanning"
        self.log("جارٍ البحث عن ملفات PDF…")
        exclude = [s["output_dir"]] if s["output_mode"] == "folder" else []
        exclude += [os.path.join(app_data_dir(), d) for d in ("uploads", "downloads", "work")]
        files, zips_done = [], 0
        # files already settled before the scan (Drive files skipped without download, failed downloads)
        seen = {os.path.normcase(os.path.abspath(r["source"])) for r in self.results if os.path.isabs(r.get("source", ""))}
        queue = list(self.roots)
        while queue:
            root = queue.pop(0)
            own = [e for e in exclude if os.path.normcase(os.path.abspath(e)) != os.path.normcase(root.path)
                   and not os.path.normcase(root.path).startswith(os.path.normcase(os.path.abspath(e)) + os.sep)]
            exts = (".pdf",)
            if s["scan_zips"] and root.kind != "zip":
                exts += (".zip",)
            if s["scan_other_files"]:
                exts += tomarkdown.OTHER_EXTS
            for path in iter_pdfs(root.path, s["include_system_folders"], own, self.stop_event, exts):
                if path.lower().endswith(".zip"):
                    if os.path.isfile(root.path):
                        continue
                    rel_dir = os.path.relpath(os.path.dirname(path), root.path)
                    stem = os.path.splitext(os.path.basename(path))[0]
                    parts = [p for p in (rel_dir, stem) if p not in (".", "")]
                    label = os.path.join(root.label, *parts)
                    if root.out_base is not None:
                        out_base = os.path.join(root.out_base, *parts)
                    else:
                        out_base = os.path.splitext(path)[0] + "_Word"
                    try:
                        if os.path.getsize(path) > 4 * 1024 ** 3:
                            self.log(f"تجاهل ملف ZIP كبير جداً: {path}", "warn")
                            continue
                    except OSError:
                        continue
                    disp = (root.display + os.path.relpath(path, root.path)) if root.display else path
                    r = self._extract_zip(path, label, out_base, disp)
                    if r:
                        zips_done += 1
                        self.roots.append(r)
                        queue.append(r)
                    continue
                key = os.path.normcase(os.path.abspath(path))
                if key in seen:
                    continue
                seen.add(key)
                files.append((root, path))
                if root.display:
                    self.display[path] = root.display + os.path.relpath(path, root.path)
                with self.lock:
                    self.found = len(files)
                    if len(files) % 50 == 0:
                        self.current = self.display.get(path, path)
        if self.stop_event.is_set():
            self.phase = "stopped"
            self.log("تم الإيقاف.", "warn")
            return
        self.log(f"تم العثور على {len(files)} ملف PDF" + (f" (منها ما في {zips_done} ملف ZIP)" if zips_done else "") + ".")
        # plan outputs (avoid name clashes, skip already converted)
        tasks, planned = [], {os.path.normcase(o) for o in self.arcs}
        for root, pdf in files:
            out = plan_output(root, pdf)
            stem, k = out[:-5], 2
            while os.path.normcase(out) in planned:
                out = f"{stem} ({k}).docx"
                k += 1
            planned.add(os.path.normcase(out))
            self.arcs[out] = arc_name(root, out)
            if s["skip_existing"] and os.path.exists(long_path(out)):
                try:
                    if os.path.getmtime(long_path(out)) >= os.path.getmtime(long_path(pdf)) and os.path.getsize(long_path(out)) > 0:
                        self._record(FileReport(source=pdf, output=out, status="skipped", message="محوّل مسبقاً").to_dict(), quiet=True)
                        continue
                except OSError:
                    pass
            tasks.append((pdf, out))
        with self.lock:
            self.total = len(files) + self._pre_counted()
        if self.skipped:
            self.log(f"تم تخطي {self.skipped} ملفاً محوّلاً مسبقاً.")
        self.phase = "converting"
        if tasks:
            if s["workers"] > 1 and len(tasks) > 1:
                self._run_parallel(tasks)
            else:
                self._run_serial(tasks)
        self._write_report()
        stopped = self.stop_event.is_set()
        if not stopped:
            self._package()
        if stopped:
            self.phase = "stopped"
            self.log("تم الإيقاف بناءً على طلبك.", "warn")
        else:
            self.phase = "done"
            self.log(f"اكتمل التحويل: {self.ok} ناجح، {self.warn} يحتاج مراجعة، {self.failed} فشل، {self.skipped} متخطى.", "success")

    def _run_pack_only(self):
        """AI_READY copy (+ analysis, + ZIP) of Word files that already exist (converted earlier)."""
        self.phase = "packaging"
        folder = self.pack_folder
        entries = aiexport.collect_docx(folder)
        if not entries:
            self.log("لا توجد ملفات Word في هذا المجلد.", "error")
            self.phase = "error"
            return
        self.log(f"وُجد {len(entries)} ملف Word في {folder}")
        top = gdrive.safe_name(os.path.basename(folder.rstrip("\\/")) or "PDF2Word", 60)
        for e in entries:
            self.display[e["docx"]] = e["source"]
            self.arcs[e["docx"]] = os.path.join(top, e["source"])
            self._record(FileReport(source=e["docx"], output=e["docx"], status="skipped").to_dict(), quiet=True)
        with self.lock:
            self.total = len(entries)
        self._package(name=top, zip_word=False)
        if self.stop_event.is_set():
            self.phase = "stopped"
            self.log("تم الإيقاف بناءً على طلبك.", "warn")
        else:
            self.phase = "done"
            self.log("اكتمل.", "success")

    def _pre_counted(self):
        """Files recorded before scanning (Drive files skipped without download / failed downloads)."""
        return getattr(self, "_pre", 0)

    def _progress(self, i, n):
        with self.lock:
            self.page_info = f"{min(i + 1, n)}/{n}"

    def _run_serial(self, tasks):
        conv = Converter(self.s, log=lambda m: self.log(m, "warn" if "⚠" in m else "info"), stop_event=self.stop_event,
                         progress=self._progress)
        for pdf, out in tasks:
            if self.stop_event.is_set():
                break
            with self.lock:
                self.current = self.display.get(pdf, pdf)
                self.page_info = ""
            rep = conv.convert(pdf, out)
            self._record(rep.to_dict())

    def _run_parallel(self, tasks):
        s = dict(self.s)
        n = s["workers"]
        if s.get("ai_enabled"):
            from .ai import PROVIDERS
            base_rpm = s.get("ai_rpm") or PROVIDERS.get(s.get("ai_provider"), {}).get("rpm", 10)
            s["ai_rpm"] = max(1, int(base_rpm / n))
        self.log(f"تحويل متوازٍ باستخدام {n} عمليات.")
        with ProcessPoolExecutor(max_workers=n, initializer=_worker_init, initargs=(s,)) as ex:
            futs = {}
            it = iter(tasks)
            for _ in range(n * 2):
                t = next(it, None)
                if t is None:
                    break
                futs[ex.submit(_worker_convert, *t)] = t
            while futs:
                done = next(as_completed(list(futs)))
                pdf, out = futs.pop(done)
                try:
                    rep = done.result()
                except Exception as e:
                    rep = FileReport(source=pdf, output=out, status="error", message=str(e)).to_dict()
                for line in rep.get("log", [])[:20]:
                    if not line.startswith("Traceback"):
                        self.log(line)
                self._record(rep)
                if not self.stop_event.is_set():
                    t = next(it, None)
                    if t is not None:
                        futs[ex.submit(_worker_convert, *t)] = t
                with self.lock:
                    self.current = "، ".join(os.path.basename(v[0]) for v in futs.values())

    def _record(self, rep, quiet=False):
        st = rep.get("status")
        src = rep.get("source", "")
        rep["display"] = self.display.get(src, src)
        with self.lock:
            if self.phase in ("preparing", "listing", "downloading"):
                self._pre = getattr(self, "_pre", 0) + 1
            self.results.append(rep)
            if st == "ok":
                self.ok += 1
            elif st == "warning":
                self.warn += 1
            elif st == "skipped":
                self.skipped += 1
            elif st == "cancelled":
                pass
            else:
                self.failed += 1
            if st != "skipped":
                self.done += 1
        if quiet:
            return
        name = os.path.basename(src)
        extra = f" — {rep.get('message')}" if rep.get("message") else ""
        if st == "ok":
            self.log(f"✔ {name} ({rep.get('pages')} صفحة، {rep.get('seconds')} ث)", "success")
        elif st == "warning":
            self.log(f"⚠ {name}{extra}", "warn")
        elif st == "cancelled":
            self.log(f"⏹ {name} أُوقف", "warn")
        else:
            self.log(f"✖ {name}{extra}", "error")

    def _write_report(self):
        if not self.results:
            return
        d = self._report_dir()
        try:
            os.makedirs(d, exist_ok=True)
            path = os.path.join(d, f"تقرير_التحويل_{datetime.now():%Y-%m-%d_%H-%M-%S}.csv")
            status_ar = {"ok": "ناجح", "warning": "يحتاج مراجعة", "error": "فشل", "skipped": "متخطى", "cancelled": "أُوقف"}
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(["ملف PDF", "ملف Word", "الحالة", "الصفحات", "صفحات نصية", "صفحات OCR",
                            "صفحات صححها الذكاء الاصطناعي", "صفحات تحتاج مراجعة", "كلمات غير مقروءة", "محرك OCR",
                            "ملاحظات", "الوقت (ث)"])
                for r in self.results:
                    notes = [r.get("message", "")] + list(r.get("notes", []))[:15]
                    eng = " ".join(f"{k}:{v}" for k, v in (r.get("engines") or {}).items())
                    w.writerow([r.get("display") or r.get("source"),
                                r.get("output") if r.get("status") in ("ok", "warning", "skipped") else "",
                                status_ar.get(r.get("status"), r.get("status")), r.get("pages", 0), r.get("native_pages", 0),
                                r.get("ocr_pages", 0), r.get("ai_pages", 0), " ".join(map(str, r.get("review_pages", []))),
                                r.get("uncertain", 0), eng, " | ".join(n for n in notes if n), r.get("seconds", 0)])
            self.report_path = path
            self.log(f"حُفظ التقرير: {path}")
        except OSError as e:
            self.log(f"تعذّر حفظ التقرير: {e}", "error")

    # -- results: AI package + ZIP -------------------------------------------------------
    def _outputs(self, extras=False):
        """(report, name inside the ZIP) for every file produced. With extras=True the
        Markdown files written beside the Word files are listed as well."""
        out = []
        for r in self.results:
            o = r.get("output")
            if r.get("status") in ("ok", "warning", "skipped") and o and os.path.exists(long_path(o)):
                arc = self.arcs.get(o) or os.path.basename(o)
                out.append((r, arc))
                md = r.get("markdown")
                if extras and md and md != o and os.path.exists(long_path(md)):
                    out.append(({"output": md}, os.path.splitext(arc)[0] + ".md"))
        out.sort(key=lambda t: t[1].lower())
        return out

    def _an_progress(self, **kw):
        with self.lock:
            self.an.update({k: v for k, v in kw.items() if v is not None})
            cur = self.an.get("current") or ""
            sub = self.an.get("sub") or ""
            tot = self.an.get("total") or 0
            self.current = (f"تحليل {min(self.an.get('done', 0) + 1, tot)}/{tot}: " if tot and cur and cur != "التقرير الشامل"
                            else "") + cur + (f" ({sub})" if sub else "")

    def _package(self, name=None, zip_word=True):
        s = self.s
        if not (s["ai_pack"] or s["zip_output"] or s["analysis_enabled"]):
            return
        outs = self._outputs()
        if not outs:
            return
        self.phase = "packaging"
        d = self._report_dir()
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        if not name:
            tops = sorted({r.label.split(os.sep)[0] for r in self.roots}) or ["PDF2Word"]
            name = gdrive.safe_name(tops[0] if len(tops) == 1 else "PDF2Word", 60)
        if s["ai_pack"] or s["analysis_enabled"]:
            with self.lock:
                self.current = "تجهيز النسخة المختصرة للذكاء الاصطناعي…"
            entries = [{"docx": long_path(r["output"]), "source": os.path.splitext(arc)[0].replace(os.sep, "/") + ".pdf",
                        "report": r} for r, arc in outs if str(r.get("output", "")).lower().endswith(".docx")]
            pack_dir = os.path.join(d, f"AI_READY_{name}_{ts}")
            if not entries:
                self.log("لا توجد ملفات Word لبناء النسخة المختصرة (كل النتائج Markdown).", "warn")
                entries = None
            try:
                if entries is None:
                    raise RuntimeError("skip")
                self.pack_info = aiexport.build_pack(entries, pack_dir, part_tokens=s["ai_pack_part_tokens"],
                                                     strip_tashkeel=s["ai_pack_strip_tashkeel"],
                                                     log=lambda m: self.log(m, "success"), title=name,
                                                     task_prompt=s["analysis_prompt"], task_lang=s["analysis_language"])
                self.pack_dir = pack_dir
                with open(os.path.join(pack_dir, "manifest.json"), encoding="utf-8") as f:
                    self.claude_parts = [p["file"] for p in json.load(f).get("parts", [])]
            except RuntimeError as e:
                if str(e) != "skip":
                    self.log(f"تعذّر إنشاء النسخة المختصرة: {e}", "error")
            except Exception as e:
                self.log(f"تعذّر إنشاء النسخة المختصرة: {e}", "error")
        if s["analysis_enabled"] and self.pack_dir and not self.stop_event.is_set():
            self.phase = "analyzing"
            self.an = {"done": 0, "total": self.pack_info.get("docs", 0)}
            out_docx = os.path.join(d, f"تحليل_{name}_{ts}.docx")
            try:
                res = analysis.run_on_pack(self.pack_dir, s, out_docx=out_docx, log=lambda m: self.log(
                    m, "error" if m.startswith("✖") else ("warn" if m.startswith(("⏸", "⚠")) else "success" if m.startswith("✔") else "info")),
                    stop=self.stop_event, progress=self._an_progress, title=name)
                self.analysis_info = {k: v for k, v in res.items() if k != "failed"}
                self.analysis_info["failed"] = len(res.get("failed") or [])
                self.analysis_path = res.get("docx") or ""
            except analysis.AIAuthError as e:
                self.log(f"✖ تحليل المحتوى يحتاج خدمة ذكاء اصطناعي مُعدّة (القسم ٤): {e}", "error")
            except Exception as e:
                self.log(f"✖ تعذّر تحليل المحتوى: {e}", "error")
            if self.stop_event.is_set():
                return
        if s["zip_output"]:
            self.phase = "packaging"
            with self.lock:
                self.current = "ضغط الملفات في ZIP…"
            items = [(long_path(r["output"]), arc) for r, arc in self._outputs(extras=True)] if zip_word else []
            if self.report_path:
                items.append((self.report_path, os.path.basename(self.report_path)))
            if self.analysis_path:
                items.append((self.analysis_path, os.path.basename(self.analysis_path)))
            if self.pack_dir:
                items.append((self.pack_dir, os.path.basename(self.pack_dir)))
            if not items:
                return
            zpath = os.path.join(d, f"{name}_Word_{ts}.zip")
            try:
                archives.make_zip(zpath, items)
                self.zip_path = zpath
                self.log(f"📦 ملف ZIP جاهز: {zpath} ({len(outs) if zip_word else 0} ملف Word، "
                         f"{os.path.getsize(zpath) / 1048576:.1f} MB)", "success")
            except (OSError, ValueError) as e:
                self.log(f"تعذّر إنشاء ملف ZIP: {e}", "error")

    def _cleanup(self):
        shutil.rmtree(os.path.join(work_dir(), self.job_id), ignore_errors=True)
        if self.phase == "done" and not self.s["keep_downloads"] and self.failed == 0:
            for r in self.roots:
                if r.cache:
                    shutil.rmtree(r.cache, ignore_errors=True)
