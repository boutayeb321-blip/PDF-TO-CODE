# -*- coding: utf-8 -*-
"""ZIP input (e.g. the ZIP that Google Drive gives for "Download" of a folder) and ZIP output."""
from __future__ import annotations

import os
import time
import zipfile

from .gdrive import safe_name


def _name_score(cand: str) -> int:
    good = bad = 0
    for c in cand:
        if c.isascii():
            good += c.isalnum()
        elif "\u0621" <= c <= "\u064a" or "\u0660" <= c <= "\u0669" or c in "\u067e\u0686\u0698\u06af\u06a9\u06cc\u0640":
            good += 1
        else:  # box drawing, accented Latin... = wrong code page
            bad += 1
    return good - 4 * bad


def _fix_name(info: zipfile.ZipInfo) -> str:
    """Names without the UTF-8 flag are decoded as cp437 by Python; Arabic names written by
    older Windows tools come out garbled. Pick the code page that gives real Arabic."""
    name = info.filename
    if info.flag_bits & 0x800 or all(ord(c) < 128 for c in name):
        return name
    try:
        raw = name.encode("cp437")
    except UnicodeEncodeError:
        return name
    best, best_score = name, _name_score(name)
    for enc in ("utf-8", "cp1256", "cp720", "cp864"):
        try:
            cand = raw.decode(enc)
        except UnicodeDecodeError:
            continue
        sc = _name_score(cand)
        if sc > best_score:
            best, best_score = cand, sc
    return best


def _safe_parts(name: str):
    parts = []
    for p in name.replace("\\", "/").split("/"):
        if p in ("", ".", ".."):
            continue
        parts.append(safe_name(p))
    return parts


def extract_pdfs(zip_path, dest, depth=0, log=None, max_total=50 * 1024 ** 3):
    """Extract the PDFs (and nested ZIPs, one level) of a ZIP into dest. Returns count."""
    log = log or (lambda *_: None)
    n = 0
    total = 0
    try:
        zf = zipfile.ZipFile(zip_path)
    except (zipfile.BadZipFile, OSError) as e:
        log(f"✖ ملف ZIP تالف: {os.path.basename(zip_path)} ({e})")
        return 0
    with zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            name = _fix_name(info)
            low = name.lower()
            if not (low.endswith(".pdf") or (low.endswith(".zip") and depth < 1)):
                continue
            if info.file_size > 8 * 1024 ** 3 or (info.compress_size and info.file_size / max(1, info.compress_size) > 2000):
                log(f"تجاهل عنصر مريب داخل ZIP: {name}")
                continue
            total += info.file_size
            if total > max_total:
                log("توقف فك الضغط: الحجم كبير جداً")
                break
            parts = _safe_parts(name)
            if not parts:
                continue
            out = os.path.join(dest, *parts)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            try:
                with zf.open(info) as src, open(out, "wb") as dst:
                    while True:
                        chunk = src.read(1 << 20)
                        if not chunk:
                            break
                        dst.write(chunk)
            except (zipfile.BadZipFile, OSError, RuntimeError) as e:
                log(f"✖ تعذّر استخراج {name}: {e}")
                continue
            try:  # keep the original date so "skip already converted" works on the next run
                ts = time.mktime(info.date_time + (0, 0, -1))
                os.utime(out, (ts, ts))
            except (OverflowError, ValueError, OSError):
                pass
            if low.endswith(".zip"):
                inner = os.path.splitext(out)[0]
                n += extract_pdfs(out, inner, depth + 1, log)
                try:
                    os.remove(out)
                except OSError:
                    pass
            else:
                n += 1
    return n


def make_zip(zip_path, items, log=None):
    """items: [(file_path, arcname)] or [(folder_path, arc_prefix)] for folders."""
    log = log or (lambda *_: None)
    tmp = zip_path + ".part"
    count = 0
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, allowZip64=True, compresslevel=6) as z:
        for path, arc in items:
            if os.path.isdir(path):
                for dp, _, files in os.walk(path):
                    for fn in sorted(files):
                        full = os.path.join(dp, fn)
                        rel = os.path.relpath(full, path)
                        z.write(full, os.path.join(arc, rel).replace("\\", "/"))
                        count += 1
            elif os.path.isfile(path):
                z.write(path, arc.replace("\\", "/"))
                count += 1
    os.replace(tmp, zip_path)
    return count
