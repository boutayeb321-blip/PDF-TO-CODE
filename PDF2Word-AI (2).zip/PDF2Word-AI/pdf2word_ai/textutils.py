# -*- coding: utf-8 -*-
"""Text helpers: Arabic normalisation, visual->logical bidi reordering, quality checks, similarity.

PDF files store glyphs by position. For Arabic (right-to-left) text the glyphs are usually written
in *visual* order, so a naive extraction gives reversed words. Everything here works on "units"
(one glyph = one unit, which may hold several characters such as a lam-alef ligature or a letter
with its diacritics) so that ligatures and harakat stay attached to the right letter.
"""
from __future__ import annotations

import re
import unicodedata
from collections import Counter
from difflib import SequenceMatcher

# ----------------------------------------------------------------------------------------------
# Character classes
# ----------------------------------------------------------------------------------------------
MIRROR = {
    "(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{", "<": ">", ">": "<",
    "«": "»", "»": "«", "‹": "›", "›": "‹", "﴾": "﴿", "﴿": "﴾",
}

_ZERO_WIDTH_DROP = {"﻿", "​", "­", "⁠", "￾"}
_TATWEEL = "ـ"


def bidi_of(ch: str) -> str:
    return unicodedata.bidirectional(ch) or "ON"


def is_arabic_letter(ch: str) -> bool:
    return bidi_of(ch) in ("AL", "R")


def unit_bidi_type(text: str) -> str:
    """Bidi class of a unit: first strong class, otherwise the class of the first character."""
    first = None
    for ch in text:
        b = bidi_of(ch)
        if b in ("L", "R", "AL"):
            return "R" if b in ("R", "AL") else "L"
        if first is None and b != "NSM":
            first = b
    if first is None:
        return "NSM" if text else "ON"
    if first in ("WS", "S", "B"):
        return "WS"
    if first in ("EN", "AN", "ES", "ET", "CS"):
        return first
    return "ON"


def arabic_ratio(text: str) -> float:
    ar = lt = 0
    for ch in text:
        b = bidi_of(ch)
        if b in ("AL", "R"):
            ar += 1
        elif b == "L":
            lt += 1
    tot = ar + lt
    return ar / tot if tot else 0.0


def is_rtl_text(text: str) -> bool:
    ar = lt = 0
    for ch in text:
        b = bidi_of(ch)
        if b in ("AL", "R"):
            ar += 1
        elif b == "L":
            lt += 1
    return ar > 0 and ar >= lt


# ----------------------------------------------------------------------------------------------
# Normalisation
# ----------------------------------------------------------------------------------------------
def _norm_char(ch: str) -> str:
    o = ord(ch)
    # Arabic presentation forms (shaping glyphs) and Latin ligatures -> plain letters.
    # The special word-ligatures U+FDF0..U+FDFF (e.g. ﷺ ﷲ ﷽) are real characters: keep them.
    if 0xFB50 <= o <= 0xFDCF or 0xFE70 <= o <= 0xFEFC or 0xFB00 <= o <= 0xFB06:
        r = unicodedata.normalize("NFKC", ch)
        # isolated/medial harakat forms decompose to " ً" or "ـً" -> keep only the mark
        if len(r) > 1 and r[0] in (" ", _TATWEEL) and all(unicodedata.category(c) == "Mn" for c in r[1:]):
            r = r[1:]
        return r
    if ch in _ZERO_WIDTH_DROP:
        return ""
    if ch in ("\t", "\n"):
        return ch
    cat = unicodedata.category(ch)
    if cat == "Cc":
        return ""
    if ch in (" ", " ", " ", " ", " ", " "):
        return " "
    if ch in ("‪", "‫", "‬", "‭", "‮", "‎", "‏", "⁦", "⁧", "⁨", "⁩"):
        return ""  # explicit bidi controls are meaningless after we reorder ourselves
    return ch


def normalize_text(text: str) -> str:
    """Normalise extracted PDF text (presentation forms, invisible characters)."""
    if not text:
        return ""
    return "".join(_norm_char(c) for c in text)


def strip_diacritics(text: str) -> str:
    return "".join(c for c in text if unicodedata.category(c) != "Mn")


def is_mark_text(text: str) -> bool:
    return bool(text) and all(unicodedata.category(c) == "Mn" for c in text)


def remove_justification_tatweel(text: str) -> str:
    """Remove kashida used only for justification (runs of 2+ tatweel, or heavy density)."""
    if _TATWEEL not in text:
        return text
    text = re.sub(_TATWEEL + "{2,}", "", text)
    letters = sum(1 for c in text if is_arabic_letter(c))
    if letters and text.count(_TATWEEL) / letters > 0.04:
        text = text.replace(_TATWEEL, "")
    return text


# ----------------------------------------------------------------------------------------------
# Visual -> logical reordering (inverse of the Unicode Bidirectional Algorithm, 3 levels)
# ----------------------------------------------------------------------------------------------
UNIT_WORDS = {
    "gb", "mb", "kb", "tb", "gib", "mib", "kg", "g", "mg", "km", "m", "cm", "mm", "ml", "l", "hz", "khz", "mhz",
    "ghz", "w", "kw", "kwh", "v", "a", "mah", "px", "pt", "dpi", "fps", "usd", "sar", "eur", "aed", "egp", "kwd",
    "qar", "omr", "bhd", "jod", "mad", "dzd", "tnd", "am", "pm", "x", "k", "bit", "bits", "byte", "bytes", "mbps",
    "gbps", "kbps", "sec", "min", "h", "hr", "hrs", "ms", "ft", "in", "lb", "lbs", "oz", "mm2", "m2", "m3", "%",
}


def _word_left_of(texts, types, i):
    j = i - 1
    while j >= 0 and types[j] not in ("L", "R"):
        j -= 1
    if j < 0 or types[j] != "L":
        return ""
    k = j
    while k - 1 >= 0 and types[k - 1] == "L":
        k -= 1
    return "".join(texts[k:j + 1])


def _nearest_strong(types, i, step):
    j = i + step
    while 0 <= j < len(types):
        if types[j] in ("L", "R"):
            return types[j]
        j += step
    return None


def visual_to_logical(texts, base_rtl: bool, context_strong: str | None = None):
    """Reorder a line given in visual (left-to-right) order into logical order.

    texts: list of unit strings in visual order.
    base_rtl: paragraph direction.
    context_strong: 'R'/'L' strong type that logically precedes this line (previous line of the
                    same paragraph). Used for numbers at the line start.
    Returns (order, mirrored) where order is a list of indexes into texts in logical order and
    mirrored is a set of indexes whose bracket character must be mirrored.
    """
    n = len(texts)
    if n == 0:
        return [], set()
    base = "R" if base_rtl else "L"
    t = [unit_bidi_type(x) for x in texts]
    t = ["ON" if x == "NSM" else x for x in t]
    ctx = context_strong or base

    # Numbers: decide EN (European), AN (Arabic context) or L (part of a Latin phrase).
    for i in range(n):
        if t[i] == "EN":
            left = _nearest_strong(t, i, -1)
            right = _nearest_strong(t, i, +1)
            if base == "R":
                if left == "L" and _word_left_of(texts, t, i).lower() not in UNIT_WORDS:
                    t[i] = "L"  # W7: "Windows 10" (but "10 GB" keeps the number first)
                else:
                    pre = right if right is not None else ctx  # logical predecessor is on the right
                    t[i] = "AN" if pre == "R" else "EN"  # W2
            else:
                if left == "R" and right == "R":
                    t[i] = "AN"  # inside an RTL island
                else:
                    pre = left if left is not None else ctx
                    t[i] = "AN" if pre == "R" else "L"
    # W4: single separator between two numbers of the same type
    for i in range(1, n - 1):
        if t[i] == "ES" and t[i - 1] == "EN" and t[i + 1] == "EN":
            t[i] = "EN"
        elif t[i] == "CS" and t[i - 1] in ("EN", "AN") and t[i + 1] == t[i - 1]:
            t[i] = t[i - 1]
        elif t[i] in ("CS", "ES") and t[i - 1] == "L" and t[i + 1] == "L" and texts[i - 1][-1:].isdigit() and texts[i + 1][:1].isdigit():
            t[i] = "L"
    # W5: European terminators (%, $, °...) next to European numbers
    i = 0
    while i < n:
        if t[i] == "ET":
            j = i
            while j < n and t[j] == "ET":
                j += 1
            if (i > 0 and t[i - 1] == "EN") or (j < n and t[j] == "EN"):
                for k in range(i, j):
                    t[k] = "EN"
            i = j
        else:
            i += 1
    t = ["ON" if x in ("ES", "ET", "CS") else x for x in t]

    # N1/N2: neutrals take the direction of their neighbours (numbers count as R), else base.
    def strongish(x):
        if x in ("R", "EN", "AN"):
            return "R"
        if x == "L":
            return "L"
        return None

    resolved = list(t)
    i = 0
    while i < n:
        if strongish(t[i]) is None:
            j = i
            while j < n and strongish(t[j]) is None:
                j += 1
            left = strongish(t[i - 1]) if i > 0 else base
            right = strongish(t[j]) if j < n else base
            d = left if left == right else base
            for k in range(i, j):
                resolved[k] = "N" + d
            i = j
        else:
            i += 1

    levels = []
    for x in resolved:
        if base == "R":
            lv = 1 if x in ("R", "NR") else 2
        else:
            if x in ("L", "NL"):
                lv = 0
            elif x in ("R", "NR"):
                lv = 1
            else:  # EN / AN
                lv = 2
        levels.append(lv)

    order = list(range(n))

    def reverse_runs(min_level):
        i = 0
        while i < n:
            if levels[order[i]] >= min_level:
                j = i
                while j < n and levels[order[j]] >= min_level:
                    j += 1
                order[i:j] = order[i:j][::-1]
                i = j
            else:
                i += 1

    reverse_runs(2)
    reverse_runs(1)
    mirrored = {k for k in range(n) if levels[k] % 2 == 1 and texts[k] in MIRROR}
    return order, mirrored


def reorder_string_visual(line: str, base_rtl: bool | None = None) -> str:
    """Convenience: treat each character as a unit (diacritics kept with their letter)."""
    units = []
    for ch in line:
        if units and unicodedata.category(ch) == "Mn":
            units[-1] += ch
        else:
            units.append(ch)
    if base_rtl is None:
        base_rtl = is_rtl_text(line)
    order, mirrored = visual_to_logical(units, base_rtl)
    return "".join(MIRROR[units[k]] if k in mirrored else units[k] for k in order)


# ----------------------------------------------------------------------------------------------
# Broken-encoding detection and repair
# ----------------------------------------------------------------------------------------------
def detect_cp1256_mojibake(text: str) -> bool:
    """Arabic Windows-1256 bytes shown as Latin-1/1252 (e.g. 'ÇáÚÑÈíÉ')."""
    letters = [c for c in text if c.isalpha()]
    if len(letters) < 15:
        return False
    sup = sum(1 for c in letters if 0xC0 <= ord(c) <= 0xFF)
    if sup / len(letters) < 0.30:
        return False
    fixed = fix_cp1256_mojibake(text)
    return fixed is not None and arabic_ratio(fixed) > 0.6


def fix_cp1256_mojibake(text: str) -> str | None:
    out = []
    for ch in text:
        o = ord(ch)
        if 0x80 <= o <= 0xFF or ch in "€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ":
            try:
                b = ch.encode("cp1252")
            except UnicodeEncodeError:
                try:
                    b = ch.encode("latin-1")
                except UnicodeEncodeError:
                    out.append(ch)
                    continue
            try:
                out.append(b.decode("cp1256"))
            except UnicodeDecodeError:
                out.append(ch)
        else:
            out.append(ch)
    return "".join(out)


def text_quality(text: str) -> float:
    """1.0 = clean text; low values mean replacement / private-use / control characters."""
    chars = [c for c in text if not c.isspace()]
    if not chars:
        return 0.0
    bad = 0
    for c in chars:
        o = ord(c)
        if c == "�" or 0xE000 <= o <= 0xF8FF or unicodedata.category(c) in ("Cc", "Co", "Cn"):
            bad += 1
    return 1.0 - bad / len(chars)


_SYMBOLS = set("[]{}~^`|\\@#$<>")


def gibberish_score(text: str) -> float:
    """Detects text from fonts with a broken mapping (Arabic glyphs coming out as random Latin)."""
    words = re.findall(r"[A-Za-z]{3,}", text)
    nonspace = [c for c in text if not c.isspace()]
    if len(words) < 15 or not nonspace:
        return 0.0
    vowelless = sum(1 for w in words if not re.search(r"[aeiouyAEIOUY]", w))
    weird_case = sum(1 for w in words if re.search(r"[a-z][A-Z]", w))
    sym = sum(1 for c in nonspace if c in _SYMBOLS) / len(nonspace)
    return min(1.0, (vowelless + weird_case) / len(words) + 2 * sym)


# ----------------------------------------------------------------------------------------------
# Arabic word-order sanity check
# ----------------------------------------------------------------------------------------------
_COMMON_AR = set(
    "في من على إلى الى عن مع هذا هذه ذلك التي الذي الذين أن إن كان كانت قد لم لن لا ما هو هي ثم أو "
    "بين كل بعد قبل عند حتى منذ خلال حيث كما وقد وفي ومن وعلى وهو وهي فقد لقد إذا اذا غير أي أيضا "
    "تم يتم عليه عليها فيه فيها منه منها إلا الا".split()
)
_PALIN = {w for w in _COMMON_AR if w == w[::-1]}
_REV_COMMON = {w[::-1] for w in _COMMON_AR if w not in _PALIN} - _COMMON_AR


def arabic_order_scores(text: str):
    toks = re.findall(r"[ء-يٱ-ۓ]+", strip_diacritics(text))
    normal = rev = 0
    for t in toks:
        if t in _COMMON_AR or (len(t) >= 4 and t.startswith("ال")):
            normal += 1
        if t in _REV_COMMON or (len(t) >= 4 and t.endswith("لا") and not t.startswith("ال")):
            rev += 1
    return normal, rev


def looks_reversed(text: str) -> bool:
    normal, rev = arabic_order_scores(text)
    return rev >= 5 and rev > 1.5 * normal


# ----------------------------------------------------------------------------------------------
# Similarity (used to validate AI corrections and to verify conversions)
# ----------------------------------------------------------------------------------------------
_AR_UNIFY = str.maketrans({"إ": "ا", "أ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ة": "ه", "ـ": None})


def normalize_for_compare(text: str) -> str:
    text = strip_diacritics(normalize_text(text)).translate(_AR_UNIFY).lower()
    text = re.sub(r"[*#|_`>\-–—•·]+", " ", text)  # markdown / bullets do not count
    return re.sub(r"\s+", " ", text).strip()


def _ngrams(s: str, n: int = 3) -> Counter:
    s = s.replace(" ", "_")
    return Counter(s[i:i + n] for i in range(max(0, len(s) - n + 1)))


def dice_trigram(a: str, b: str) -> float:
    ga, gb = _ngrams(a), _ngrams(b)
    ta, tb = sum(ga.values()), sum(gb.values())
    if ta + tb == 0:
        return 1.0
    inter = sum((ga & gb).values())
    return 2 * inter / (ta + tb)


def word_seq_ratio(a: str, b: str) -> float:
    wa, wb = a.split(), b.split()
    if not wa and not wb:
        return 1.0
    return SequenceMatcher(None, wa, wb, autojunk=False).ratio()


def similarity_report(original: str, candidate: str) -> dict:
    a, b = normalize_for_compare(original), normalize_for_compare(candidate)
    la, lb = len(a), len(b)
    return {
        "dice": dice_trigram(a, b),
        "words": word_seq_ratio(a, b),
        "len_ratio": (lb / la) if la else (1.0 if lb == 0 else 9.9),
        "ar_orig": arabic_ratio(a),
        "ar_cand": arabic_ratio(b),
    }


def word_recall(reference: str, candidate: str) -> float:
    """Share of reference words (with multiplicity) that also appear in candidate."""
    ra = Counter(normalize_for_compare(reference).split())
    rb = Counter(normalize_for_compare(candidate).split())
    tot = sum(ra.values())
    if not tot:
        return 1.0
    return sum((ra & rb).values()) / tot


def count_visible(text: str) -> int:
    return sum(1 for c in text if not c.isspace())


# ----------------------------------------------------------------------------------------------
# Engine-independent OCR plausibility (to choose between two OCR engines on the same page)
# ----------------------------------------------------------------------------------------------
_COMMON_EN = set(
    "the of and to in a is that for it as was with be by on not he i this are or his from at which but have an "
    "they you were her she there one all we can their has been if more when will would who so no its also than "
    "into only other new some could time these two may then do first any my now such like our over man me even "
    "most made after many before must through back years where much your way well down should because each just "
    "those people how too little state good very make world still own see men work long get here between both life "
    "being under never day same another know while last might us great old year off come since against go came "
    "right used take three page report total section table figure date number name".split()
)


def ocr_plausibility(text: str) -> float:
    """0..100: how much a page reading looks like real language (not OCR noise)."""
    toks = re.findall(r"\S+", text or "")
    if not toks:
        return 0.0
    ar_tokens = [t for t in toks if any(is_arabic_letter(c) for c in t)]
    lat_tokens = [t for t in toks if re.search(r"[A-Za-z]", t) and not any(is_arabic_letter(c) for c in t)]
    junk = 0
    for t in toks:
        core = re.sub(r"[\W_]+", "", t)
        if not core:
            continue
        mixed = any(is_arabic_letter(c) for c in core) and re.search(r"[A-Za-z]", core)
        if mixed or re.fullmatch(r"[lIi1|!]{2,}", core) or (len(core) == 1 and re.match(r"[A-Za-z]", core) and core not in "aAI"):
            junk += 1
    if len(ar_tokens) >= len(lat_tokens):
        plain = [strip_diacritics(re.sub(r"[^\u0621-\u064A\u0671-\u06D3\u064B-\u0652]", "", t)) for t in ar_tokens]
        hits = sum(1 for t in plain if t in _COMMON_AR or (len(t) >= 4 and t.startswith("ال")))
        lang = min(1.0, hits / max(1, len(plain)) / 0.38)
        # Arabic junk: Latin fragments in an Arabic page
        junk += sum(1 for t in lat_tokens if len(re.sub(r"[^A-Za-z]", "", t)) <= 3)
    else:
        words = [re.sub(r"[^a-z]", "", t.lower()) for t in lat_tokens]
        hits = sum(1 for w in words if w in _COMMON_EN)
        lang = min(1.0, hits / max(1, len(words)) / 0.30)
    return max(0.0, 100.0 * lang - 120.0 * junk / len(toks))
