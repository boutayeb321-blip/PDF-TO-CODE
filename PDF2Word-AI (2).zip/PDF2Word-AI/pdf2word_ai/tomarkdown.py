# -*- coding: utf-8 -*-
"""Markdown output — the same idea as Microsoft's MarkItDown: turn documents into clean Markdown
that both people and AI assistants read easily (headings, lists, tables, bold are kept).

Two jobs:
  * render_pages()  — a converted PDF (our page model) -> faithful Markdown.
  * convert_file()  — Word, PowerPoint, Excel, CSV, HTML, text, JSON, XML -> Markdown.

من إنجاز بوطيب أحمد (Boutib Ahmed).
"""
from __future__ import annotations

import csv as _csv
import html as _html
import io
import json
import os
import re
import shutil

from .model import Paragraph, Picture, Table

# files convert_file() can read (PDFs go through the normal converter)
OTHER_EXTS = (".docx", ".pptx", ".xlsx", ".xlsm", ".csv", ".tsv", ".html", ".htm",
              ".txt", ".text", ".md", ".markdown", ".json", ".jsonl", ".xml")

_WS = re.compile(r"[ \t ]+")
_LIST = r"(?:[-*+]|\d{1,3}[.)])\s"


def _tighten_lists(text: str) -> str:
    """Remove the blank line between consecutive list items so they render as one list."""
    pat = re.compile(r"(?m)^(" + _LIST + r"[^\n]*)\n\n(?=" + _LIST + r")")
    for _ in range(8):
        new = pat.sub(r"\1\n", text)
        if new == text:
            break
        text = new
    return text


def _clean(text: str) -> str:
    return _WS.sub(" ", (text or "").replace("\r", "")).strip()


def _esc_cell(text: str) -> str:
    return _clean(text).replace("|", "\\|")


def _esc_line(text: str) -> str:
    """Stop body text from accidentally becoming a heading / list / quote."""
    t = _clean(text)
    return re.sub(r"^([#>|]|[-*+]\s|\d+[.)]\s)", r"\\\1", t) if t else t


def _runs_md(p: Paragraph) -> str:
    """Paragraph text with **bold** kept."""
    out, buf, buf_bold = [], "", False

    def flush():
        nonlocal buf, buf_bold
        if not buf:
            return
        if buf_bold and buf.strip():
            lead = buf[:len(buf) - len(buf.lstrip())]
            trail = buf[len(buf.rstrip()):]
            out.append(lead + "**" + buf.strip() + "**" + trail)
        else:
            out.append(buf)
        buf = ""

    for r in getattr(p, "runs", []) or []:
        t = r.text or ""
        if not t:
            continue
        b = bool(getattr(r, "bold", False))
        if b != buf_bold:
            flush()
            buf_bold = b
        buf += t
    flush()
    return "".join(out)


def _para_md(p: Paragraph) -> str:
    text = _clean(_runs_md(p))
    if not text:
        return ""
    if getattr(p, "heading", 0):
        plain = re.sub(r"\*\*", "", text)
        return "#" * min(6, int(p.heading)) + " " + plain
    if getattr(p, "is_list", False):
        body = re.sub(r"^[•▪●\-\*•]\s*", "", text)
        m = re.match(r"^((?:\d{1,3}|[٠-٩]{1,3})[.)])\s*(.*)$", body)
        return (m.group(1) + " " + m.group(2)) if m else ("- " + body)
    return _esc_line(text)


def _table_md(t: Table) -> str:
    rows = []
    for row in t.grid:
        cells = []
        for c in row:
            if c is None:
                cells.append("")
            else:
                cells.append(_esc_cell(" ".join(_runs_md(p) for p in c.paragraphs)))
        rows.append(cells)
    rows = [r for r in rows if any(x for x in r)]
    if not rows:
        return ""
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    if width == 1:                      # a one-column "table" reads better as plain lines
        return "\n\n".join(r[0] for r in rows if r[0])
    out = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * width]
    for r in rows[1:]:
        out.append("| " + " | ".join(r) + " |")
    return "\n".join(out)


def _pic_md(pic: Picture, img_rel: str | None) -> str:
    if img_rel:
        return "![صورة](" + img_rel.replace(" ", "%20") + ")"
    return "[صورة]" if pic.kind != "page" else "[صفحة كصورة]"


def render_pages(pages, images_dir=None, images_name="", page_marks=True, source=None) -> str:
    """Faithful Markdown of a converted PDF. `images_dir` (if given) receives the pictures."""
    parts = []
    if source:
        parts.append("<!-- " + _clean(str(source)) + " — PDF2Word AI, بوطيب أحمد -->")
    n_img = 0
    for pr in pages:
        if page_marks and len(pages) > 1:
            parts.append("<!-- ص%d -->" % (pr.index + 1))
        for it in pr.items:
            if isinstance(it, Paragraph):
                md = _para_md(it)
                if md:
                    parts.append(md)
            elif isinstance(it, Table):
                md = _table_md(it)
                if md:
                    parts.append(md)
            elif isinstance(it, Picture):
                rel = None
                if images_dir and it.path and os.path.exists(it.path):
                    try:
                        os.makedirs(images_dir, exist_ok=True)
                        n_img += 1
                        name = "img%03d%s" % (n_img, os.path.splitext(it.path)[1] or ".png")
                        shutil.copyfile(it.path, os.path.join(images_dir, name))
                        rel = (images_name + "/" + name) if images_name else name
                    except OSError:
                        rel = None
                parts.append(_pic_md(it, rel))
    text = "\n\n".join(p for p in parts if p)
    return _tighten_lists(re.sub(r"\n{3,}", "\n\n", text)).strip() + "\n"


def write_markdown(pages, md_path, images=True, source=None) -> str:
    stem = os.path.splitext(os.path.basename(md_path))[0]
    images_name = stem + "_images"
    images_dir = os.path.join(os.path.dirname(md_path), images_name) if images else None
    text = render_pages(pages, images_dir, images_name, source=source)
    tmp = md_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, md_path)
    return md_path


# ----------------------------------------------------------------------------------------------
# Other document types (what MarkItDown also reads)
# ----------------------------------------------------------------------------------------------
def _rows_to_md(rows) -> str:
    rows = [[_esc_cell("" if c is None else str(c)) for c in r] for r in rows]
    rows = [r for r in rows if any(x for x in r)]
    if not rows:
        return ""
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    out = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * width]
    for r in rows[1:]:
        out.append("| " + " | ".join(r) + " |")
    return "\n".join(out)


def _docx_to_md(path) -> str:
    from docx import Document
    from docx.table import Table as _T
    from docx.text.paragraph import Paragraph as _P
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    doc = Document(path)
    levels = {}
    for st in doc.styles:
        name = (getattr(st, "name", "") or "").lower()
        m = re.search(r"(?:heading|عنوان)\s*(\d)", name)
        if m:
            levels[st.style_id] = int(m.group(1))
        elif name == "title":
            levels[st.style_id] = 1
    out = []
    for child in doc.element.body.iterchildren():
        if child.tag == W + "p":
            p = _P(child, doc)
            text = _clean("".join(
                ("**" + r.text.strip() + "**") if (r.bold and r.text and r.text.strip()) else (r.text or "")
                for r in p.runs)) or _clean(p.text)
            if not text:
                continue
            lvl = levels.get(getattr(p.style, "style_id", None), 0)
            sname = (getattr(p.style, "name", "") or "").lower()
            if lvl:
                out.append("#" * min(6, lvl) + " " + re.sub(r"\*\*", "", text))
            elif "list" in sname or "قائمة" in sname:
                out.append("- " + text)
            else:
                out.append(_esc_line(text))
        elif child.tag == W + "tbl":
            t = _T(child, doc)
            rows = [[c.text for c in row.cells] for row in t.rows]
            md = _rows_to_md(rows)
            if md:
                out.append(md)
    return "\n\n".join(out)


def _pptx_to_md(path) -> str:
    from pptx import Presentation
    prs = Presentation(path)
    out = []
    for i, slide in enumerate(prs.slides, 1):
        out.append("## شريحة %d" % i)
        for shape in slide.shapes:
            if shape.has_table:
                rows = [[c.text for c in row.cells] for row in shape.table.rows]
                md = _rows_to_md(rows)
                if md:
                    out.append(md)
                continue
            is_title = False
            try:
                is_title = shape == slide.shapes.title
            except Exception:
                is_title = False
            if not getattr(shape, "has_text_frame", False):
                if shape.shape_type is not None and "PICTURE" in str(shape.shape_type):
                    out.append("[صورة]")
                continue
            for para in shape.text_frame.paragraphs:
                text = _clean("".join(r.text or "" for r in para.runs)) or _clean(para.text)
                if not text:
                    continue
                if is_title:
                    out.append("### " + re.sub(r"\*\*", "", text))
                    is_title = False
                else:
                    out.append(("- " if para.level else "") + _esc_line(text))
        try:
            if slide.has_notes_slide:
                note = _clean(slide.notes_slide.notes_text_frame.text)
                if note:
                    out.append("> ملاحظات: " + note)
        except Exception:
            pass
    return "\n\n".join(out)


def _xlsx_to_md(path) -> str:
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True, read_only=True)
    out = []
    for ws in wb.worksheets:
        rows = []
        for row in ws.iter_rows(values_only=True):
            rows.append(["" if v is None else v for v in row])
            if len(rows) > 5000:
                break
        md = _rows_to_md(rows)
        if md:
            out.append("## " + str(ws.title))
            out.append(md)
    wb.close()
    return "\n\n".join(out)


def _csv_to_md(path) -> str:
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as f:
        sample = f.read(8192)
        f.seek(0)
        try:
            dialect = _csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except _csv.Error:
            dialect = _csv.excel
        rows = [r for _, r in zip(range(5000), _csv.reader(f, dialect))]
    return _rows_to_md(rows)


def _html_to_md(path) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(raw, "html.parser")
        for bad in soup(["script", "style", "noscript"]):
            bad.decompose()
        body = soup.body or soup
        import markdownify
        return _clean_md(markdownify.markdownify(str(body), heading_style="ATX"))
    except Exception:
        text = re.sub(rb"<[^>]+>", b" ", raw).decode("utf-8", "replace")
        return _clean_md(_html.unescape(text))


def _clean_md(text) -> str:
    text = (text or "").replace("\r", "")
    text = re.sub(r"[ \t ]+\n", "\n", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def _text_to_md(path) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        raw = f.read(4_000_000)
    ext = os.path.splitext(path)[1].lower()
    if ext in (".md", ".markdown", ".txt", ".text"):
        return _clean_md(raw)
    if ext in (".json", ".jsonl"):
        try:
            pretty = json.dumps(json.loads(raw), ensure_ascii=False, indent=2)
        except ValueError:
            pretty = raw
        return "```json\n" + pretty.strip() + "\n```"
    return "```xml\n" + raw.strip() + "\n```"


def convert_file(path, source=None) -> str:
    """Any supported non-PDF document -> Markdown."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".docx":
        body = _docx_to_md(path)
    elif ext == ".pptx":
        body = _pptx_to_md(path)
    elif ext in (".xlsx", ".xlsm"):
        body = _xlsx_to_md(path)
    elif ext in (".csv", ".tsv"):
        body = _csv_to_md(path)
    elif ext in (".html", ".htm"):
        body = _html_to_md(path)
    elif ext in OTHER_EXTS:
        body = _text_to_md(path)
    else:
        raise ValueError("صيغة غير مدعومة: " + ext)
    head = "<!-- " + _clean(str(source or os.path.basename(path))) + " — PDF2Word AI, بوطيب أحمد -->\n\n"
    return head + _clean_md(body) + "\n"


def write_file_markdown(path, md_path, source=None) -> str:
    text = convert_file(path, source)
    tmp = md_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, md_path)
    return md_path
