# -*- coding: utf-8 -*-
"""Built-in OCR engine: RapidOCR (PaddleOCR PP-OCR models running on ONNX Runtime).

It is installed with the program's Python libraries, so scanned PDFs can be read even when
Tesseract is not installed. The models (a few MB) are downloaded automatically the first time.
"""
from __future__ import annotations

import importlib.util
import os
import statistics
import threading

from PIL import Image, ImageDraw, ImageFont

from . import textutils as tu
from .model import Paragraph, Run
from .ocr import OcrLine, OcrResult, ink_bands

# Tesseract language codes -> PP-OCR recognition model families
_FAMILY = {
    "ara": "arabic", "fas": "arabic", "per": "arabic", "urd": "arabic", "kur": "arabic", "uig": "arabic", "pus": "arabic",
    "fra": "latin", "deu": "latin", "spa": "latin", "ita": "latin", "por": "latin", "tur": "latin", "nld": "latin",
    "ind": "latin", "msa": "latin", "pol": "latin", "ron": "latin", "swe": "latin", "dan": "latin", "nor": "latin",
    "rus": "eslav", "ukr": "eslav", "bel": "eslav", "eng": "en", "chi_sim": "ch", "chi_tra": "chinese_cht",
    "jpn": "japan", "kor": "korean", "hin": "devanagari", "mar": "devanagari", "nep": "devanagari",
    "tha": "th", "ell": "el", "tam": "ta", "tel": "te",
}


def installed() -> bool:
    try:
        return importlib.util.find_spec("rapidocr") is not None or importlib.util.find_spec("rapidocr_onnxruntime") is not None
    except (ImportError, ValueError):
        return False


def family_for(langs: str) -> str:
    parts = [p for p in (langs or "").split("+") if p]
    fams = [_FAMILY.get(p) for p in parts]
    if "arabic" in fams:
        return "arabic"  # the Arabic model also reads English
    for f in fams:
        if f and f not in ("en",):
            return f
    return "en" if "en" in fams else "ch"


class EmbeddedOCR:
    name = "embedded"
    label = "محرك OCR المدمج"

    def __init__(self, langs="ara+eng", log=None, threads=0):
        self.langs = langs or "ara+eng"
        self.family = family_for(self.langs)
        self.log = log or (lambda *_: None)
        self.threads = int(threads or 0)
        self._engine = None
        self._lock = threading.Lock()
        self.broken = None  # error text once the engine cannot start

    # -- engine construction (tolerant to RapidOCR API versions) ---------------------------
    def _create(self):
        try:
            import rapidocr as R  # RapidOCR 3.x
        except ImportError:
            from rapidocr_onnxruntime import RapidOCR as Legacy  # RapidOCR 1.x: Chinese/English models only
            return "v1", Legacy()
        RapidOCR = R.RapidOCR
        LangRec = getattr(R, "LangRec", None)
        OCRVersion = getattr(R, "OCRVersion", None)
        if LangRec is None or OCRVersion is None:
            try:
                from rapidocr.utils.typings import LangRec as LR, OCRVersion as OV
                LangRec, OCRVersion = LangRec or LR, OCRVersion or OV
            except Exception:
                pass
        attempts = []
        extra = {}
        if self.threads > 0:
            extra = {"EngineConfig.onnxruntime.intra_op_num_threads": self.threads}
        if LangRec is not None and OCRVersion is not None:
            lr = getattr(LangRec, self.family.upper(), None)
            for ver in ("PPOCRV5", "PPOCRV4"):
                ov = getattr(OCRVersion, ver, None)
                if lr is not None and ov is not None:
                    attempts.append({"Rec.lang_type": lr, "Rec.ocr_version": ov})
        attempts.append({"Rec.lang_type": self.family})
        if self.family in ("ch", "en"):
            attempts.append({})
        last = None
        for params in attempts:
            for with_extra in ((True, False) if extra else (False,)):
                p = dict(params, **extra) if with_extra else dict(params)
                try:
                    return "v3", (RapidOCR(params=p) if p else RapidOCR())
                except Exception as e:  # unknown key / model not in this version / download failed
                    last = e
        raise RuntimeError(f"تعذّر تشغيل محرك OCR المدمج: {last}")

    def engine(self):
        if self.broken:
            raise RuntimeError(self.broken)
        with self._lock:
            if self._engine is None:
                try:
                    self._engine = self._create()
                except Exception as e:
                    self.broken = str(e)
                    raise
        return self._engine

    @staticmethod
    def _run(eng, arr):
        kind, e = eng
        if kind == "v3":
            out = e(arr)
            boxes = getattr(out, "boxes", None)
            txts = getattr(out, "txts", None)
            scores = getattr(out, "scores", None)
            if boxes is None or txts is None:
                return []
            if scores is None:
                scores = [1.0] * len(txts)
            res = []
            for b, t, sc in zip(boxes, txts, scores):
                try:
                    pts = [(float(p[0]), float(p[1])) for p in b]
                except (TypeError, IndexError):
                    continue
                res.append((pts, str(t or ""), float(sc or 0.0)))
            return res
        result, _ = e(arr)
        out = []
        for item in result or []:
            try:
                pts = [(float(p[0]), float(p[1])) for p in item[0]]
                out.append((pts, str(item[1] or ""), float(item[2] or 0.0)))
            except (TypeError, IndexError, ValueError):
                continue
        return out

    # -- page OCR -------------------------------------------------------------------------
    def ocr(self, img: Image.Image, dpi: int = 300) -> OcrResult:
        import numpy as np

        eng = self.engine()
        im = img.convert("RGB")
        scale = 1.0
        if max(im.size) > 2600:  # the detector works on ~2000 px; keeps it fast
            scale = 2600.0 / max(im.size)
            im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.LANCZOS)
        raw = self._run(eng, np.array(im))
        lines = []
        for pts, text, score in raw:
            text = tu.normalize_text(text).strip()
            if not text:
                continue
            xs, ys = [p[0] for p in pts], [p[1] for p in pts]
            lines.append({"text": text, "score": max(0.0, min(1.0, score)),
                          "box": (min(xs) / scale, min(ys) / scale, max(xs) / scale, max(ys) / scale)})
        fix_direction(lines)
        groups = group_lines(lines, dpi)
        res = OcrResult(dpi=dpi, variant="embedded")
        res.paragraphs = groups
        res.words = sum(len(l["text"].split()) for l in lines)
        res.conf = 100.0 * (sum(l["score"] * len(l["text"]) for l in lines) / max(1, sum(len(l["text"]) for l in lines))) if lines else 0.0
        res.text = "\n\n".join(" ".join(l.text for l in g) for g in groups)
        # pictures: big areas of ink without text (photos, charts, logos)
        heights = sorted(l["box"][3] - l["box"][1] for l in lines) or [dpi * 0.18]
        line_h = heights[len(heights) // 2]
        pics = []
        for x0, y0, x1, y1, ink in ink_bands(img, [l["box"] for l in lines]):
            bw, bh = x1 - x0, y1 - y0
            if bw * bh >= 0.012 * img.width * img.height and bh >= 3 * line_h and ink >= 40:
                inside = sum(1 for l in lines if x0 <= (l["box"][0] + l["box"][2]) / 2 <= x1 and y0 <= (l["box"][1] + l["box"][3]) / 2 <= y1)
                if inside < 5:
                    pics.append((int(x0), int(y0), int(x1), int(y1)))
        res.pictures = pics
        return res

    def self_test(self):
        """Run the engine on a small generated image. Returns (ok, message)."""
        try:
            img = Image.new("RGB", (1000, 160), "white")
            d = ImageDraw.Draw(img)
            try:
                font = ImageFont.load_default(size=56)
            except TypeError:
                font = ImageFont.load_default()
            d.text((30, 40), "PDF2Word OCR 2026", fill="black", font=font)
            r = self.ocr(img, dpi=150)
            txt = r.text.replace(" ", "").upper()
            ok = "2026" in txt or "OCR" in txt or "PDF" in txt
            return ok, (f"محرك OCR المدمج يعمل ✔ (قرأ: {r.text.strip()[:40]})" if ok
                        else f"المحرك يعمل لكن نتيجة الاختبار غير متوقعة: {r.text[:60]}")
        except Exception as e:
            return False, str(e)


def fix_direction(lines):
    """PP-OCR reads a text line from left to right, so Arabic can come out in visual
    (reversed) order. Decide per page which order reads like real Arabic."""
    ar = [l for l in lines if tu.arabic_ratio(l["text"]) > 0.3]
    if not ar:
        return
    n1, r1 = tu.arabic_order_scores(" ".join(l["text"] for l in ar))
    flipped = [tu.reorder_string_visual(l["text"], True) for l in ar]
    n2, r2 = tu.arabic_order_scores(" ".join(flipped))
    if n2 > n1 * 1.2 + 1 and n2 >= r2:
        for l, f in zip(ar, flipped):
            l["text"] = f


def group_lines(lines, dpi):
    """Detected text boxes -> paragraphs (lists of OcrLine) in reading order (columns, RTL)."""
    if not lines:
        return []
    s = 72.0 / dpi
    # 1) join pieces of one visual line that the detector split
    rows = sorted(lines, key=lambda l: (l["box"][1] + l["box"][3]) / 2)
    merged = []
    for l in rows:
        b = l["box"]
        h = b[3] - b[1]
        cy = (b[1] + b[3]) / 2
        target = None
        for m in reversed(merged[-8:]):
            mb = m["box"]
            mh = mb[3] - mb[1]
            if abs(cy - (mb[1] + mb[3]) / 2) < 0.5 * min(h, mh):
                gap = max(b[0] - mb[2], mb[0] - b[2])
                if gap < 1.6 * min(h, mh):
                    target = m
                    break
        if target is None:
            merged.append({"parts": [l], "box": b})
        else:
            target["parts"].append(l)
            mb = target["box"]
            target["box"] = (min(mb[0], b[0]), min(mb[1], b[1]), max(mb[2], b[2]), max(mb[3], b[3]))
    olines = []
    for m in merged:
        txt_all = " ".join(p["text"] for p in m["parts"])
        rtl = tu.arabic_ratio(txt_all) > 0.4
        parts = sorted(m["parts"], key=lambda p: p["box"][0], reverse=rtl)
        b = m["box"]
        olines.append(OcrLine(text=" ".join(p["text"] for p in parts), bbox=(b[0] * s, b[1] * s, b[2] * s, b[3] * s), height=(b[3] - b[1]) * s))
    # 2) blocks of lines that belong together
    olines.sort(key=lambda l: (l.bbox[1], l.bbox[0]))
    blocks = []
    for ln in olines:
        best = None
        for blk in blocks[-12:]:
            last = blk[-1]
            vgap = ln.bbox[1] - last.bbox[3]
            hmin, hmax = min(ln.height, last.height), max(ln.height, last.height)
            if vgap < -0.3 * hmin or vgap > 0.9 * hmax or hmax / max(hmin, 0.1) > 1.35:
                continue
            bx0 = min(x.bbox[0] for x in blk)
            bx1 = max(x.bbox[2] for x in blk)
            ov = min(ln.bbox[2], bx1) - max(ln.bbox[0], bx0)
            if ov < 0.4 * min(ln.bbox[2] - ln.bbox[0], bx1 - bx0):
                continue
            if best is None or vgap < best[0]:
                best = (vgap, blk)
        if best is None:
            blocks.append([ln])
        else:
            best[1].append(ln)
    # 3) reading order of blocks (columns right-to-left for Arabic)
    from .layout import xy_cut

    proxies = []
    for blk in blocks:
        txt = " ".join(l.text for l in blk)
        p = Paragraph(runs=[Run(txt)], rtl=tu.is_rtl_text(txt), line_count=len(blk),
                      bbox=(min(l.bbox[0] for l in blk), min(l.bbox[1] for l in blk), max(l.bbox[2] for l in blk), max(l.bbox[3] for l in blk)))
        p._blk = blk
        proxies.append(p)
    ordered = []
    xy_cut(proxies, (0, 0, 1e6, 1e6), ordered)
    # 4) paragraphs inside a block: a line ending early closes the paragraph
    out = []
    for p, _ in ordered:
        blk = sorted(p._blk, key=lambda l: l.bbox[1])
        bx0 = min(l.bbox[0] for l in blk)
        bx1 = max(l.bbox[2] for l in blk)
        bw = max(bx1 - bx0, 1.0)
        cur = [blk[0]]
        for prev, ln in zip(blk, blk[1:]):
            free = (prev.bbox[0] - bx0) if p.rtl else (bx1 - prev.bbox[2])
            if free > max(0.15 * bw, 2.5 * prev.height):
                out.append(cur)
                cur = [ln]
            else:
                cur.append(ln)
        out.append(cur)
    return out
