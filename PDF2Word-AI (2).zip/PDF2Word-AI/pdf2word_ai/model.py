# -*- coding: utf-8 -*-
"""Document model shared by the extractor, the OCR/AI path and the Word writer."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Run:
    text: str
    bold: bool = False
    italic: bool = False
    size: float | None = None
    font: str | None = None
    color: str | None = None  # "RRGGBB" or None for automatic (black)
    superscript: bool = False
    underline: bool = False


@dataclass
class Paragraph:
    runs: list
    rtl: bool = False
    align: str | None = None  # None (start) | "center" | "left" | "right" | "justify"
    heading: int = 0  # 0 = body text, 1..3 = heading level
    size: float | None = None  # dominant font size in points
    bbox: tuple | None = None  # (x0, top, x1, bottom) on the page
    line_count: int = 1
    is_list: bool = False
    source: str = "native"  # native | ocr | ai
    bold_all: bool = False
    space_before: float = 0.0  # extra vertical space (pt) to mimic the original layout

    @property
    def text(self) -> str:
        return "".join(r.text for r in self.runs)


@dataclass
class TableCell:
    paragraphs: list
    rowspan: int = 1
    colspan: int = 1


@dataclass
class Table:
    grid: list  # list of rows; each row is a list of TableCell or None (covered by a span)
    rtl: bool = False
    col_widths: list | None = None  # points, in grid (logical) order
    bbox: tuple | None = None

    @property
    def text(self) -> str:
        out = []
        for row in self.grid:
            for c in row:
                if c is not None:
                    out.extend(p.text for p in c.paragraphs)
        return "\n".join(out)


@dataclass
class Picture:
    path: str  # PNG/JPEG file on disk
    width: float  # points
    height: float
    bbox: tuple | None = None
    align: str | None = None
    kind: str = "image"  # image | figure | page


@dataclass
class PageResult:
    index: int
    width: float
    height: float
    items: list = field(default_factory=list)
    method: str = "native"  # native | ocr | ocr_layer | ai | blank | image
    notes: list = field(default_factory=list)
    ocr_conf: float | None = None
    ai_used: bool = False
    needs_review: bool = False
    uncertain: int = 0
    text_bounds: tuple | None = None  # (x0, top, x1, bottom) of the text on the page
    chars_in: int = 0  # visible characters found in the PDF page (native pages)
    chars_out: int = 0  # visible characters written for that page
    col_plan: list = field(default_factory=lambda: [(1, 0, 0.0)])  # (columns, first item index, gap pt)
    engine: str | None = None  # OCR engine that produced the text (tesseract / embedded)

    def plain_text(self) -> str:
        parts = []
        for it in self.items:
            if isinstance(it, Paragraph):
                parts.append(it.text)
            elif isinstance(it, Table):
                parts.append(it.text)
        return "\n".join(parts)
