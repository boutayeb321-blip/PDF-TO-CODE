# -*- coding: utf-8 -*-
"""PDF2Word AI — convert every PDF on a drive, folder or Google Drive link into a faithful Word
document, read scanned/image PDFs with built-in OCR, and analyse the content with free AI.

من إنجاز بوطيب أحمد — by Boutib Ahmed."""
__version__ = "1.4.0"
__author__ = "بوطيب أحمد (Boutib Ahmed)"
AUTHOR = "بوطيب أحمد (Boutib Ahmed)"
