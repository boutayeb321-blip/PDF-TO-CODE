# -*- coding: utf-8 -*-
"""Native (digital) PDF page analysis.

pdfplumber gives every glyph with its position, font and colour. From that we rebuild:
glyph rows -> line fragments (split at column gutters) -> logical text (bidi) -> blocks ->
paragraphs, plus ruled tables, raster images and vector figures, in reading order.
"""
from __future__ import annotations

import io
import os
import re
import statistics
import unicodedata
from collections import Counter

from . import textutils as tu
from .model import PageResult, Paragraph, Picture, Run, Table, TableCell

PUA_BULLETS = {
    "": "•", "": "▪", "": "➢", "": "✓", "": "❖",
    "": "□", "": "●", "": "■", "": "➢", "": "◆",
}
LIST_MARKER = re.compile(
    r"^\s*(?:[•▪●○■□◆◇➢➤►▶✓✔❖◦‣⁃\-–—*]|\(?[0-9٠-٩۰-۹]{1,3}[.)\-–]|\(?[a-zA-Z][.)]|\(?[أابجدهوزحطيكلمنسعفصقرشتثخذضظغ][)\-–])\s+"
)


# ----------------------------------------------------------------------------------------------
# Fonts and colours
# ----------------------------------------------------------------------------------------------
_SUBSET = re.compile(r"^[A-Z]{6}\+")
_KNOWN_FONTS = {
    "timesnewroman": "Times New Roman", "timesnewromanps": "Times New Roman", "times": "Times New Roman",
    "timesroman": "Times New Roman", "helvetica": "Arial", "arial": "Arial", "arialmt": "Arial",
    "arialunicodems": "Arial Unicode MS", "couriernew": "Courier New", "courier": "Courier New",
    "calibri": "Calibri", "cambria": "Cambria", "tahoma": "Tahoma", "verdana": "Verdana",
    "georgia": "Georgia", "garamond": "Garamond", "segoeui": "Segoe UI", "simplifiedarabic": "Simplified Arabic",
    "traditionalarabic": "Traditional Arabic", "arabictypesetting": "Arabic Typesetting",
    "sakkalmajalla": "Sakkal Majalla", "andalus": "Andalus", "aldhabi": "Aldhabi", "ubuntu": "Ubuntu",
    "dejavusans": "DejaVu Sans", "dejavuserif": "DejaVu Serif", "liberationsans": "Arial",
    "liberationserif": "Times New Roman", "notonaskharabic": "Noto Naskh Arabic", "amiri": "Amiri",
    "notosansarabic": "Noto Sans Arabic", "notokufiarabic": "Noto Kufi Arabic", "symbol": "Symbol",
    "wingdings": "Wingdings", "bookantiqua": "Book Antiqua", "centurygothic": "Century Gothic",
    "trebuchetms": "Trebuchet MS", "lucidasans": "Lucida Sans", "palatinolinotype": "Palatino Linotype",
    "candara": "Candara", "constantia": "Constantia", "corbel": "Corbel", "consolas": "Consolas",
}
_FONT_CACHE: dict = {}


def font_info(name: str | None):
    """Return (word_font_name | None, bold, italic) for a PDF font name."""
    if not name:
        return None, False, False
    hit = _FONT_CACHE.get(name)
    if hit:
        return hit
    n = _SUBSET.sub("", name)
    low = n.lower()
    bold = bool(re.search(r"bold|black|heavy|semibold|demi|extrabold|[-,]bd\b|_bd\b", low))
    italic = bool(re.search(r"italic|oblique|[-,]it\b", low))
    base = re.split(r"[-,+]", n)[0]
    base = re.sub(r"(PSMT|PS|MT|Std|Pro|LT|Regular|Roman|Bold|Italic|Oblique|Light|Medium)$", "", base) or base
    key = re.sub(r"[^a-z0-9]", "", base.lower())
    word = _KNOWN_FONTS.get(key)
    if word is None:
        if re.match(r"^(F|T|C|TT|R|CID|Font|T3)\d", base) or not re.match(r"^[A-Za-z][A-Za-z0-9 ]{2,40}$", base):
            word = None
        else:
            word = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", base).strip()
    res = (word, bold, italic)
    _FONT_CACHE[name] = res
    return res


def color_hex(c) -> str | None:
    if c is None:
        return None
    if isinstance(c, (int, float)):
        c = (c,)
    if not isinstance(c, (tuple, list)) or not c:
        return None
    try:
        v = [float(x) for x in c]
    except (TypeError, ValueError):
        return None
    if len(v) == 1:
        r = g = b = v[0]
    elif len(v) == 3:
        r, g, b = v
    elif len(v) == 4:
        C, M, Y, K = v
        r, g, b = (1 - C) * (1 - K), (1 - M) * (1 - K), (1 - Y) * (1 - K)
    else:
        return None
    r, g, b = (min(1.0, max(0.0, x)) for x in (r, g, b))
    if max(r, g, b) < 0.25 and max(abs(r - g), abs(g - b), abs(r - b)) < 0.12:
        return None  # black / near black -> automatic colour
    if min(r, g, b) > 0.85:
        return None  # white text (was on a dark background we do not reproduce) -> automatic
    return "%02X%02X%02X" % (round(r * 255), round(g * 255), round(b * 255))


# ----------------------------------------------------------------------------------------------
# Glyph boxes
# ----------------------------------------------------------------------------------------------
class CB:
    __slots__ = ("text", "x0", "x1", "top", "bottom", "size", "font", "bold", "italic", "color", "kind", "rawfont")

    def __init__(self, text, x0, x1, top, bottom, size, font, bold, italic, color, kind, rawfont=""):
        self.text, self.x0, self.x1, self.top, self.bottom = text, x0, x1, top, bottom
        self.size, self.font, self.bold, self.italic, self.color, self.kind = size, font, bold, italic, color, kind
        self.rawfont = rawfont

    @property
    def cy(self):
        return (self.top + self.bottom) / 2


def make_charboxes(chars, fix_mojibake=False):
    out = []
    for c in chars:
        raw = c.get("text") or ""
        if not raw:
            continue
        if raw in PUA_BULLETS:
            raw = PUA_BULLETS[raw]
        if fix_mojibake:
            raw = tu.fix_cp1256_mojibake(raw) or raw
        t = tu.normalize_text(raw)
        if not t:
            continue
        if t.isspace():
            kind = "s"
            t = " "
        elif tu.is_mark_text(t):
            kind = "m"
        elif float(c["x1"]) - float(c["x0"]) < 0.02 and not (c.get("adv") or 0):
            kind = "x"  # zero-width glyph without a usable mapping (unmapped diacritic) -> not text
        else:
            kind = "c"
        size = float(c.get("size") or 0) or max(1.0, float(c["bottom"]) - float(c["top"]))
        word, bold, italic = font_info(c.get("fontname"))
        out.append(CB(t, float(c["x0"]), float(c["x1"]), float(c["top"]), float(c["bottom"]), size, word, bold,
                      italic, color_hex(c.get("non_stroking_color")), kind, c.get("fontname") or ""))
    return out


# ----------------------------------------------------------------------------------------------
# Rows and line fragments
# ----------------------------------------------------------------------------------------------
class Row:
    __slots__ = ("chars", "cy", "h", "_n", "_sy", "_sh", "x0", "x1", "size", "gaps", "ink")

    def __init__(self, c):
        self.chars = [c]
        self._n = 1
        self._sy = c.cy
        self._sh = max(c.bottom - c.top, 1.0)
        self.cy = c.cy
        self.h = self._sh

    def add(self, c):
        self.chars.append(c)
        if c.kind not in ("m", "x"):
            self._n += 1
            self._sy += c.cy
            self._sh += max(c.bottom - c.top, 1.0)
            self.cy = self._sy / self._n
            self.h = self._sh / self._n

    def finish(self):
        self.chars.sort(key=lambda c: (c.x0, c.x1))
        ink = [c for c in self.chars if c.kind == "c"] or self.chars
        self.ink = ink
        self.x0 = min(c.x0 for c in ink)
        self.x1 = max(c.x1 for c in ink)
        sizes = [c.size for c in ink]
        self.size = statistics.median(sizes) if sizes else 10.0

    def has_ink(self, a, b):
        for c in self.ink:
            if c.x1 > a and c.x0 < b:
                return True
        return False


def build_rows(cbs):
    cbs = sorted(cbs, key=lambda c: c.cy)
    rows: list[Row] = []
    for c in cbs:
        h = max(c.bottom - c.top, 1.0)
        best, bestd = None, None
        for r in rows[-14:]:
            d = abs(c.cy - r.cy)
            lim = 0.8 * r.h if c.kind in ("m", "x") else 0.42 * min(h, r.h)
            if d <= lim and (bestd is None or d < bestd):
                best, bestd = r, d
        if best is None:
            rows.append(Row(c))
        else:
            best.add(c)
    rows = [r for r in rows if any(c.kind == "c" for c in r.chars)]
    for r in rows:
        r.finish()
    rows.sort(key=lambda r: r.cy)
    return rows


def split_rows(rows):
    """Split rows at column gutters. A gap is a gutter when neighbouring rows also have
    white space there (justified text has random wide gaps, columns have aligned ones)."""
    for r in rows:
        gaps = []
        ink = r.ink
        for a, b in zip(ink, ink[1:]):
            if b.x0 - a.x1 >= max(0.9 * r.size, 5.0):
                gaps.append((a.x1, b.x0))
        r.gaps = gaps
    frags = []
    for i, r in enumerate(rows):
        cuts = []
        for gl, gr in r.gaps:
            if gr - gl >= 3.0 * r.size:
                cuts.append((gl, gr))
                continue
            sup = con = 0
            for j in range(max(0, i - 5), min(len(rows), i + 6)):
                if j == i:
                    continue
                n = rows[j]
                if abs(n.cy - r.cy) > 5 * max(r.h, n.h):
                    continue
                if n.x0 >= gl - 1 or n.x1 <= gr + 1:
                    continue
                if n.has_ink(gl + 0.5, gr - 0.5):
                    con += 1
                else:
                    sup += 1
            if sup >= 1 and sup >= con:
                cuts.append((gl, gr))
        if not cuts:
            frags.append(r.chars)
            continue
        bounds = [(gl + gr) / 2 for gl, gr in cuts]
        parts = [[] for _ in range(len(bounds) + 1)]
        for c in r.chars:
            cx = (c.x0 + c.x1) / 2
            k = 0
            while k < len(bounds) and cx > bounds[k]:
                k += 1
            parts[k].append(c)
        parts = [p for p in parts if any(c.kind == "c" for c in p)]
        frags.extend(_merge_markers(parts, r.size))
    return frags


_MARKER_ONLY = re.compile(r"^(?:[•▪●○■□◆◇➢➤►▶✓✔❖◦‣⁃\-–—*]|\(?[0-9٠-٩۰-۹]{1,3}[.)\-–]?\)?|\(?[a-zA-Z][.)]|[أابجدهوزحطيكلمنسعفصقرشتثخذضظغ][.)\-–])$")


def _merge_markers(parts, size):
    """A list bullet/number separated from its text by an indent must stay with the text."""
    if len(parts) < 2:
        return parts
    out = [list(p) for p in parts]
    i = 0
    while i < len(out):
        p = out[i]
        ink = [c for c in p if c.kind == "c"]
        txt = "".join(c.text for c in sorted(ink, key=lambda c: c.x0))
        width = max(c.x1 for c in ink) - min(c.x0 for c in ink) if ink else 0
        if ink and width < 3 * size and _MARKER_ONLY.match(txt) and len(out) > 1:
            left = out[i - 1] if i > 0 else None
            right = out[i + 1] if i + 1 < len(out) else None
            lgap = (min(c.x0 for c in p) - max(c.x1 for c in left)) if left else 1e9
            rgap = (min(c.x0 for c in right) - max(c.x1 for c in p)) if right else 1e9
            if rgap <= lgap and right is not None:
                out[i + 1] = p + right
            elif left is not None:
                out[i - 1] = left + p
            del out[i]
            continue
        i += 1
    return out


# ----------------------------------------------------------------------------------------------
# Units -> logical runs
# ----------------------------------------------------------------------------------------------
class Unit:
    __slots__ = ("text", "x0", "x1", "top", "bottom", "size", "font", "bold", "italic", "color", "space", "sup")

    def __init__(self, c, text=None, space=False):
        self.text = c.text if text is None else text
        self.x0, self.x1, self.top, self.bottom = c.x0, c.x1, c.top, c.bottom
        self.size, self.font, self.bold, self.italic, self.color = c.size, c.font, c.bold, c.italic, c.color
        self.space = space or c.kind == "s"
        self.sup = False

    def fmt(self):
        return (self.bold, self.italic, round(self.size * 2) / 2, self.font, self.color, self.sup)


def _mark_center(m):
    return (m.x0 + m.x1) / 2 if (m.x1 - m.x0) > 0.3 else m.x0 + 0.15 * m.size


def _nearest_letter(center, letters, size):
    best, bd = None, 1e9
    for u in letters:
        if u.x0 - 0.4 <= center <= u.x1 + 0.4:
            d = abs(center - (u.x0 + u.x1) / 2) * 0.01
        else:
            d = min(abs(center - u.x0), abs(center - u.x1))
        if d < bd:
            best, bd = u, d
    if best is not None and bd <= 0.7 * size:
        return best
    return None


def learn_stray_marks(rows, doc_state):
    """Learn what unmapped zero-width glyphs mean: when such a glyph sits on a letter whose own
    mapping already carries harakat, that glyph *is* those harakat (same code = same mark)."""
    votes = doc_state.setdefault("stray_votes", {})
    for r in rows:
        strays = [c for c in r.chars if c.kind == "x"]
        if not strays:
            continue
        letters = [c for c in r.chars if c.kind == "c"]
        for st in strays:
            center = _mark_center(st)
            hits = [c for c in letters if c.x0 - 0.35 * st.size <= center <= c.x1 + 0.1 * st.size]
            if len(hits) != 1:
                continue
            base = hits[0]
            marks = "".join(ch for ch in base.text if unicodedata.category(ch) == "Mn")
            if not marks:
                continue
            others = [o for o in strays if o is not st and base.x0 - 0.35 * o.size <= _mark_center(o) <= base.x1 + 0.1 * o.size]
            if others:
                continue
            key = (st.rawfont, st.text)
            votes.setdefault(key, Counter())[marks] += 1
    doc_state["stray_map"] = {k: v.most_common(1)[0][0] for k, v in votes.items() if v}


def make_units(chars, space_factor, doc_state=None):
    doc_state = doc_state or {}
    leak_fix = doc_state.get("leak_fix", False)
    stray_map = doc_state.get("stray_map", {})
    strays = [c for c in chars if c.kind == "x"]
    bases = [Unit(c) for c in chars if c.kind not in ("m", "x")]
    marks = [c for c in chars if c.kind == "m"]
    letters = [u for u in bases if not u.space]
    if leak_fix:
        # Some producers map a glyph to "letter+harakat" once and reuse that mapping for every
        # later occurrence of the plain letter. Keep harakat only where a mark glyph is drawn.
        drawn = [_mark_center(m) for m in strays + marks]
        for u in letters:
            if len(u.text) > 1 and any(unicodedata.category(ch) == "Mn" for ch in u.text):
                lo, hi = u.x0 - 0.35 * u.size, u.x1 + 0.1 * u.size
                if not any(lo <= x <= hi for x in drawn):
                    u.text = "".join(ch for ch in u.text if unicodedata.category(ch) != "Mn") or u.text
    for st in strays:
        mk = stray_map.get((st.rawfont, st.text))
        if not mk:
            continue
        u = _nearest_letter(_mark_center(st), letters, st.size)
        if u is not None and not all(ch in u.text for ch in mk):
            u.text += mk
    for m in marks:
        u = _nearest_letter(_mark_center(m), letters, m.size)
        if u is not None:
            u.text += m.text
        else:
            bases.append(Unit(m))
    bases.sort(key=lambda u: (u.x0, u.x1))
    out = []
    for u in bases:
        if out:
            p = out[-1]
            if u.space and p.space:
                continue
            gap = u.x0 - p.x1
            if not u.space and not p.space and gap > space_factor * min(p.size, u.size):
                sp = Unit(p, text=" ", space=True)
                sp.x0, sp.x1 = p.x1, u.x0
                out.append(sp)
        out.append(u)
    while out and out[0].space:
        out.pop(0)
    while out and out[-1].space:
        out.pop()
    # superscripts (footnote marks): clearly smaller and raised
    if out:
        sizes = [u.size for u in out if not u.space]
        main = max(Counter(round(s) for s in sizes).items(), key=lambda kv: kv[1])[0] if sizes else 0
        base_bottom = statistics.median([u.bottom for u in out if not u.space and abs(u.size - main) < 1]) if sizes else 0
        for u in out:
            if not u.space and u.size <= 0.75 * main and u.bottom < base_bottom - 0.18 * main:
                u.sup = True
    return out


class Line:
    __slots__ = ("units", "x0", "x1", "top", "bottom", "size", "rtl", "strong", "bold_all", "_runs")

    def __init__(self, units):
        self.units = units
        ink = [u for u in units if not u.space]
        self.x0 = min(u.x0 for u in ink)
        self.x1 = max(u.x1 for u in ink)
        self.top = min(u.top for u in ink)
        self.bottom = max(u.bottom for u in ink)
        weights = Counter()
        for u in ink:
            weights[round(u.size * 2) / 2] += len(u.text)
        self.size = weights.most_common(1)[0][0] if weights else 10.0
        text = "".join(u.text for u in units)
        ar = sum(1 for ch in text if tu.bidi_of(ch) in ("AL", "R"))
        lt = sum(1 for ch in text if tu.bidi_of(ch) == "L")
        self.strong = ar + lt
        self.rtl = ar > 0 and ar >= lt
        self.bold_all = all(u.bold for u in ink)
        self._runs = None

    @property
    def h(self):
        return max(self.bottom - self.top, 1.0)

    @property
    def width(self):
        return max(self.x1 - self.x0, 0.1)

    def runs(self, rtl=None, context=None, mirror=False):
        rtl = self.rtl if rtl is None else rtl
        texts = [u.text for u in self.units]
        order, mirrored = tu.visual_to_logical(texts, rtl, context)
        if not mirror:
            mirrored = ()
        runs = []
        last_key = None
        for k in order:
            u = self.units[k]
            t = tu.MIRROR[u.text] if k in mirrored else u.text
            key = last_key if (u.space and last_key is not None) else u.fmt()
            if runs and key == last_key:
                runs[-1].text += t
            else:
                b, i, s, f, col, sup = key
                runs.append(Run(t, bold=b, italic=i, size=s, font=f, color=col, superscript=sup))
                last_key = key
        return runs

    def first_word_width(self, rtl=None):
        rtl = self.rtl if rtl is None else rtl
        texts = [u.text for u in self.units]
        order, _ = tu.visual_to_logical(texts, rtl)
        w = 0.0
        for k in order:
            u = self.units[k]
            if u.space:
                if w > 0:
                    break
                continue
            w += u.x1 - u.x0
        return w

    def logical_text(self, rtl=None, context=None, mirror=False):
        return "".join(r.text for r in self.runs(rtl, context, mirror))


def last_strong(text):
    for ch in reversed(text):
        b = tu.bidi_of(ch)
        if b in ("R", "AL"):
            return "R"
        if b == "L":
            return "L"
    return None


# ----------------------------------------------------------------------------------------------
# Blocks and paragraphs
# ----------------------------------------------------------------------------------------------
def estimate_line_gap(lines):
    gaps = []
    srt = sorted(lines, key=lambda l: l.top)
    for i, ln in enumerate(srt):
        best = None
        for p in reversed(srt[max(0, i - 12):i]):
            if p.bottom > ln.top + 0.3 * ln.h:
                continue
            ov = min(ln.x1, p.x1) - max(ln.x0, p.x0)
            if ov < 0.5 * min(ln.width, p.width) or abs(ln.size - p.size) > 0.2 * max(ln.size, p.size):
                continue
            g = ln.top - p.bottom
            if best is None or g < best:
                best = g
        if best is not None and best < 1.2 * ln.size:
            gaps.append(best)
    if len(gaps) >= 3:
        gaps.sort()
        return gaps[int(len(gaps) * 0.15)]
    med = statistics.median([l.size for l in lines]) if lines else 10
    return 0.2 * med


def group_blocks(lines, line_gap):
    blocks: list[list[Line]] = []
    for ln in sorted(lines, key=lambda l: (l.top, l.x0)):
        best, best_gap = None, None
        for b in blocks[-20:]:
            last = b[-1]
            vgap = ln.top - last.bottom
            if vgap < -0.35 * min(ln.h, last.h):
                continue
            if vgap > line_gap + 0.5 * max(ln.size, last.size):
                continue
            bx0 = min(l.x0 for l in b)
            bx1 = max(l.x1 for l in b)
            ov = min(ln.x1, bx1) - max(ln.x0, bx0)
            if ov < 0.5 * min(ln.width, bx1 - bx0):
                continue
            if abs(ln.size - last.size) > 0.2 * max(ln.size, last.size):
                continue
            if ln.strong > 3 and last.strong > 3 and ln.rtl != last.rtl:
                continue
            if best is None or vgap < best_gap:
                best, best_gap = b, vgap
        if best is None:
            blocks.append([ln])
        else:
            best.append(ln)
    return blocks


def _indented(ln, bx0, bx1, rtl):
    tol = max(1.5 * ln.size, 0.04 * (bx1 - bx0))
    return (ln.x1 < bx1 - tol) if rtl else (ln.x0 > bx0 + tol)


def split_block(lines):
    """Split a block (lines of one column region) into paragraphs."""
    if len(lines) == 1:
        return [lines]
    bx0 = min(l.x0 for l in lines)
    bx1 = max(l.x1 for l in lines)
    bw = bx1 - bx0
    paras = [[lines[0]]]
    for idx in range(1, len(lines)):
        prev, ln = lines[idx - 1], lines[idx]
        rtl = prev.rtl
        new = False
        text = ln.logical_text()
        if LIST_MARKER.match(text):
            new = True
        else:
            free = (prev.x0 - bx0) if rtl else (bx1 - prev.x1)
            short = free > max(0.12 * bw, 2 * prev.size)
            # A line can end early only because the next word did not fit: not a paragraph end.
            if short and free > ln.first_word_width(rtl) + 0.6 * prev.size:
                new = True
            elif _indented(ln, bx0, bx1, rtl) and not _indented(prev, bx0, bx1, rtl):
                nxt = lines[idx + 1] if idx + 1 < len(lines) else None
                prev_is_item = bool(LIST_MARKER.match(paras[-1][0].logical_text()))
                if not prev_is_item and (nxt is None or not _indented(nxt, bx0, bx1, rtl)):
                    new = True
            if not new and prev.bold_all != ln.bold_all and (prev.bold_all and prev.width < 0.7 * bw):
                new = True
        if new:
            paras.append([ln])
        else:
            paras[-1].append(ln)
    return paras


def merge_runs(runs):
    out = []
    for r in runs:
        if not r.text:
            continue
        if out:
            p = out[-1]
            if (p.bold, p.italic, p.size, p.font, p.color, p.superscript) == (r.bold, r.italic, r.size, r.font, r.color, r.superscript):
                p.text += r.text
                continue
        out.append(Run(r.text, r.bold, r.italic, r.size, r.font, r.color, r.superscript))
    return out


def _bracket_score(text):
    pairs = {")": "(", "]": "[", "}": "{", "»": "«"}
    opens = set(pairs.values())
    depth = {k: 0 for k in opens}
    bad = 0
    for ch in text:
        if ch in opens:
            depth[ch] += 1
        elif ch in pairs:
            o = pairs[ch]
            depth[o] -= 1
            if depth[o] < 0:
                bad += 1
                depth[o] = 0
    return bad * 10 + sum(depth.values())


def _choose_mirroring(lines, rtl):
    """PDF producers disagree on whether a mirrored bracket glyph maps to '(' or ')'.
    Pick the interpretation that gives properly nested brackets."""
    sample = "".join(l.logical_text(rtl) for l in lines)
    if not any(ch in tu.MIRROR for ch in sample):
        return False
    plain = _bracket_score(sample)
    if plain == 0:
        return False
    mirrored = _bracket_score("".join(l.logical_text(rtl, mirror=True) for l in lines))
    return mirrored < plain


def lines_to_paragraph(lines, source="native", force_rtl=None):
    ar = sum(max(1, l.strong) for l in lines if l.rtl)
    lt = sum(max(1, l.strong) for l in lines if not l.rtl)
    rtl = (ar >= lt and ar > 0) if force_rtl is None else force_rtl
    mirror = _choose_mirroring(lines, rtl)
    runs = []
    ctx = None
    for i, ln in enumerate(lines):
        lr = ln.runs(rtl, ctx, mirror)
        ltext = "".join(r.text for r in lr)
        if i > 0 and lr:
            prev_text = "".join(r.text for r in runs[-3:]) if runs else ""
            if (not rtl and prev_text.endswith("-") and len(prev_text) > 1 and prev_text[-2].isalpha()
                    and ltext[:1].islower()):
                runs[-1].text = runs[-1].text[:-1]
            elif not prev_text.endswith(" ") and not ltext.startswith(" "):
                runs[-1].text += " "
        runs.extend(lr)
        s = last_strong(ltext)
        if s:
            ctx = s
    runs = merge_runs(runs)
    weights = Counter()
    for r in runs:
        if r.size:
            weights[r.size] += len(r.text.strip())
    size = weights.most_common(1)[0][0] if weights else None
    text = "".join(r.text for r in runs)
    p = Paragraph(runs=runs, rtl=rtl, size=size, line_count=len(lines), source=source,
                  bbox=(min(l.x0 for l in lines), min(l.top for l in lines), max(l.x1 for l in lines),
                        max(l.bottom for l in lines)))
    p.is_list = bool(LIST_MARKER.match(text))
    vis = [r for r in runs if r.text.strip()]
    p.bold_all = bool(vis) and all(r.bold for r in vis)
    p._lines = lines  # kept for alignment detection
    return p


def detect_alignment(p, cx0, cx1):
    lines = getattr(p, "_lines", None)
    if not lines:
        return None
    cw = cx1 - cx0
    if cw <= 5:
        return None
    tol = max(0.025 * cw, 3.0)
    if len(lines) >= 3:
        body = lines[:-1]
        if all(abs(l.x0 - cx0) <= tol and abs(l.x1 - cx1) <= tol for l in body):
            last = lines[-1]
            if abs(last.x0 - cx0) <= tol and abs(last.x1 - cx1) <= tol:
                return "justify"
            # last line of a justified paragraph sits on the start side
            if (p.rtl and abs(last.x1 - cx1) <= tol) or (not p.rtl and abs(last.x0 - cx0) <= tol):
                return "justify"
    mid = (cx0 + cx1) / 2
    if all(abs((l.x0 + l.x1) / 2 - mid) <= max(0.035 * cw, 4.0) for l in lines) and max(l.width for l in lines) < 0.88 * cw:
        return "center"
    if p.rtl:
        if all(abs(l.x1 - cx1) <= tol for l in lines):
            return None
        if all(abs(l.x0 - cx0) <= tol for l in lines) and max(l.width for l in lines) < 0.8 * cw:
            return "left"
    else:
        if all(abs(l.x0 - cx0) <= tol for l in lines):
            return None
        if all(abs(l.x1 - cx1) <= tol for l in lines) and max(l.width for l in lines) < 0.8 * cw:
            return "right"
    return None


# ----------------------------------------------------------------------------------------------
# Reading order (recursive XY-cut, right-to-left aware)
# ----------------------------------------------------------------------------------------------
def _bbox(it):
    return it.bbox


def _union(items):
    return (min(_bbox(i)[0] for i in items), min(_bbox(i)[1] for i in items),
            max(_bbox(i)[2] for i in items), max(_bbox(i)[3] for i in items))


def _split(items, axis, min_gap):
    lo, hi = (0, 2) if axis == 0 else (1, 3)
    srt = sorted(items, key=lambda it: _bbox(it)[lo])
    groups, cur, cur_hi = [], [], None
    for it in srt:
        b = _bbox(it)
        if cur and b[lo] > cur_hi + min_gap:
            groups.append(cur)
            cur, cur_hi = [], None
        cur.append(it)
        cur_hi = b[hi] if cur_hi is None else max(cur_hi, b[hi])
    if cur:
        groups.append(cur)
    return groups


def _group_rtl(items):
    ar = lt = 0
    for it in items:
        if isinstance(it, Paragraph):
            n = len(it.text)
            if it.rtl:
                ar += n
            else:
                lt += n
    return ar > lt


def _paired_rows(g1, g2):
    """Two side-by-side groups whose single-line paragraphs pair up row by row (Arabic poetry,
    label/value forms). Prose columns have multi-line paragraphs and do not pair."""
    p1 = [i for i in g1 if isinstance(i, Paragraph)]
    p2 = [i for i in g2 if isinstance(i, Paragraph)]
    if len(p1) < 3 or len(p2) < 3 or len(p1) != len(g1) or len(p2) != len(g2):
        return False
    if sum(1 for p in p1 + p2 if p.line_count == 1) < 0.85 * (len(p1) + len(p2)):
        return False
    if abs(len(p1) - len(p2)) > max(1, 0.2 * max(len(p1), len(p2))):
        return False
    matched = 0
    for a in p1:
        ca = (a.bbox[1] + a.bbox[3]) / 2
        ha = a.bbox[3] - a.bbox[1]
        if any(abs(ca - (b.bbox[1] + b.bbox[3]) / 2) <= 0.5 * ha for b in p2):
            matched += 1
    return matched >= 0.8 * len(p1)


def xy_cut(items, bounds, out):
    """Append (item, column_bounds) to out in reading order."""
    if not items:
        return
    if len(items) == 1:
        out.append((items[0], bounds))
        return
    rtl = _group_rtl(items)
    xg = _split(items, 0, 3.0)
    yg = _split(items, 1, 0.5)
    # A vertical gutter that no item crosses means columns: read each column fully first.
    if len(xg) > 1:
        xg.sort(key=lambda g: _union(g)[0], reverse=rtl)
        if len(xg) == 2 and _paired_rows(xg[0], xg[1]):
            allp = xg[0] + xg[1]
            rank = {id(it): k for k, it in enumerate(allp)}
            allp.sort(key=lambda it: (round(((it.bbox[1] + it.bbox[3]) / 2) / max(it.bbox[3] - it.bbox[1], 1) * 2), rank[id(it)]))
            for it in allp:
                out.append((it, bounds))
            return
        for g in xg:
            ub = _union(g)
            xy_cut(g, ub, out)
        return
    if len(yg) > 1:
        for g in yg:
            xy_cut(g, bounds, out)
        return
    for it in sorted(items, key=lambda it: (_bbox(it)[1], -_bbox(it)[2] if rtl else _bbox(it)[0])):
        out.append((it, bounds))


# ----------------------------------------------------------------------------------------------
# Tables
# ----------------------------------------------------------------------------------------------
def _cluster_coords(vals, tol=2.0):
    vals = sorted(vals)
    out = []
    for v in vals:
        if out and v - out[-1][-1] <= tol:
            out[-1].append(v)
        else:
            out.append([v])
    return [sum(g) / len(g) for g in out]


def _nearest(coords, v):
    return min(range(len(coords)), key=lambda i: abs(coords[i] - v))


def cell_paragraphs(chars, space_factor, doc_state=None, force_rtl=None):
    if not any(c.kind == "c" for c in chars):
        return []
    rows = build_rows(chars)
    lines = []
    for r in rows:
        units = make_units(r.chars, space_factor, doc_state)
        if any(not u.space for u in units):
            lines.append(Line(units))
    if not lines:
        return []
    paras = []
    for group in split_block(sorted(lines, key=lambda l: l.top)):
        p = lines_to_paragraph(group, force_rtl=force_rtl)
        paras.append(p)
    # alignment inside the cell
    return paras


def extract_tables(page, cbs, space_factor, doc_state=None):
    """Ruled tables found by pdfplumber. Returns (tables, consumed_char_ids)."""
    try:
        found = page.find_tables()
    except Exception:
        return [], set()
    tables, consumed = [], set()
    for t in found:
        cells = [c for c in (t.cells or []) if c]
        if len(cells) < 4:
            continue
        xs = _cluster_coords([v for c in cells for v in (c[0], c[2])])
        ys = _cluster_coords([v for c in cells for v in (c[1], c[3])])
        ncols, nrows = len(xs) - 1, len(ys) - 1
        if ncols < 2 or nrows < 1 or (nrows < 2 and ncols < 3):
            continue
        tb = t.bbox
        inside = [c for c in cbs if tb[0] - 1 <= (c.x0 + c.x1) / 2 <= tb[2] + 1 and tb[1] - 1 <= c.cy <= tb[3] + 1]
        placed = {}
        cell_chars = {}
        for cb in cells:
            c0, c1 = _nearest(xs, cb[0]), _nearest(xs, cb[2])
            r0, r1 = _nearest(ys, cb[1]), _nearest(ys, cb[3])
            if c1 <= c0 or r1 <= r0 or (r0, c0) in placed:
                continue
            placed[(r0, c0)] = (r1 - r0, c1 - c0, cb)
            cell_chars[(r0, c0)] = []
        if len(placed) < 3:
            continue
        # assign glyphs to cells
        keys = list(placed.keys())
        for c in inside:
            cx = (c.x0 + c.x1) / 2
            hit = None
            for k in keys:
                rs, cs, cb = placed[k]
                if cb[0] - 0.5 <= cx <= cb[2] + 0.5 and cb[1] - 0.5 <= c.cy <= cb[3] + 0.5:
                    hit = k
                    break
            if hit is not None:
                cell_chars[hit].append(c)
        nonempty = sum(1 for k in keys if any(ch.kind == "c" for ch in cell_chars[k]))
        if nonempty < 2:
            continue
        grid = [[None] * ncols for _ in range(nrows)]
        covered = set()
        table_rtl = tu.is_rtl_text("".join(c.text for c in inside))
        for (r0, c0), (rs, cs, cb) in placed.items():
            paras = cell_paragraphs(cell_chars[(r0, c0)], space_factor, doc_state, force_rtl=True if table_rtl else None)
            for p in paras:
                p.align = detect_alignment(p, cb[0] + 1.5, cb[2] - 1.5)
            grid[r0][c0] = TableCell(paragraphs=paras, rowspan=rs, colspan=cs)
            for rr in range(r0, r0 + rs):
                for cc in range(c0, c0 + cs):
                    if (rr, cc) != (r0, c0):
                        covered.add((rr, cc))
        for rr in range(nrows):
            for cc in range(ncols):
                if grid[rr][cc] is None and (rr, cc) not in covered:
                    grid[rr][cc] = TableCell(paragraphs=[])
        rtl = table_rtl
        widths = [xs[i + 1] - xs[i] for i in range(ncols)]
        if rtl:  # logical column order for a right-to-left table
            new = [[None] * ncols for _ in range(nrows)]
            for rr in range(nrows):
                for cc in range(ncols):
                    cell = grid[rr][cc]
                    if cell is not None:
                        new[rr][ncols - cc - cell.colspan] = cell
            grid = new
            widths = widths[::-1]
        for c in inside:
            consumed.add(id(c))
        tables.append(Table(grid=grid, rtl=rtl, col_widths=widths, bbox=tuple(tb)))
    return tables, consumed


# ----------------------------------------------------------------------------------------------
# Vector figures (charts / diagrams drawn with paths)
# ----------------------------------------------------------------------------------------------
def find_vector_figures(page, frame, exclude_boxes, cbs):
    W = frame[2] - frame[0]
    H = frame[3] - frame[1]
    objs = []
    for c in page.curves:
        objs.append(("c", (c["x0"], c["top"], c["x1"], c["bottom"])))
    for r in page.rects:
        w, h = r["x1"] - r["x0"], r["bottom"] - r["top"]
        if w * h > 0.6 * W * H:
            continue
        objs.append(("r" if (w > 2 and h > 2) else "l", (r["x0"], r["top"], r["x1"], r["bottom"])))
    for l in page.lines:
        objs.append(("l", (l["x0"], l["top"], l["x1"], l["bottom"])))
    if len(objs) < 4 or len(objs) > 6000:
        return []

    def inside_any(b):
        cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
        return any(e[0] - 2 <= cx <= e[2] + 2 and e[1] - 2 <= cy <= e[3] + 2 for e in exclude_boxes)

    objs = [o for o in objs if not inside_any(o[1])]
    n = len(objs)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    boxes = [o[1] for o in objs]
    order = sorted(range(n), key=lambda i: boxes[i][0])
    pad = 4.0
    for a_i in range(n):
        a = order[a_i]
        ba = boxes[a]
        for b_i in range(a_i + 1, n):
            b = order[b_i]
            bb = boxes[b]
            if bb[0] > ba[2] + pad:
                break
            if bb[1] <= ba[3] + pad and bb[3] >= ba[1] - pad:
                ra, rb = find(a), find(b)
                if ra != rb:
                    parent[ra] = rb
    clusters = {}
    for i in range(n):
        clusters.setdefault(find(i), []).append(i)
    figs = []
    for idx in clusters.values():
        kinds = Counter(objs[i][0] for i in idx)
        x0 = min(boxes[i][0] for i in idx)
        y0 = min(boxes[i][1] for i in idx)
        x1 = max(boxes[i][2] for i in idx)
        y1 = max(boxes[i][3] for i in idx)
        w, h = x1 - x0, y1 - y0
        area = w * h
        if w < 40 or h < 30 or area < 0.008 * W * H or area > 0.85 * W * H:
            continue
        if not (kinds["c"] >= 4 or (kinds["r"] >= 3 and len(idx) >= 6)):
            continue
        txt = sum(1 for c in cbs if c.kind == "c" and x0 <= (c.x0 + c.x1) / 2 <= x1 and y0 <= c.cy <= y1)
        if txt > 160 or txt > 0.004 * area:
            continue  # text-heavy region: keep the text editable
        figs.append((x0 - 2, y0 - 2, x1 + 2, y1 + 2))
    return figs


_CAPTION = re.compile(r"^\s*(fig(ure)?\.?|chart|table|source|graph|الشكل|شكل|رسم|جدول|الجدول|المصدر|مخطط)\b", re.I)


def expand_figures(figs, cbs):
    """Pull axis labels / legends / chart titles (short text right next to a figure) into it,
    so the picture shows the whole chart and the labels are not repeated as loose text."""
    if not figs:
        return figs
    ink = [c for c in cbs if c.kind == "c"]
    if not ink:
        return figs
    frags = split_rows(build_rows([c for c in cbs if c.kind in ("c", "s")]))
    boxes = []
    for fr in frags:
        chars = [c for c in fr if c.kind == "c"]
        if not chars:
            continue
        txt = "".join(c.text for c in sorted(chars, key=lambda c: c.x0))
        size = statistics.median(c.size for c in chars)
        boxes.append([min(c.x0 for c in chars), min(c.top for c in chars), max(c.x1 for c in chars),
                      max(c.bottom for c in chars), txt, size, all(c.bold for c in chars)])
    out = [list(f) for f in figs]
    for _ in range(3):
        changed = False
        for f in out:
            for b in boxes:
                if b is None or len(b[4]) > 30 or _CAPTION.match(b[4]):
                    continue
                if b[0] >= f[0] and b[2] <= f[2] and b[1] >= f[1] and b[3] <= f[3]:
                    continue
                dx = max(0.0, f[0] - b[2], b[0] - f[2])
                dy = max(0.0, f[1] - b[3], b[1] - f[3])
                if max(dx, dy) <= max(14.0, 1.6 * b[5]) and min(dx, dy) == 0.0:
                    f[0], f[1] = min(f[0], b[0] - 1), min(f[1], b[1] - 1)
                    f[2], f[3] = max(f[2], b[2] + 1), max(f[3], b[3] + 1)
                    changed = True
        if not changed:
            break
    return [tuple(f) for f in out]


# ----------------------------------------------------------------------------------------------
# Rendering helpers (pypdfium2)
# ----------------------------------------------------------------------------------------------
def render_regions(pdfium_page, frame, regions, dpi, remove_text=False):
    """Render the page and crop regions (x0, top, x1, bottom in pdfplumber page coords)."""
    if not regions:
        return []
    if remove_text:
        try:
            import pypdfium2.raw as pdfium_c
            texts = [o for o in pdfium_page.get_objects(max_depth=1) if o.type == pdfium_c.FPDF_PAGEOBJ_TEXT]
            for o in texts:
                pdfium_page.remove_obj(o)
            if texts:
                pdfium_page.gen_content()
            for o in texts:
                try:
                    o.close()
                except Exception:
                    pass
            del texts
        except Exception:
            pass
    scale = dpi / 72.0
    bm = pdfium_page.render(scale=scale)
    try:
        img = bm.to_pil().convert("RGB")
    finally:
        bm.close()
    out = []
    for (x0, top, x1, bottom) in regions:
        box = (max(0, int((x0 - frame[0]) * scale)), max(0, int((top - frame[1]) * scale)),
               min(img.width, int((x1 - frame[0]) * scale + 0.999)), min(img.height, int((bottom - frame[1]) * scale + 0.999)))
        if box[2] - box[0] < 4 or box[3] - box[1] < 4:
            out.append(None)
            continue
        out.append(img.crop(box))
    return out


def save_image(pil, img_dir, stem):
    small = pil.copy()
    small.thumbnail((64, 64))
    colors = small.getcolors(64 * 64)
    photo = colors is None or len(colors) > 400
    if photo:
        path = os.path.join(img_dir, stem + ".jpg")
        pil.save(path, "JPEG", quality=88)
    else:
        path = os.path.join(img_dir, stem + ".png")
        pil.save(path, "PNG", optimize=True)
    return path


# ----------------------------------------------------------------------------------------------
# Native page analysis
# ----------------------------------------------------------------------------------------------
def page_frame(page):
    try:
        cb = page.cropbox
        if cb and cb[2] - cb[0] > 10 and cb[3] - cb[1] > 10:
            return tuple(float(v) for v in cb)
    except Exception:
        pass
    b = page.bbox
    return tuple(float(v) for v in b)


def visible_chars(page, frame):
    try:
        chars = page.dedupe_chars(tolerance=1).chars
    except Exception:
        chars = page.chars
    out = []
    for c in chars:
        cx = (c["x0"] + c["x1"]) / 2
        cy = (c["top"] + c["bottom"]) / 2
        if frame[0] - 1 <= cx <= frame[2] + 1 and frame[1] - 1 <= cy <= frame[3] + 1:
            out.append(c)
    return out


def column_plan(ordered, page_bounds):
    """Turn the reading order (item, column bounds) into Word column sections:
    [(n_columns, first_item_index, gap_pt), ...]."""
    tw = max(page_bounds[2] - page_bounds[0], 1.0)
    segs = []  # (kind, start, [bounds])
    for idx, (it, b) in enumerate(ordered):
        narrow = (b[2] - b[0]) < 0.62 * tw
        kind = "col" if narrow else "full"
        if segs and segs[-1][0] == kind:
            segs[-1][2].append(b)
        else:
            segs.append([kind, idx, [b]])
    plan = []
    for kind, start, bounds in segs:
        n = 1
        gap = 0.0
        if kind == "col":
            xs = []
            for b in sorted(bounds, key=lambda b: b[0]):
                if not xs or b[0] > xs[-1][1] - 2:
                    xs.append([b[0], b[2]])
                else:
                    xs[-1][1] = max(xs[-1][1], b[2])
            n = len(xs) if 2 <= len(xs) <= 3 else 1
            if n > 1:
                gaps = [xs[k + 1][0] - xs[k][1] for k in range(n - 1)]
                gap = max(8.0, min(60.0, sum(gaps) / len(gaps)))
        if plan and plan[-1][0] == n:
            continue
        plan.append((n, start, gap))
    if not plan:
        plan = [(1, 0, 0.0)]
    # tiny segments are not worth a section break
    clean = []
    for k, seg in enumerate(plan):
        end = plan[k + 1][1] if k + 1 < len(plan) else len(ordered)
        if clean and seg[0] > 1 and end - seg[1] < 2:
            continue
        if clean and clean[-1][0] == seg[0]:
            continue
        clean.append(seg)
    clean[0] = (clean[0][0], 0, clean[0][2])
    return clean


def analyze_native_page(page, pdfium_page, index, opts, img_dir, raw_chars=None, fix_mojibake=False, doc_state=None):
    doc_state = {} if doc_state is None else doc_state
    frame = page_frame(page)
    W, H = frame[2] - frame[0], frame[3] - frame[1]
    res = PageResult(index=index, width=W, height=H, method="native")
    raw = raw_chars if raw_chars is not None else visible_chars(page, frame)
    upright = [c for c in raw if c.get("upright", True)]
    cbs = make_charboxes(upright, fix_mojibake=fix_mojibake)
    n_space = sum(1 for c in cbs if c.kind == "s")
    n_char = sum(1 for c in cbs if c.kind == "c")
    n_stray = sum(1 for c in cbs if c.kind == "x")
    if n_stray >= 3:
        doc_state["leak_fix"] = True
    if n_stray:
        learn_stray_marks(build_rows(cbs), doc_state)
        unknown = sum(1 for c in cbs if c.kind == "x" and (c.rawfont, c.text) not in doc_state.get("stray_map", {}))
        if unknown:
            res.notes.append(f"{unknown} علامة تشكيل غير مقروءة في ملف PDF لم تُنقل")
    space_factor = 0.33 if n_char and n_space / n_char > 0.06 else 0.15

    tables, consumed = extract_tables(page, cbs, space_factor, doc_state) if opts.get("tables", True) else ([], set())
    table_boxes = [t.bbox for t in tables]

    figures = []
    if opts.get("figures", True):
        try:
            figures = find_vector_figures(page, frame, table_boxes, cbs)
            figures = expand_figures(figures, cbs)
        except Exception:
            figures = []
    in_fig = set()
    for f in figures:
        for c in cbs:
            if f[0] <= (c.x0 + c.x1) / 2 <= f[2] and f[1] <= c.cy <= f[3]:
                in_fig.add(id(c))

    flow = [c for c in cbs if id(c) not in consumed and id(c) not in in_fig]
    rows = build_rows(flow)
    frags = split_rows(rows)
    lines = []
    for fr in frags:
        units = make_units(fr, space_factor, doc_state)
        if any(not u.space for u in units):
            lines.append(Line(units))
    line_gap = estimate_line_gap(lines)
    paragraphs = []
    for block in group_blocks(lines, line_gap):
        block.sort(key=lambda l: l.top)
        for group in split_block(block):
            paragraphs.append(lines_to_paragraph(group))

    # raster images
    pictures = []
    if opts.get("images", True):
        regions, metas = [], []
        dpi_needed = 110
        for im in page.images:
            x0, top, x1, bottom = max(im["x0"], frame[0]), max(im["top"], frame[1]), min(im["x1"], frame[2]), min(im["bottom"], frame[3])
            w, h = x1 - x0, bottom - top
            if w < 12 or h < 12 or w * h > 0.85 * W * H:
                continue
            if any(t[0] - 2 <= (x0 + x1) / 2 <= t[2] + 2 and t[1] - 2 <= (top + bottom) / 2 <= t[3] + 2 for t in figures):
                continue
            src = im.get("srcsize") or (0, 0)
            try:
                native_dpi = float(src[0]) / (w / 72.0)
            except Exception:
                native_dpi = 150
            dpi_needed = max(dpi_needed, min(native_dpi, 220))
            regions.append((x0, top, x1, bottom))
        # de-duplicate identical boxes
        seen = set()
        uniq = []
        for r in regions:
            key = tuple(round(v) for v in r)
            if key not in seen:
                seen.add(key)
                uniq.append(r)
        regions = uniq
        fig_imgs = render_regions(pdfium_page, frame, figures, 200, remove_text=False) if figures else []
        ras_imgs = render_regions(pdfium_page, frame, regions, dpi_needed, remove_text=True) if regions else []
        for k, (box, pil) in enumerate(zip(figures, fig_imgs)):
            if pil is None:
                continue
            path = save_image(pil, img_dir, f"p{index + 1}_fig{k + 1}")
            pictures.append(Picture(path=path, width=box[2] - box[0], height=box[3] - box[1], bbox=box, kind="figure"))
        for k, (box, pil) in enumerate(zip(regions, ras_imgs)):
            if pil is None:
                continue
            path = save_image(pil, img_dir, f"p{index + 1}_img{k + 1}")
            pictures.append(Picture(path=path, width=box[2] - box[0], height=box[3] - box[1], bbox=box, kind="image"))

    items = paragraphs + tables + pictures
    if items:
        tb = _union(items)
        ordered = []
        xy_cut(items, tb, ordered)
        final = []
        for it, b in ordered:
            if isinstance(it, Paragraph):
                it.align = detect_alignment(it, b[0], b[2])
            elif isinstance(it, Picture):
                cx = (it.bbox[0] + it.bbox[2]) / 2
                mid = (frame[0] + frame[2]) / 2
                if abs(cx - mid) < 0.08 * W:
                    it.align = "center"
                elif cx > mid:
                    it.align = "right"
                else:
                    it.align = "left"
            final.append(it)
        prev = None
        for it in final:
            if prev is not None and isinstance(it, Paragraph) and it.bbox and prev.bbox:
                ov = min(it.bbox[2], prev.bbox[2]) - max(it.bbox[0], prev.bbox[0])
                gap = it.bbox[1] - prev.bbox[3]
                if ov > 0 and gap > 0:
                    size = it.size or 11.0
                    extra = gap - 0.35 * size - 4.0
                    if extra > 3.0:
                        it.space_before = round(min(extra, 40.0), 1)
            prev = it
        res.items = final
        if opts.get("columns", True):
            res.col_plan = column_plan(ordered, tb)
        txt_items = [i for i in final if isinstance(i, (Paragraph, Table))]
        if txt_items:
            u = _union(txt_items)
            res.text_bounds = (u[0] - frame[0], u[1] - frame[1], u[2] - frame[0], u[3] - frame[1])
    res.chars_in = sum(1 for c in cbs if c.kind in ("c", "m") and id(c) not in in_fig)
    res.chars_out = sum(tu.count_visible(i.text) for i in res.items if isinstance(i, (Paragraph, Table)))
    nonup = len(raw) - len(upright)
    if nonup > 0:
        res.notes.append(f"{nonup} حرفاً بخط مائل/عمودي لم يُنقل")
    if figures:
        res.notes.append(f"{len(figures)} رسماً بيانياً نُقل كصورة")
    return res
