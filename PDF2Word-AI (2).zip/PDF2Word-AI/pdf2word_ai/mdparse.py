# -*- coding: utf-8 -*-
"""Turn the Markdown written by the AI transcriber into Word paragraphs and tables."""
from __future__ import annotations

import re

from . import textutils as tu
from .model import Paragraph, Run, Table, TableCell

_HEADING = re.compile(r"^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$")
_BULLET = re.compile(r"^\s*[-*•▪●+]\s+(.*)$")
_NUMBERED = re.compile(r"^\s*((?:\d{1,3}|[٠-٩]{1,3})[.)\-])\s+(.*)$")
_RULE = re.compile(r"^\s*([-*_])(\s*\1){2,}\s*$")
_SEP_ROW = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")


def _inline_runs(text: str):
    """Support **bold** only; everything else is literal text."""
    text = text.replace("\\*", "\u0000").replace("\\#", "#").replace("\\|", "|").replace("\\_", "_")
    runs = []
    pos = 0
    for m in re.finditer(r"\*\*(.+?)\*\*", text):
        if m.start() > pos:
            runs.append(Run(text[pos:m.start()]))
        runs.append(Run(m.group(1), bold=True))
        pos = m.end()
    if pos < len(text):
        runs.append(Run(text[pos:]))
    for r in runs:
        r.text = r.text.replace("\u0000", "*")
    return [r for r in runs if r.text] or [Run("")]


def _para(text, heading=0, is_list=False, source="ai"):
    text = tu.normalize_text(text)
    runs = _inline_runs(text)
    plain = "".join(r.text for r in runs)
    p = Paragraph(runs=runs, rtl=tu.is_rtl_text(plain), heading=heading, is_list=is_list, source=source)
    if heading:
        for r in p.runs:
            r.bold = True
    return p


def _split_row(line):
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|") and not s.endswith("\\|"):
        s = s[:-1]
    cells = re.split(r"(?<!\\)\|", s)
    return [c.strip() for c in cells]


def _table(lines, source="ai"):
    rows = [_split_row(l) for l in lines if not _SEP_ROW.match(l)]
    if not rows:
        return None
    ncols = max(len(r) for r in rows)
    grid = []
    for r in rows:
        r = r + [""] * (ncols - len(r))
        grid.append([TableCell(paragraphs=[_para(c, source=source)] if c else []) for c in r])
    text = " ".join(c for r in rows for c in r)
    # Markdown tables are written in reading order -> logical order: right-to-left table for Arabic
    return Table(grid=grid, rtl=tu.is_rtl_text(text))


def parse_markdown(md: str, source="ai"):
    items = []
    lines = (md or "").replace("\r\n", "\n").split("\n")
    buf = []

    def flush():
        if buf:
            text = "\n".join(buf).strip()
            if text:
                items.append(_para(text, source=source))
            buf.clear()

    i = 0
    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if not s:
            flush()
            i += 1
            continue
        if s.startswith("|") and s.count("|") >= 2:
            flush()
            tl = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                tl.append(lines[i])
                i += 1
            t = _table(tl, source)
            if t:
                items.append(t)
            continue
        if _RULE.match(s):
            flush()
            i += 1
            continue
        m = _HEADING.match(line)
        if m:
            flush()
            level = min(3, len(m.group(1)))
            items.append(_para(m.group(2), heading=level, source=source))
            i += 1
            continue
        m = _BULLET.match(line)
        if m:
            flush()
            items.append(_para("• " + m.group(1), is_list=True, source=source))
            i += 1
            continue
        m = _NUMBERED.match(line)
        if m:
            flush()
            items.append(_para(m.group(1) + " " + m.group(2), is_list=True, source=source))
            i += 1
            continue
        buf.append(s)
        i += 1
    flush()
    return items
