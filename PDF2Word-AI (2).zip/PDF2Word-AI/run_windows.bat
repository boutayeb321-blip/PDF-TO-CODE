@echo off
chcp 65001 >nul
title PDF2Word AI
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo First start: running the installer ...
  call "%~dp0install_windows.bat"
)
set PYTHONIOENCODING=utf-8
".venv\Scripts\python.exe" run.py %*
if errorlevel 1 pause
