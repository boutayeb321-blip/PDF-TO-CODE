/*
 * PDF2Word AI — Android app.
 * من إنجاز بوطيب أحمد — by Boutib Ahmed.
 *
 * The heavy work (reading PDFs, OCR, AI) runs in the PDF2Word AI program on the computer.
 * This app is the phone screen for it: you type the computer's address once, and the app
 * shows the program's interface full screen, uploads files from the phone, and saves the
 * finished Word / ZIP files to the phone's Downloads folder.
 */
package com.boutib.pdf2word;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String PREFS = "pdf2word_ai";
    private static final String KEY_URL = "server_url";
    private static final int PICK_FILES = 1001;
    private static final int DEFAULT_PORT = 8765;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String serverUrl = "";
    private boolean showingError = false;

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        serverUrl = prefs().getString(KEY_URL, "");
        if (serverUrl == null || serverUrl.isEmpty()) {
            showSetup(null);
        } else {
            showWeb(serverUrl);
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                getResources().getDisplayMetrics());
    }

    // ---------------------------------------------------------------- setup screen

    /** Asks for the computer's address. Built in code so the app needs no layout files. */
    private void showSetup(String prefill) {
        web = null;
        showingError = false;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#f4f6fb"));
        root.setPadding(dp(24), dp(32), dp(24), dp(24));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("محوّل PDF إلى Word الذكي");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTextColor(Color.parseColor("#0e6b5c"));
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("شغّل البرنامج على الحاسوب بالملف run_phone_windows.bat، "
                + "ثم اكتب هنا العنوان الذي يظهره البرنامج.\n"
                + "يجب أن يكون الهاتف والحاسوب على نفس شبكة الواي‑فاي.");
        help.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        help.setTextColor(Color.parseColor("#475467"));
        help.setPadding(0, dp(12), 0, dp(20));
        root.addView(help);

        final EditText input = new EditText(this);
        input.setHint("192.168.1.20:8765");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setSingleLine(true);
        input.setTextDirection(View.TEXT_DIRECTION_LTR);
        if (prefill != null && !prefill.isEmpty()) {
            input.setText(prefill);
        } else {
            input.setText(prefs().getString(KEY_URL, ""));
        }
        root.addView(input);

        Button connect = new Button(this);
        connect.setText("اتصال");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(20);
        connect.setLayoutParams(bp);
        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = normalize(input.getText().toString());
                if (url.isEmpty()) {
                    Toast.makeText(MainActivity.this,
                            "اكتب عنواناً صحيحاً مثل 192.168.1.20:8765", Toast.LENGTH_LONG).show();
                    return;
                }
                prefs().edit().putString(KEY_URL, url).apply();
                serverUrl = url;
                showWeb(url);
            }
        });
        root.addView(connect);

        TextView by = new TextView(this);
        by.setText("من إنجاز بوطيب أحمد · Boutib Ahmed");
        by.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        by.setTextColor(Color.parseColor("#98a2b3"));
        by.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams byp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        byp.topMargin = dp(28);
        by.setLayoutParams(byp);
        root.addView(by);

        setContentView(root);
    }

    /** "192.168.1.20" -> "http://192.168.1.20:8765/" */
    private String normalize(String raw) {
        String s = raw == null ? "" : raw.trim();
        if (s.isEmpty()) {
            return "";
        }
        if (!s.startsWith("http://") && !s.startsWith("https://")) {
            s = "http://" + s;
        }
        Uri u = Uri.parse(s);
        String host = u.getHost();
        if (host == null || host.isEmpty()) {
            return "";
        }
        int port = u.getPort();
        if (port <= 0) {
            port = DEFAULT_PORT;
        }
        String path = u.getPath();
        if (path == null || path.isEmpty()) {
            path = "/";
        }
        return u.getScheme() + "://" + host + ":" + port + path;
    }

    // ---------------------------------------------------------------- the program's interface

    private void showWeb(String url) {
        showingError = false;
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);          // the interface is a JavaScript app
        s.setDomStorageEnabled(true);          // it remembers your choices
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setSupportMultipleWindows(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String target) {
                return false;                  // keep every page inside the app
            }

            @Override
            public void onReceivedError(WebView view, int code, String description, String failingUrl) {
                if (failingUrl != null && failingUrl.startsWith(serverUrl.substring(0,
                        Math.min(serverUrl.length(), 12)))) {
                    showError(description);
                }
            }

            @TargetApi(Build.VERSION_CODES.M)
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showError(String.valueOf(error.getDescription()));
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(
                            Intent.createChooser(intent, "اختر ملفات PDF أو ZIP"), PICK_FILES);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "تعذّر فتح مدير الملفات", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        // finished Word / ZIP files go to the phone's Downloads folder
        web.setDownloadListener(new android.webkit.DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String disposition,
                                        String mime, long size) {
                String name = URLUtil.guessFileName(url, disposition, mime);
                try {
                    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                    req.setTitle(name);
                    req.setMimeType(mime);
                    req.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) {
                        dm.enqueue(req);
                        Toast.makeText(MainActivity.this, "جارٍ تنزيل: " + name, Toast.LENGTH_LONG).show();
                        return;
                    }
                } catch (Exception e) {
                    // fall through to the browser
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e2) {
                    Toast.makeText(MainActivity.this, "تعذّر تنزيل الملف", Toast.LENGTH_LONG).show();
                }
            }
        });

        setContentView(web);
        web.loadUrl(url);
    }

    private void showError(String reason) {
        if (showingError || isFinishing()) {
            return;
        }
        showingError = true;
        new AlertDialog.Builder(this)
                .setTitle("تعذّر الاتصال بالحاسوب")
                .setMessage("لم أستطع الوصول إلى:\n" + serverUrl + "\n\n"
                        + (reason == null ? "" : reason + "\n\n")
                        + "تأكد من أن:\n"
                        + "• البرنامج يعمل على الحاسوب (run_phone_windows.bat)\n"
                        + "• الهاتف والحاسوب على نفس شبكة الواي‑فاي\n"
                        + "• العنوان مكتوب كما يعرضه البرنامج")
                .setCancelable(false)
                .setPositiveButton("إعادة المحاولة", (d, w) -> {
                    showingError = false;
                    if (web != null) {
                        web.loadUrl(serverUrl);
                    }
                })
                .setNegativeButton("تغيير العنوان", (d, w) -> showSetup(serverUrl))
                .show();
    }

    // ---------------------------------------------------------------- file picker result

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != PICK_FILES) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
        if (fileCallback == null) {
            return;
        }
        Uri[] picked = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                picked = new Uri[n];
                for (int i = 0; i < n; i++) {
                    picked[i] = data.getClipData().getItemAt(i).getUri();
                }
            } else if (data.getData() != null) {
                picked = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(picked);
        fileCallback = null;
    }

    // ---------------------------------------------------------------- navigation & menu

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "تحديث");
        menu.add(0, 2, 1, "تغيير عنوان الحاسوب");
        menu.add(0, 3, 2, "عن البرنامج");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                if (web != null) {
                    web.reload();
                }
                return true;
            case 2:
                showSetup(serverUrl);
                return true;
            case 3:
                new AlertDialog.Builder(this)
                        .setTitle("محوّل PDF إلى Word الذكي")
                        .setMessage("من إنجاز بوطيب أحمد · Boutib Ahmed\n\n"
                                + "هذا التطبيق شاشة تحكّم للبرنامج العامل على الحاسوب؛ "
                                + "تحويل الملفات وقراءتها ضوئياً وتحليلها يجري على الحاسوب.")
                        .setPositiveButton("حسناً", null)
                        .show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
