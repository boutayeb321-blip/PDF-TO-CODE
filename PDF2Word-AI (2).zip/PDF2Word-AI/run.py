# -*- coding: utf-8 -*-
"""Start PDF2Word AI.

  python run.py                 -> opens the Arabic interface in your browser
  python run.py D:\\ -o E:\\Word  -> command line mode (see: python run.py --help)
"""
import multiprocessing
import os
import sys
import tempfile
import traceback


def _app_dir():
    """Folder to write error.log into: next to the .exe when frozen, else next to this file."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _safe_streams():
    """A windowed build (.exe without a console) has no stdout/stderr: give libraries that write
    to them directly a harmless destination so they cannot crash the program."""
    for name in ("stdout", "stderr"):
        if getattr(sys, name, None) is None:
            try:
                setattr(sys, name, open(os.devnull, "w", encoding="utf-8"))
            except OSError:
                pass


def _show_error(err, log):
    """In a windowed build nothing is printed, so show the failure in a message box."""
    if os.name != "nt" or not getattr(sys, "frozen", False):
        return
    import ctypes
    msg = "حدث خطأ أثناء التشغيل.\n\nالتفاصيل في:\n" + log + "\n\n" + err.strip().splitlines()[-1][:300]
    ctypes.windll.user32.MessageBoxW(None, msg, "PDF2Word AI", 0x10)


def main():
    multiprocessing.freeze_support()
    _safe_streams()
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        args = sys.argv[1:]
        if args and args[0] in ("--lan", "--phone"):
            from pdf2word_ai.webui import run_server
            run_server(lan=True)
        elif args:
            from pdf2word_ai.cli import main as cli_main
            sys.exit(cli_main(args))
        else:
            from pdf2word_ai.webui import run_server
            run_server()
    except SystemExit:
        raise
    except Exception:
        err = traceback.format_exc()
        log = os.path.join(_app_dir(), "error.log")
        try:
            with open(log, "w", encoding="utf-8") as f:
                f.write(err)
        except OSError:
            log = os.path.join(tempfile.gettempdir(), "PDF2Word-AI-error.log")
            try:
                with open(log, "w", encoding="utf-8") as f:
                    f.write(err)
            except OSError:
                pass
        print(err)
        print("\nحدث خطأ أثناء التشغيل. التفاصيل محفوظة في: " + log)
        try:
            _show_error(err, log)
        except Exception:
            pass
        if os.name == "nt" and sys.stdin is not None:
            try:
                input("اضغط Enter للإغلاق…")
            except (EOFError, RuntimeError, OSError):
                pass
        sys.exit(1)


if __name__ == "__main__":
    main()
