#!/usr/bin/env bash
# PDF2Word AI - installer for macOS / Linux
set -e
cd "$(dirname "$0")"
export PYTHONIOENCODING=utf-8
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -r requirements-optional.txt || true
echo "Built-in OCR engine (reads image-only PDFs) ..."
if python -m pip install -r requirements-ocr.txt; then
  python -c "from pdf2word_ai.ocr_embedded import EmbeddedOCR; ok, msg = EmbeddedOCR().self_test(); print(msg)" || true
else
  echo "The built-in OCR engine could not be installed; Tesseract will be used."
fi
if ! command -v tesseract >/dev/null 2>&1; then
  if command -v brew >/dev/null 2>&1; then brew install tesseract tesseract-lang || true
  elif command -v apt-get >/dev/null 2>&1; then sudo apt-get install -y tesseract-ocr tesseract-ocr-ara || true
  elif command -v dnf >/dev/null 2>&1; then sudo dnf install -y tesseract tesseract-langpack-ara || true
  else echo "Optional: install Tesseract OCR (with Arabic) from your package manager for even better OCR."; fi
fi
python -c "from pdf2word_ai.ocr import Tesseract; t=Tesseract(log=print); print(t.prepare(allow_download=True, upgrade_arabic=True))" || true
echo "Done. Start with: ./run_mac_linux.sh"
