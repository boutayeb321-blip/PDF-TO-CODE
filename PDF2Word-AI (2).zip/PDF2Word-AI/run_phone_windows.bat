@echo off
chcp 65001 >nul
title PDF2Word AI - Phone mode  (by Boutib Ahmed)
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo First start: running the installer ...
  call "%~dp0install_windows.bat"
)
set PYTHONIOENCODING=utf-8
echo Starting in phone mode. Open the shown http://192.168... address
echo in your phone browser (same Wi-Fi), then "Add to Home screen".
".venv\Scripts\python.exe" run.py --lan
if errorlevel 1 pause
