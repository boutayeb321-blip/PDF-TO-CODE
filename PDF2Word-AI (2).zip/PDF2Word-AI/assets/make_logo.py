# -*- coding: utf-8 -*-
"""Generate the app logo (PNG, multi-size ICO, and Android launcher PNGs) from one design.
Run:  python assets/make_logo.py
No internet or extra packages needed (Pillow only, already required by the app)."""
import os

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
SS = 4  # supersampling for smooth edges

TEAL1 = (24, 162, 134)   # top of the gradient
TEAL2 = (11, 85, 71)     # bottom
RED = (211, 47, 47)
BLUE = (21, 101, 192)
INK = (28, 36, 48)


def font(path, size):
    for p in (path, "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(p, size)
        except OSError:
            continue
    return ImageFont.load_default()


FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FL = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"


def rounded(draw, box, r, fill):
    draw.rounded_rectangle(box, radius=r, fill=fill)


def vgrad(size, c1, c2, radius):
    """Rounded square filled with a vertical gradient."""
    w = h = size
    grad = Image.new("RGB", (1, h))
    for y in range(h):
        t = y / (h - 1)
        grad.putpixel((0, y), tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3)))
    grad = grad.resize((w, h))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=radius, fill=255)
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(grad, (0, 0), mask)
    return out


def draw_logo(px=1024):
    from PIL.ImageFilter import GaussianBlur
    S = px * SS
    img = vgrad(S, TEAL1, TEAL2, radius=int(S * 0.235))
    # subtle, soft top sheen (blurred so there is no visible edge)
    hi = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(hi).ellipse([int(S * -0.15), int(S * -0.55), int(S * 1.15), int(S * 0.45)], fill=(255, 255, 255, 30))
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.235), fill=255)
    hi.putalpha(Image.composite(hi.getchannel("A"), Image.new("L", (S, S), 0), mask).filter(GaussianBlur(S * 0.02)))
    img = Image.alpha_composite(img, hi)
    d = ImageDraw.Draw(img)

    # --- document (white sheet with a folded corner) ---
    L, T, R, B = int(S * 0.285), int(S * 0.215), int(S * 0.715), int(S * 0.80)
    fold = int(S * 0.11)
    rr = int(S * 0.028)
    # soft drop shadow
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rounded_rectangle([L + int(S * 0.012), T + int(S * 0.022), R + int(S * 0.012), B + int(S * 0.022)],
                                             radius=int(S * 0.03), fill=(0, 0, 0, 80))
    img = Image.alpha_composite(img, shadow.filter(GaussianBlur(S * 0.014)))
    # white sheet with the top-right corner folded
    page = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    pd = ImageDraw.Draw(page)
    pd.rounded_rectangle([L, T, R, B], radius=rr, fill=(255, 255, 255, 255))
    cut = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(cut).polygon([(R - fold, T - 2), (R + 4, T - 2), (R + 4, T + fold)], fill=(255, 255, 255, 255))
    page.paste((0, 0, 0, 0), (0, 0), cut)
    pd.polygon([(R - fold, T), (R, T + fold), (R - fold, T + fold)], fill=(206, 224, 221, 255))
    img = Image.alpha_composite(img, page)
    d = ImageDraw.Draw(img)

    # --- PDF pill ---
    pill_w, pill_h = int(S * 0.235), int(S * 0.083)
    px0 = (L + R) // 2 - pill_w // 2
    py0 = T + int(S * 0.065)
    d.rounded_rectangle([px0, py0, px0 + pill_w, py0 + pill_h], radius=pill_h // 2, fill=RED)
    f1 = font(FL, int(S * 0.052))
    d.text(((px0 + px0 + pill_w) / 2, py0 + pill_h / 2), "PDF", font=f1, fill=(255, 255, 255, 255), anchor="mm")

    # --- arrow down ---
    cx = (L + R) // 2
    ay0, ay1 = T + int(S * 0.20), T + int(S * 0.315)
    aw = int(S * 0.028)
    d.line([(cx, ay0), (cx, ay1)], fill=(120, 132, 145, 255), width=aw)
    ah = int(S * 0.040)
    d.polygon([(cx - ah, ay1 - ah * 0.3), (cx + ah, ay1 - ah * 0.3), (cx, ay1 + ah)], fill=(120, 132, 145, 255))

    # --- W (Word) ---
    f2 = font(FL, int(S * 0.205))
    wy = T + int(S * 0.405)
    d.text((cx, wy), "W", font=f2, fill=BLUE, anchor="mm")

    img = img.resize((px, px), Image.LANCZOS)
    return img


def main():
    os.makedirs(HERE, exist_ok=True)
    big = draw_logo(1024)
    big.save(os.path.join(HERE, "logo.png"))
    # web header (small)
    big.resize((256, 256), Image.LANCZOS).save(os.path.join(HERE, "logo_256.png"))
    # Windows ICO (multi-size)
    ico_sizes = [16, 24, 32, 48, 64, 128, 256]
    big.save(os.path.join(HERE, "icon.ico"), sizes=[(s, s) for s in ico_sizes])
    # Android launcher icons (mipmap densities)
    for name, s in (("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)):
        d = os.path.join(HERE, "android", f"mipmap-{name}")
        os.makedirs(d, exist_ok=True)
        big.resize((s, s), Image.LANCZOS).save(os.path.join(d, "ic_launcher.png"))
    # Play Store / general 512
    big.resize((512, 512), Image.LANCZOS).save(os.path.join(HERE, "logo_512.png"))
    print("wrote logo.png, logo_256.png, logo_512.png, icon.ico, android/mipmap-*/ic_launcher.png")


if __name__ == "__main__":
    main()
