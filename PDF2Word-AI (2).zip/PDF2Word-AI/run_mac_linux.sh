#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -x .venv/bin/python ] || ./install_mac_linux.sh
exec .venv/bin/python run.py "$@"
