@echo off
chcp 65001 >nul
title PDF2Word AI - Setup
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo ================================================================
echo   PDF2Word AI - installation (needs internet, only once)
echo ================================================================
echo.
set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" >nul 2>nul && set "PY=python"
if not defined PY goto nopython
echo [1/5] Python found:
%PY% --version
if not exist ".venv\Scripts\python.exe" (
  echo Creating a private Python environment ...
  %PY% -m venv .venv || goto fail
)
echo [2/5] Installing libraries ...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto fail
".venv\Scripts\python.exe" -m pip install -r requirements-optional.txt >nul 2>nul
echo [3/5] Built-in OCR engine (reads image-only PDFs, about 60 MB) ...
".venv\Scripts\python.exe" -m pip install -r requirements-ocr.txt
if errorlevel 1 (
  echo   The built-in OCR engine could not be installed. Tesseract below is used instead.
) else (
  echo   Downloading the OCR models once and testing the engine ...
  ".venv\Scripts\python.exe" -c "from pdf2word_ai.ocr_embedded import EmbeddedOCR; ok, msg = EmbeddedOCR().self_test(); print(msg)"
)
echo [4/5] Tesseract OCR (second OCR engine, optional - improves accuracy) ...
where tesseract >nul 2>nul && goto tessok
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" goto tessok
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" goto tessok
where winget >nul 2>nul || goto tessmanual
echo Installing Tesseract with winget (accept the Windows prompt if asked) ...
winget install -e --id UB-Mannheim.TesseractOCR --accept-package-agreements --accept-source-agreements
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" goto tessok
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" goto tessok
:tessmanual
echo.
echo   Tesseract is not installed (optional). To add it later, install it from:
echo   https://github.com/UB-Mannheim/tesseract/wiki
echo   and run this file again.
goto shortcut
:tessok
echo [5/5] Downloading the best Arabic model for Tesseract (about 13 MB, once) ...
".venv\Scripts\python.exe" -c "from pdf2word_ai.ocr import Tesseract; t=Tesseract(log=print); print(t.prepare(allow_download=True, upgrade_arabic=True))"
:shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\PDF2Word AI.lnk'); $s.TargetPath='%~dp0run_windows.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation=$env:SystemRoot+'\System32\imageres.dll,2'; $s.Save()" >nul 2>nul
echo.
echo ================================================================
echo   Done. Start the program with the "PDF2Word AI" icon on your
echo   desktop, or double-click run_windows.bat
echo ================================================================
pause
exit /b 0
:nopython
echo Python 3.9 or newer was not found.
echo Install it from https://www.python.org/downloads/ and tick
echo "Add python.exe to PATH" on the first installer screen, then run this file again.
start "" https://www.python.org/downloads/
pause
exit /b 1
:fail
echo.
echo Installation failed. Check the internet connection and run this file again.
pause
exit /b 1
