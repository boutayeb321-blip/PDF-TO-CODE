#!/usr/bin/env bash
# PDF2Word AI - phone mode (open from your phone on the same Wi-Fi)
cd "$(dirname "$0")"
. .venv/bin/activate 2>/dev/null || true
export PYTHONIOENCODING=utf-8
python run.py --lan
